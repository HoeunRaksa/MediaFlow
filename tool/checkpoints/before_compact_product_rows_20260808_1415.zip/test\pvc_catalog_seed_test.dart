import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:material_quote_pro/core/constants/business_ids.dart';
import 'package:material_quote_pro/core/storage/local_json_storage.dart';
import 'package:material_quote_pro/features/materials/data/models/material_price.dart';
import 'package:material_quote_pro/features/materials/data/seed/default_material_seed.dart';
import 'package:material_quote_pro/features/materials/data/seed/pvc_catalog_seed.dart';
import 'package:material_quote_pro/features/materials/domain/material_quantity_pricing.dart';

void main() {
  final now = DateTime.utc(2026, 8, 8);

  MaterialPrice price(String materialId, String priceTypeId) {
    return DefaultMaterialSeed.prices(now).singleWhere(
      (entry) =>
          entry.materialId == materialId && entry.priceTypeId == priceTypeId,
    );
  }

  group('PVC catalog seed', () {
    test('contains all requested selling and base factory prices', () {
      expect(
        price(PvcMaterialIds.k01_3000, PriceTypeIds.saleUnitPrice).price,
        6.70,
      );
      expect(
        price(PvcMaterialIds.k01_4000, PriceTypeIds.saleUnitPrice).price,
        8.60,
      );
      expect(
        price(PvcMaterialIds.p01_3000, PriceTypeIds.saleUnitPrice).price,
        6.90,
      );
      expect(
        price(PvcMaterialIds.p01_4000, PriceTypeIds.saleUnitPrice).price,
        8.85,
      );
      expect(
        price(PvcMaterialIds.k01_3000, PriceTypeIds.costUnitPrice).price,
        5.80,
      );

      final cLine023Sale = price(
        PvcMaterialIds.cLine023_4000,
        PriceTypeIds.saleBoxPrice,
      );
      final cLine023Cost = price(
        PvcMaterialIds.cLine023_4000,
        PriceTypeIds.costBoxPrice,
      );
      final cLine027Sale = price(
        PvcMaterialIds.cLine027_4000,
        PriceTypeIds.saleBoxPrice,
      );
      final cLine027Cost = price(
        PvcMaterialIds.cLine027_4000,
        PriceTypeIds.costBoxPrice,
      );
      expect(cLine023Sale.priceCents, 1624);
      expect(cLine023Cost.priceCents, 850);
      expect(cLine027Sale.priceCents, 1719);
      expect(cLine027Cost.priceCents, 950);
    });

    test('quantity tier lookup uses the highest eligible breakpoint', () {
      final tiers = DefaultMaterialSeed.quantityPriceTiers(now);

      final quantity100 = MaterialQuantityPricing.resolve(
        materialId: PvcMaterialIds.k01_3000,
        quantity: 100,
        tiers: tiers,
      );
      final quantity500 = MaterialQuantityPricing.resolve(
        materialId: PvcMaterialIds.k01_3000,
        quantity: 500,
        tiers: tiers,
      );

      expect(quantity100?.unitPriceCents, 530);
      expect(quantity500?.unitPriceCents, 500);
    });

    test('uses authoritative factory names and dimensions', () {
      final materials = DefaultMaterialSeed.materials(now);
      final selling160 = materials.singleWhere(
        (entry) => entry.id == 'pvc_image1_row03_160x20x3000',
      );
      final factory160 = materials.singleWhere(
        (entry) => entry.id == 'pvc_factory_160x22x3000',
      );

      expect(selling160.khmerName, '4ភ្លឺធំ');
      expect(selling160.englishName, '4ភ្លឺធំ');
      expect(selling160.spec, '160 × 22 × 3000 mm');
      expect(selling160.thicknessMm, 22);
      expect(factory160.thicknessMm, 22);
      expect(selling160.id, isNot(factory160.id));

      const requiredKhmerNames = {
        '4ភ្លឺធំ',
        '3ភ្លឺធំទាប',
        '4ភ្លឺទាប',
        'ជ្រី V',
        'ជ្រីស៊ុមទ្វាបង្អួច',
        'ជ្រីជើងជញ្ជាំង',
        'ជ្រីធំលើ',
        'ជ្រីដេគ័រ',
        'ជ្រីកែង',
        'ជ្រីតតំណ',
        'ជ្រីចំហៀង',
        'ញូម',
        'ឃ្មៀបអ៊ីណុក',
        'កាវ',
        'វីសបាញ់ពិដាន',
        'វីសបាញ់ក្តារក្រាលបាត',
        'ជ្រីខណ្ឌជញ្ជាំង',
      };
      final pvc = materials.where((item) => item.categoryId == 'pvc').toList();
      final names = pvc.map((item) => item.khmerName).toSet();
      expect(names, containsAll(requiredKhmerNames));
      for (final name in requiredKhmerNames) {
        expect(
          pvc
              .where((item) => item.khmerName == name)
              .map((item) => item.englishName)
              .toSet(),
          {name},
        );
      }
      expect(
        pvc.where(
          (item) =>
              item.khmerName.contains('Row') ||
              item.englishName.contains('Accessory'),
        ),
        isEmpty,
      );
    });

    test('uses factory package sizes for clips and screws', () {
      final materials = DefaultMaterialSeed.materials(now);
      final clip = materials.singleWhere(
        (item) => item.id == 'pvc_image1_row16',
      );
      final ceilingScrew = materials.singleWhere(
        (item) => item.id == 'pvc_image1_row17',
      );
      final floorScrew = materials.singleWhere(
        (item) => item.id == 'pvc_image1_row18',
      );

      expect(clip.spec, '100គ្រាប់/កញ្ចប់');
      expect(clip.piecesPerBundle, 100);
      expect(ceilingScrew.spec, '1000គ្រាប់/កញ្ចប់');
      expect(ceilingScrew.piecesPerBundle, 1000);
      expect(floorScrew.piecesPerBundle, 1000);
      expect(price('pvc_image1_row16', PriceTypeIds.saleBoxPrice).price, 4);
    });

    test('inserts the expected PVC record totals', () {
      final pvcMaterials = DefaultMaterialSeed.materials(
        now,
      ).where((entry) => entry.categoryId == 'pvc').toList();
      final pvcIds = pvcMaterials.map((entry) => entry.id).toSet();
      final pvcPrices = DefaultMaterialSeed.prices(
        now,
      ).where((entry) => pvcIds.contains(entry.materialId)).toList();
      final salePrices = pvcPrices
          .where(
            (entry) =>
                entry.priceTypeId == PriceTypeIds.saleUnitPrice ||
                entry.priceTypeId == PriceTypeIds.saleBoxPrice,
          )
          .toList();
      final costPrices = pvcPrices
          .where(
            (entry) =>
                entry.priceTypeId == PriceTypeIds.costUnitPrice ||
                entry.priceTypeId == PriceTypeIds.costBoxPrice,
          )
          .toList();

      expect(pvcMaterials, hasLength(67));
      expect(salePrices, hasLength(47));
      expect(costPrices, hasLength(60));
      expect(DefaultMaterialSeed.quantityPriceTiers(now), hasLength(119));
    });

    test(
      'seeding twice does not duplicate products, prices, or tiers',
      () async {
        final directory = await Directory.systemTemp.createTemp(
          'mqp_pvc_seed_',
        );
        addTearDown(() async {
          if (await directory.exists()) {
            await directory.delete(recursive: true);
          }
        });
        final storage = LocalJsonStorage(baseDirectory: directory);
        final seed = DefaultMaterialSeed.json(now);

        await storage.ensureSeeded(seed);
        await storage.ensureSeeded(seed);

        for (final key in const [
          'materials',
          'prices',
          'materialQuantityPriceTiers',
        ]) {
          final rows = await storage.readCollection(key);
          final ids = rows.map((row) => row['id']).toList();
          expect(ids.toSet(), hasLength(ids.length), reason: key);
          expect(rows, hasLength((seed[key] as List).length), reason: key);
        }
      },
    );

    test(
      'existing local PVC placeholders migrate to canonical master data',
      () async {
        final directory = await Directory.systemTemp.createTemp(
          'mqp_pvc_names_',
        );
        addTearDown(() async {
          if (await directory.exists()) {
            await directory.delete(recursive: true);
          }
        });
        final storage = LocalJsonStorage(baseDirectory: directory);
        final seed = DefaultMaterialSeed.json(now);
        await storage.ensureSeeded(seed);

        final materials = await storage.readCollection('materials');
        final row03 = materials.singleWhere(
          (item) => item['id'] == 'pvc_image1_row03_160x20x3000',
        );
        row03
          ..['khmerName'] = 'ROW-03'
          ..['englishName'] = 'PVC Image 1 Row 3'
          ..['code'] = 'ROW-03'
          ..['spec'] = '160 × 20 × 3000 mm'
          ..['thicknessMm'] = 20;
        await storage.writeCollection('materials', materials);

        final prices = (await storage.readCollection('prices')).toList();
        prices.removeWhere(
          (item) =>
              item['materialId'] == 'pvc_image1_row16' &&
              item['priceTypeId'] == PriceTypeIds.saleBoxPrice,
        );
        prices.add({
          ...price('pvc_image1_row16', PriceTypeIds.saleBoxPrice).toJson(),
          'id': 'pvc_image1_row16_${PriceTypeIds.saleUnitPrice}',
          'priceTypeId': PriceTypeIds.saleUnitPrice,
        });
        await storage.writeCollection('prices', prices);

        final packaging = (await storage.readCollection(
          'packagingRules',
        )).toList();
        packaging.add({
          ...packaging.first,
          'id': 'packaging_pvc_image1_row13',
          'materialId': 'pvc_image1_row13',
        });
        await storage.writeCollection('packagingRules', packaging);

        await storage.ensureSeeded(seed);

        final migratedMaterials = await storage.readCollection('materials');
        final migratedRow03 = migratedMaterials.singleWhere(
          (item) => item['id'] == 'pvc_image1_row03_160x20x3000',
        );
        expect(migratedRow03['khmerName'], '4ភ្លឺធំ');
        expect(migratedRow03['englishName'], '4ភ្លឺធំ');
        expect(migratedRow03['thicknessMm'], 22);

        final migratedPrices = await storage.readCollection('prices');
        expect(
          migratedPrices.where(
            (item) =>
                item['materialId'] == 'pvc_image1_row16' &&
                item['priceTypeId'] == PriceTypeIds.saleUnitPrice,
          ),
          isEmpty,
        );
        expect(
          migratedPrices.where(
            (item) =>
                item['materialId'] == 'pvc_image1_row16' &&
                item['priceTypeId'] == PriceTypeIds.saleBoxPrice,
          ),
          hasLength(1),
        );
        final migratedPackaging = await storage.readCollection(
          'packagingRules',
        );
        expect(
          migratedPackaging.where(
            (item) => item['id'] == 'packaging_pvc_image1_row13',
          ),
          isEmpty,
        );
      },
    );

    test('legacy decimal prices migrate to canonical cents', () async {
      final legacy = MaterialPrice.fromJson({
        'id': 'legacy',
        'materialId': 'legacy',
        'priceTypeId': PriceTypeIds.saleUnitPrice,
        'price': 16.24,
        'currencyCode': 'USD',
        'effectiveFrom': DateTime.utc(2020).toIso8601String(),
        'effectiveTo': null,
        'active': true,
        'createdAt': now.toIso8601String(),
        'updatedAt': now.toIso8601String(),
      });

      expect(legacy.priceCents, 1624);
      expect(legacy.toJson()['priceCents'], 1624);
    });
  });
}

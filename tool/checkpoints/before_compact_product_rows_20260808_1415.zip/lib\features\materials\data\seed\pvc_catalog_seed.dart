import '../../../../core/constants/business_ids.dart';
import '../models/material_item.dart';
import '../models/material_price.dart';
import '../models/material_quantity_price_tier.dart';
import '../models/packaging_rule.dart';

class PvcMaterialIds {
  const PvcMaterialIds._();

  static const k01_3000 = 'pvc_k01_3000';
  static const k01_4000 = 'pvc_k01_4000';
  static const p01_3000 = 'pvc_p01_3000';
  static const p01_4000 = 'pvc_p01_4000';
  static const cLine023_4000 = 'pvc_c_line_023_4000';
  static const cLine027_4000 = 'pvc_c_line_027_4000';
}

class PvcCatalogSeed {
  const PvcCatalogSeed._();

  static final DateTime factorySourceDate = DateTime.utc(2026, 5, 16);
  static final DateTime sellingSourceDate = DateTime.utc(2026, 8, 8);

  static List<MaterialItem> materials(DateTime now) {
    final products = _products();
    return [
      for (var index = 0; index < products.length; index++)
        MaterialItem(
          id: products[index].id,
          khmerName: products[index].name,
          englishName: products[index].name,
          spec: products[index].spec,
          unitId: 'piece',
          unitKhmer: 'ដើម',
          unitEnglish: 'Piece',
          categoryId: 'pvc',
          categoryKhmer: 'PVC',
          categoryEnglish: 'PVC',
          formulaTypeId: FormulaTypeIds.manualQuantity,
          coverageValue: null,
          multiplierValue: null,
          fixedQuantity: null,
          itemsPerBox: products[index].piecesPerBundle ?? 1,
          active: true,
          includedByDefault: false,
          showInCustomerQuote: products[index].sellingPriceCents != null,
          showInPickList: true,
          isOptionalAddon: true,
          isServiceOnly: false,
          sortOrder: 1000 + index,
          createdAt: now,
          updatedAt: now,
          code: products[index].code,
          productFamilyId: products[index].productFamilyId,
          widthMm: products[index].widthMm,
          thicknessMm: products[index].thicknessMm,
          lengthMm: products[index].lengthMm,
          piecesPerBundle: products[index].piecesPerBundle,
          notes: products[index].notes,
        ),
    ];
  }

  static List<MaterialPrice> prices(DateTime now) {
    final result = <MaterialPrice>[];
    for (final product in _products()) {
      final saleCents = product.sellingPriceCents;
      if (saleCents != null) {
        result.add(
          _price(
            materialId: product.id,
            priceTypeId: product.bundlePrice
                ? PriceTypeIds.saleBoxPrice
                : PriceTypeIds.saleUnitPrice,
            priceCents: saleCents,
            effectiveFrom: sellingSourceDate,
            now: now,
          ),
        );
      }
      final costCents = product.costPriceCents;
      if (costCents != null) {
        result.add(
          _price(
            materialId: product.id,
            priceTypeId: product.bundlePrice
                ? PriceTypeIds.costBoxPrice
                : PriceTypeIds.costUnitPrice,
            priceCents: costCents,
            effectiveFrom: factorySourceDate,
            now: now,
          ),
        );
      }
    }
    return result;
  }

  static List<MaterialQuantityPriceTier> quantityPriceTiers(DateTime now) {
    return [
      for (final product in _products())
        for (final entry in product.wholesalePriceCents.entries)
          MaterialQuantityPriceTier(
            id: '${product.id}_quantity_${entry.key}',
            materialId: product.id,
            minQuantity: entry.key,
            unitPriceCents: entry.value,
            currencyCode: 'USD',
            sourceDate: factorySourceDate,
            active: true,
            createdAt: now,
            updatedAt: now,
          ),
    ];
  }

  static List<PackagingRule> packagingRules(DateTime now) {
    return [
      for (final product in _products())
        if (product.piecesPerBundle != null)
          PackagingRule(
            id: 'packaging_${product.id}',
            materialId: product.id,
            itemsPerBox: product.piecesPerBundle!,
            boxUnitNameKhmer: 'បាច់',
            boxUnitNameEnglish: 'Bundle',
            size: product.spec,
            length: product.lengthMm == null
                ? ''
                : '${product.lengthMm!.toStringAsFixed(0)} mm',
            note: '${product.piecesPerBundle} pieces per bundle',
            active: true,
            updatedAt: now,
          ),
    ];
  }

  static MaterialPrice _price({
    required String materialId,
    required String priceTypeId,
    required int priceCents,
    required DateTime effectiveFrom,
    required DateTime now,
  }) {
    return MaterialPrice(
      id: '${materialId}_$priceTypeId',
      materialId: materialId,
      priceTypeId: priceTypeId,
      price: priceCents / 100,
      priceCents: priceCents,
      currencyCode: 'USD',
      effectiveFrom: effectiveFrom,
      effectiveTo: null,
      active: true,
      createdAt: now,
      updatedAt: now,
    );
  }

  static List<_PvcProduct> _products() {
    final products = <_PvcProduct>[];
    const kCodes = [
      'K-01',
      'K-02',
      'K-03',
      'K-04',
      'K-05',
      'K-06',
      'K-08',
      'K-10',
      'K-11',
      'K-12',
    ];
    const pCodes = ['P-01', 'P-02', 'P-03'];

    void addSeries({
      required List<String> codes,
      required String productName,
      required int lengthMm,
      required int sellingPriceCents,
      required int costPriceCents,
      required Map<int, int> wholesalePriceCents,
    }) {
      for (final code in codes) {
        final compactCode = code.toLowerCase().replaceAll('-', '');
        products.add(
          _PvcProduct(
            id: 'pvc_${compactCode}_$lengthMm',
            code: code,
            productFamilyId: 'pvc_$compactCode',
            name: productName,
            spec: '400 × 10 × $lengthMm mm',
            widthMm: 400,
            thicknessMm: 10,
            lengthMm: lengthMm.toDouble(),
            sellingPriceCents: sellingPriceCents,
            costPriceCents: costPriceCents,
            wholesalePriceCents: wholesalePriceCents,
            notes: '$code is a color/design code for $productName.',
          ),
        );
      }
    }

    addSeries(
      codes: kCodes,
      productName: 'K 3m',
      lengthMm: 3000,
      sellingPriceCents: 670,
      costPriceCents: 580,
      wholesalePriceCents: const {50: 560, 100: 530, 300: 510, 500: 500},
    );
    addSeries(
      codes: kCodes,
      productName: 'K 4m',
      lengthMm: 4000,
      sellingPriceCents: 860,
      costPriceCents: 770,
      wholesalePriceCents: const {50: 750, 100: 720, 300: 700, 500: 690},
    );
    addSeries(
      codes: pCodes,
      productName: 'P 3m',
      lengthMm: 3000,
      sellingPriceCents: 690,
      costPriceCents: 600,
      wholesalePriceCents: const {50: 580, 100: 550, 300: 530, 500: 520},
    );
    addSeries(
      codes: pCodes,
      productName: 'P 4m',
      lengthMm: 4000,
      sellingPriceCents: 885,
      costPriceCents: 795,
      wholesalePriceCents: const {50: 775, 100: 745, 300: 725, 500: 715},
    );

    products.addAll([
      const _PvcProduct(
        id: 'pvc_image1_row03_160x20x3000',
        code: '4ភ្លឺធំ',
        productFamilyId: 'pvc_image1_row03',
        name: '4ភ្លឺធំ',
        spec: '160 × 22 × 3000 mm',
        widthMm: 160,
        thicknessMm: 22,
        lengthMm: 3000,
        sellingPriceCents: 580,
        notes: 'Authoritative factory-sheet name and dimensions.',
      ),
      const _PvcProduct(
        id: 'pvc_image1_row04_195x3000',
        code: '3ភ្លឺធំទាប',
        productFamilyId: 'pvc_image1_row04',
        name: '3ភ្លឺធំទាប',
        spec: '195 × 12 × 3000 mm',
        widthMm: 195,
        thicknessMm: 12,
        lengthMm: 3000,
        sellingPriceCents: 650,
        notes: 'Authoritative factory-sheet name and dimensions.',
      ),
      const _PvcProduct(
        id: 'pvc_image1_row05_150x3000',
        code: '4ភ្លឺទាប',
        productFamilyId: 'pvc_image1_row05',
        name: '4ភ្លឺទាប',
        spec: '160 × 9 × 3000 mm',
        widthMm: 160,
        thicknessMm: 9,
        lengthMm: 3000,
        sellingPriceCents: 550,
        notes: 'Authoritative factory-sheet name and dimensions.',
      ),
      const _PvcProduct(
        id: 'pvc_factory_160x22x3000',
        code: '4ភ្លឺធំ',
        productFamilyId: 'pvc_factory_160x22',
        name: '4ភ្លឺធំ',
        spec: '160 × 22 × 3000 mm',
        widthMm: 160,
        thicknessMm: 22,
        lengthMm: 3000,
        costPriceCents: 490,
        wholesalePriceCents: {30: 480, 50: 450, 100: 430, 300: 410, 500: 400},
        notes: 'Factory price source dated 16/05/2026.',
      ),
      const _PvcProduct(
        id: 'pvc_factory_195x12x3000',
        code: '3ភ្លឺធំទាប',
        productFamilyId: 'pvc_factory_195x12',
        name: '3ភ្លឺធំទាប',
        spec: '195 × 12 × 3000 mm',
        widthMm: 195,
        thicknessMm: 12,
        lengthMm: 3000,
        costPriceCents: 510,
        wholesalePriceCents: {30: 500, 50: 470, 100: 450, 300: 430, 500: 420},
        notes: 'Factory price source dated 16/05/2026.',
      ),
      const _PvcProduct(
        id: 'pvc_factory_160x9x3000',
        code: '4ភ្លឺទាប',
        productFamilyId: 'pvc_factory_160x9',
        name: '4ភ្លឺទាប',
        spec: '160 × 9 × 3000 mm',
        widthMm: 160,
        thicknessMm: 9,
        lengthMm: 3000,
        costPriceCents: 440,
        wholesalePriceCents: {30: 430, 50: 400, 100: 380, 300: 360, 500: 350},
        notes: 'Factory price source dated 16/05/2026.',
      ),
      const _PvcProduct(
        id: 'pvc_v_25x25x3000',
        code: 'ជ្រី V',
        productFamilyId: 'pvc_v',
        name: 'ជ្រី V',
        spec: '3 m',
        lengthMm: 3000,
        sellingPriceCents: 350,
        costPriceCents: 250,
        notes: 'Authoritative factory-sheet name.',
      ),
    ]);

    const namedRows = [
      _PvcSheetRow(
        row: 7,
        name: 'ជ្រីស៊ុមទ្វាបង្អួច',
        saleCents: 550,
        costCents: 430,
      ),
      _PvcSheetRow(
        row: 8,
        name: 'ជ្រីជើងជញ្ជាំង',
        saleCents: 550,
        costCents: 430,
      ),
      _PvcSheetRow(row: 9, name: 'ជ្រីធំលើ', saleCents: 550, costCents: 430),
      _PvcSheetRow(row: 10, name: 'ជ្រីដេគ័រ', saleCents: 400, costCents: 280),
      _PvcSheetRow(row: 11, name: 'ជ្រីកែង', saleCents: 400, costCents: 280),
      _PvcSheetRow(row: 12, name: 'ជ្រីតតំណ', saleCents: 420, costCents: 280),
      _PvcSheetRow(row: 13, name: 'ជ្រីចំហៀង', saleCents: 550, costCents: 280),
      _PvcSheetRow(row: 14, name: 'ញូម', saleCents: 600, costCents: 320),
      _PvcSheetRow(
        row: 16,
        name: 'ឃ្មៀបអ៊ីណុក',
        spec: '100គ្រាប់/កញ្ចប់',
        saleCents: 400,
        piecesPerBundle: 100,
      ),
      _PvcSheetRow(
        row: 17,
        name: 'វីសបាញ់ពិដាន',
        spec: '1000គ្រាប់/កញ្ចប់',
        saleCents: 400,
        costCents: 260,
        piecesPerBundle: 1000,
      ),
      _PvcSheetRow(
        row: 18,
        name: 'វីសបាញ់ក្តារក្រាលបាត',
        spec: '1000គ្រាប់/កញ្ចប់',
        saleCents: 460,
        piecesPerBundle: 1000,
      ),
    ];
    for (final entry in namedRows) {
      final row = entry.row;
      products.add(
        _PvcProduct(
          id: 'pvc_image1_row${row.toString().padLeft(2, '0')}',
          code: entry.name,
          productFamilyId: 'pvc_image1_row${row.toString().padLeft(2, '0')}',
          name: entry.name,
          spec: entry.spec,
          lengthMm: entry.piecesPerBundle == null ? 3000 : null,
          piecesPerBundle: entry.piecesPerBundle,
          bundlePrice: entry.piecesPerBundle != null,
          sellingPriceCents: entry.saleCents,
          costPriceCents: entry.costCents,
          notes: 'Authoritative factory-sheet name and package size.',
        ),
      );
    }

    products.addAll([
      const _PvcProduct(
        id: 'pvc_image2_100_piece_accessory',
        code: 'ឃ្មៀបអ៊ីណុក',
        productFamilyId: 'pvc_image2_100_piece_accessory',
        name: 'ឃ្មៀបអ៊ីណុក',
        spec: '100គ្រាប់/កញ្ចប់',
        piecesPerBundle: 100,
        bundlePrice: true,
        costPriceCents: 400,
        notes: 'Authoritative factory-sheet name and package size.',
      ),
      const _PvcProduct(
        id: 'pvc_glue',
        code: 'កាវ',
        productFamilyId: 'pvc_glue',
        name: 'កាវ',
        spec: '',
        sellingPriceCents: 450,
        costPriceCents: 250,
        notes: 'Authoritative factory-sheet name.',
      ),
      const _PvcProduct(
        id: PvcMaterialIds.cLine023_4000,
        code: 'C.Line 0.23 x 4m',
        productFamilyId: 'pvc_c_line_023',
        name: 'C.Line 0.23 x 4m',
        spec: '1បាច់ = 20ដើម',
        lengthMm: 4000,
        piecesPerBundle: 20,
        bundlePrice: true,
        sellingPriceCents: 1624,
        costPriceCents: 850,
        notes: 'Selling and factory prices are per 20-piece bundle.',
      ),
      const _PvcProduct(
        id: PvcMaterialIds.cLine027_4000,
        code: 'C.Line 0.27 x 4m',
        productFamilyId: 'pvc_c_line_027',
        name: 'C.Line 0.27 x 4m',
        spec: '1បាច់ = 20ដើម',
        lengthMm: 4000,
        piecesPerBundle: 20,
        bundlePrice: true,
        sellingPriceCents: 1719,
        costPriceCents: 950,
        notes: 'Selling and factory prices are per 20-piece bundle.',
      ),
      const _PvcProduct(
        id: 'pvc_db01_selling_4000',
        code: 'DB01',
        productFamilyId: 'pvc_db01_selling',
        name: 'DB01',
        spec: '23 × 33.3 × 4000 mm',
        widthMm: 33.3,
        thicknessMm: 23,
        lengthMm: 4000,
        sellingPriceCents: 2470,
        notes: 'Authoritative factory-sheet name and dimensions.',
      ),
      const _PvcProduct(
        id: 'pvc_gd_selling_3000',
        code: 'GD',
        productFamilyId: 'pvc_gd_selling',
        name: 'GD 3m',
        spec: '23 × 400 × 3000 mm',
        widthMm: 400,
        thicknessMm: 23,
        lengthMm: 3000,
        sellingPriceCents: 2200,
        notes: 'GD14, GD105, GD125, GD147, and GD309 are design codes.',
      ),
      const _PvcProduct(
        id: 'pvc_last_accessory_3000',
        code: 'ជ្រីខណ្ឌជញ្ជាំង',
        productFamilyId: 'pvc_last_accessory',
        name: 'ជ្រីខណ្ឌជញ្ជាំង',
        spec: '3 m',
        lengthMm: 3000,
        sellingPriceCents: 1000,
        costPriceCents: 800,
        notes: 'Authoritative factory-sheet name.',
      ),
      const _PvcProduct(
        id: 'pvc_image2_row21',
        code: 'វីសបាញ់ក្តារក្រាលបាត',
        productFamilyId: 'pvc_image2_row21',
        name: 'វីសបាញ់ក្តារក្រាលបាត',
        spec: '1000គ្រាប់/កញ្ចប់',
        piecesPerBundle: 1000,
        bundlePrice: true,
        costPriceCents: 380,
        notes: 'Authoritative factory-sheet name and package size.',
      ),
    ]);

    for (final code in const ['DB01', 'DB02', 'DB03', 'DB04', 'DB05']) {
      products.add(
        _PvcProduct(
          id: 'pvc_${code.toLowerCase()}_factory_4000',
          code: code,
          productFamilyId: 'pvc_${code.toLowerCase()}_factory',
          name: code,
          spec: '23 × 33.3 × 4000 mm',
          widthMm: 33.3,
          thicknessMm: 23,
          lengthMm: 4000,
          costPriceCents: 2070,
          notes: 'DB01 through DB05 are design codes.',
        ),
      );
    }

    for (final code in const ['GD14', 'GD105', 'GD125', 'GD147', 'GD309']) {
      for (final entry in const {3000: 1800, 4000: 2350}.entries) {
        products.add(
          _PvcProduct(
            id: 'pvc_${code.toLowerCase()}_${entry.key}',
            code: code,
            productFamilyId: 'pvc_${code.toLowerCase()}',
            name: 'GD ${entry.key ~/ 1000}m',
            spec: '23 × 400 × ${entry.key} mm',
            widthMm: 400,
            thicknessMm: 23,
            lengthMm: entry.key.toDouble(),
            costPriceCents: entry.value,
            notes: 'GD14, GD105, GD125, GD147, and GD309 are design codes.',
          ),
        );
      }
    }

    return products;
  }
}

class _PvcProduct {
  const _PvcProduct({
    required this.id,
    required this.code,
    required this.productFamilyId,
    required this.name,
    required this.spec,
    this.widthMm,
    this.thicknessMm,
    this.lengthMm,
    this.piecesPerBundle,
    this.bundlePrice = false,
    this.sellingPriceCents,
    this.costPriceCents,
    this.wholesalePriceCents = const {},
    required this.notes,
  });

  final String id;
  final String code;
  final String productFamilyId;
  final String name;
  final String spec;
  final double? widthMm;
  final double? thicknessMm;
  final double? lengthMm;
  final int? piecesPerBundle;
  final bool bundlePrice;
  final int? sellingPriceCents;
  final int? costPriceCents;
  final Map<int, int> wholesalePriceCents;
  final String notes;
}

class _PvcSheetRow {
  const _PvcSheetRow({
    required this.row,
    required this.name,
    this.spec = '3 m',
    required this.saleCents,
    this.costCents,
    this.piecesPerBundle,
  });

  final int row;
  final String name;
  final String spec;
  final int saleCents;
  final int? costCents;
  final int? piecesPerBundle;
}

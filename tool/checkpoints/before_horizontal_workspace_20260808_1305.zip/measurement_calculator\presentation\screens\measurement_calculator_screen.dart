import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../../app_state.dart';
import '../../../../core/utils/money_formatter.dart';
import '../../data/measurement_product_catalog.dart';
import '../../data/measurement_quotation_adapter.dart';
import '../../domain/models/measurement_models.dart';
import '../../native/measurement_native_api.dart';
import '../providers/measurement_calculator_controller.dart';

const _surface = Color(0xFF151821);
const _card = Color(0xFF181B24);
const _border = Color(0xFF2A2F3D);
const _primary = Color(0xFF7C8CFF);
const _success = Color(0xFF22C55E);
const _danger = Color(0xFFEF4444);
const _text = Color(0xFFF4F6FA);
const _textSecondary = Color(0xFFA8AFBF);

class MeasurementCalculatorScreen extends StatefulWidget {
  const MeasurementCalculatorScreen({super.key, this.optimizer});

  final MeasurementOptimizer? optimizer;

  @override
  State<MeasurementCalculatorScreen> createState() =>
      _MeasurementCalculatorScreenState();
}

class _MeasurementCalculatorScreenState
    extends State<MeasurementCalculatorScreen> {
  final _length = TextEditingController(text: '6');
  final _width = TextEditingController(text: '4.2');
  MeasurementCalculatorController? _controller;
  List<MeasurementProductFamily> _families = const [];
  MeasurementProductFamily? _selectedFamily;

  MeasurementCalculatorController get controller => _controller!;

  @override
  void initState() {
    super.initState();
    _length.addListener(_roomChanged);
    _width.addListener(_roomChanged);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_controller != null) return;
    final state = context.read<AppState>();
    _families = const MeasurementProductCatalog().build(
      materials: state.materials,
      prices: state.prices,
    );
    _selectedFamily = _families
        .where((family) => family.id == 'pvc_k01')
        .firstOrNull;
    _selectedFamily ??= _families.firstOrNull;
    _controller = MeasurementCalculatorController(
      optimizer: widget.optimizer,
      initialOptions: state.measurementOptions,
      initialVariants: _selectedFamily?.variants ?? state.measurementVariants,
      onOptionsChanged: state.setMeasurementOptions,
    );
  }

  @override
  void dispose() {
    _length
      ..removeListener(_roomChanged)
      ..dispose();
    _width
      ..removeListener(_roomChanged)
      ..dispose();
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return LayoutBuilder(
          builder: (context, constraints) {
            final horizontalPadding = constraints.maxWidth < 720 ? 16.0 : 32.0;
            return ListView(
              padding: EdgeInsets.fromLTRB(
                horizontalPadding,
                28,
                horizontalPadding,
                48,
              ),
              children: [
                Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 900),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _header(),
                        const SizedBox(height: 24),
                        _calculatorCard(),
                        const SizedBox(height: 28),
                        _resultSection(),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _header() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'គណនាសម្ភារៈ PVC',
                style: TextStyle(
                  color: _text,
                  fontSize: 26,
                  height: 1.2,
                  fontWeight: FontWeight.w900,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'បញ្ចូលទំហំបន្ទប់ ជ្រើសផលិតផល ហើយចុចគណនា',
                style: TextStyle(color: _textSecondary, fontSize: 14),
              ),
            ],
          ),
        ),
        const SizedBox(width: 16),
        TextButton.icon(
          key: const ValueKey('measurement-advanced'),
          onPressed: _showAdvancedSettings,
          icon: const Icon(Icons.tune_rounded, size: 18),
          label: const Text('ការកំណត់បន្ថែម'),
        ),
      ],
    );
  }

  Widget _calculatorCard() {
    return _SimpleCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _sectionTitle('1', 'ទំហំបន្ទប់'),
          const SizedBox(height: 14),
          LayoutBuilder(
            builder: (context, constraints) {
              final fields = [
                _roomField(
                  key: const ValueKey('measurement-length-0'),
                  controller: _length,
                  label: 'បណ្ដោយ',
                  textInputAction: TextInputAction.next,
                ),
                _roomField(
                  key: const ValueKey('measurement-width-0'),
                  controller: _width,
                  label: 'ទទឹង',
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _calculate(),
                ),
              ];
              if (constraints.maxWidth < 560) {
                return Column(
                  children: [
                    fields.first,
                    const SizedBox(height: 12),
                    fields.last,
                  ],
                );
              }
              return Row(
                children: [
                  Expanded(child: fields.first),
                  const SizedBox(width: 14),
                  Expanded(child: fields.last),
                ],
              );
            },
          ),
          const SizedBox(height: 14),
          Container(
            key: const ValueKey('measurement-room-area'),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.square_foot_rounded,
                  color: _primary,
                  size: 20,
                ),
                const SizedBox(width: 10),
                const Text(
                  'ផ្ទៃក្រឡា',
                  style: TextStyle(color: _textSecondary),
                ),
                const Spacer(),
                Text(
                  '${_format(_roomArea)} m²',
                  style: const TextStyle(
                    color: _text,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          _sectionTitle('2', 'ជ្រើសរើសផលិតផល'),
          const SizedBox(height: 14),
          if (_families.isEmpty)
            const _InlineMessage(
              color: _danger,
              icon: Icons.inventory_2_outlined,
              text: 'មិនមានផលិតផល PVC ដែលមានទំហំ និងតម្លៃពេញលេញទេ។',
            )
          else ...[
            LayoutBuilder(
              builder: (context, constraints) {
                return DropdownMenu<MeasurementProductFamily>(
                  key: const ValueKey('measurement-product'),
                  width: constraints.maxWidth,
                  initialSelection: _selectedFamily,
                  enableFilter: true,
                  enableSearch: true,
                  requestFocusOnTap: true,
                  leadingIcon: const Icon(Icons.search_rounded),
                  label: const Text('ស្វែងរក ឬជ្រើសផលិតផល'),
                  dropdownMenuEntries: [
                    for (final family in _families)
                      DropdownMenuEntry(
                        value: family,
                        label:
                            '${family.code}  •  ${family.dimensionsLabel}  •  ${family.availabilityLabel}',
                      ),
                  ],
                  onSelected: _selectFamily,
                );
              },
            ),
            if (_selectedFamily != null) ...[
              const SizedBox(height: 12),
              _productSummary(_selectedFamily!),
            ],
          ],
          const SizedBox(height: 24),
          SizedBox(
            height: 56,
            child: FilledButton.icon(
              key: const ValueKey('measurement-calculate'),
              onPressed: controller.isCalculating || _selectedFamily == null
                  ? null
                  : _calculate,
              icon: controller.isCalculating
                  ? const SizedBox.square(
                      dimension: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.calculate_rounded, size: 22),
              label: Text(
                controller.isCalculating ? 'កំពុងគណនា…' : 'គណនា',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          if (controller.error != null) ...[
            const SizedBox(height: 12),
            _InlineMessage(
              color: _danger,
              icon: Icons.error_outline_rounded,
              text: controller.error!,
            ),
          ],
        ],
      ),
    );
  }

  Widget _sectionTitle(String number, String title) {
    return Row(
      children: [
        Container(
          width: 28,
          height: 28,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            color: _primary,
            shape: BoxShape.circle,
          ),
          child: Text(
            number,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: const TextStyle(
            color: _text,
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _roomField({
    required Key key,
    required TextEditingController controller,
    required String label,
    required TextInputAction textInputAction,
    ValueChanged<String>? onSubmitted,
  }) {
    return TextField(
      key: key,
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [_decimalFormatter],
      textInputAction: textInputAction,
      onSubmitted: onSubmitted,
      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
      decoration: InputDecoration(
        labelText: label,
        suffixText: 'm',
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 17,
        ),
      ),
    );
  }

  Widget _productSummary(MeasurementProductFamily family) {
    return Container(
      key: const ValueKey('measurement-product-summary'),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PVC ${family.code}',
            style: const TextStyle(
              color: _text,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            family.dimensionsLabel,
            style: const TextStyle(color: _textSecondary),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final variant in family.variants)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: _primary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${_format(variant.lengthMm / 1000)}m  •  ${MoneyFormatter.money(variant.unitPrice)} / សន្លឹក',
                    style: const TextStyle(
                      color: _text,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _resultSection() {
    final result = controller.optimizationResult;
    final candidate = result?.selectedCandidate;
    if (candidate == null || _selectedFamily == null) {
      return _SimpleCard(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 30),
          child: Column(
            children: [
              Icon(
                Icons.receipt_long_outlined,
                color: _textSecondary.withValues(alpha: 0.7),
                size: 34,
              ),
              const SizedBox(height: 10),
              const Text(
                'លទ្ធផលនឹងបង្ហាញនៅទីនេះ',
                style: TextStyle(color: _textSecondary),
              ),
            ],
          ),
        ),
      );
    }
    final family = _selectedFamily!;
    final variantsById = {
      for (final variant in family.variants) variant.variantId: variant,
    };
    final quantities =
        candidate.quantities
            .where(
              (quantity) =>
                  quantity.purchaseQuantity > 0 &&
                  variantsById[quantity.variantId] != null,
            )
            .toList()
          ..sort((a, b) => b.variantId.compareTo(a.variantId));

    return Container(
      key: const ValueKey('measurement-result'),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _success.withValues(alpha: 0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              color: _success.withValues(alpha: 0.1),
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(20),
              ),
            ),
            child: const Row(
              children: [
                Icon(Icons.check_circle_rounded, color: _success),
                SizedBox(width: 10),
                Text(
                  'ណែនាំ',
                  style: TextStyle(
                    color: _success,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _resultInfo(
                  'បន្ទប់',
                  '${_clean(_length.text)}m × ${_clean(_width.text)}m  =  ${_format(_roomArea)} m²',
                ),
                const SizedBox(height: 16),
                _resultInfo(
                  'ផលិតផល',
                  'PVC ${family.code}\n${family.dimensionsLabel}  •  ${family.availabilityLabel}',
                ),
                const Divider(height: 34, color: _border),
                const Text(
                  'ត្រូវប្រើ',
                  style: TextStyle(color: _textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 10),
                for (final quantity in quantities) ...[
                  _quantityRow(
                    variantsById[quantity.variantId]!,
                    quantity.purchaseQuantity,
                  ),
                  const SizedBox(height: 8),
                ],
                const Divider(height: 32, color: _border),
                _totalRow(
                  'សរុបសន្លឹក',
                  '${candidate.purchasePieceCount} សន្លឹក',
                ),
                const SizedBox(height: 12),
                _totalRow(
                  'តម្លៃសរុប',
                  MoneyFormatter.money(candidate.totalCost),
                  emphasize: true,
                ),
                if (candidate.wasteAreaM2 > 0.005) ...[
                  const SizedBox(height: 12),
                  _totalRow(
                    'សល់ / កាត់',
                    '${_format(candidate.wasteAreaM2)} m²',
                  ),
                ],
                if (candidate.jointCount > 0) ...[
                  const SizedBox(height: 12),
                  Text(
                    'ផែនការនេះមានតំណ ${candidate.jointCount} កន្លែង ដើម្បីកាត់បន្ថយសំណល់។',
                    style: const TextStyle(color: _textSecondary, fontSize: 13),
                  ),
                ],
                const SizedBox(height: 22),
                SizedBox(
                  height: 50,
                  child: OutlinedButton.icon(
                    key: const ValueKey('measurement-add-quotation'),
                    onPressed: () => _addToQuotation(candidate),
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text(
                      'បង្កើតវិក្កយបត្រ',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _resultInfo(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(color: _textSecondary, fontSize: 13),
        ),
        const SizedBox(height: 5),
        Text(
          value,
          style: const TextStyle(
            color: _text,
            fontSize: 16,
            height: 1.45,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }

  Widget _quantityRow(MeasurementProductVariant variant, int quantity) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Text(
            '${_format(variant.lengthMm / 1000)}m',
            style: const TextStyle(
              color: _text,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            '${MoneyFormatter.money(variant.unitPrice)} / សន្លឹក',
            style: const TextStyle(color: _textSecondary, fontSize: 13),
          ),
          const Spacer(),
          Text(
            '$quantity សន្លឹក',
            style: const TextStyle(
              color: _text,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _totalRow(String label, String value, {bool emphasize = false}) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: emphasize ? _text : _textSecondary,
              fontSize: emphasize ? 16 : 14,
              fontWeight: emphasize ? FontWeight.w800 : FontWeight.w500,
            ),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: emphasize ? _success : _text,
            fontSize: emphasize ? 24 : 16,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Future<void> _calculate() async {
    final family = _selectedFamily;
    if (family == null || controller.isCalculating) return;
    FocusScope.of(context).unfocus();
    controller.setVariants(family.variants);
    await controller.calculateDimensions([
      MeasurementRoom(
        id: 1,
        name: 'បន្ទប់',
        lengthM: _parse(_length.text) ?? 0,
        widthM: _parse(_width.text) ?? 0,
      ),
    ]);
  }

  void _selectFamily(MeasurementProductFamily? family) {
    if (family == null || family.id == _selectedFamily?.id) return;
    setState(() => _selectedFamily = family);
    controller.setVariants(family.variants);
    controller.clearResult();
  }

  void _roomChanged() {
    if (!mounted) return;
    _controller?.clearResult();
    setState(() {});
  }

  void _addToQuotation(MeasurementCandidate candidate) {
    final state = context.read<AppState>();
    final lines = const MeasurementQuotationAdapter().createLines(
      state: state,
      candidate: candidate,
      variants: controller.variants,
    );
    state.addTemporarySaleResults(lines);
    final added = lines.where((line) => line.canAddToTemporarySale).length;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('បានបញ្ចូល $added មុខទៅវិក្កយបត្រ។')),
    );
  }

  Future<void> _showAdvancedSettings() {
    return showDialog<void>(
      context: context,
      builder: (context) => _AdvancedSettingsDialog(
        controller: controller,
        onChanged: (options) {
          controller.setOptions(options);
          controller.clearResult();
        },
      ),
    );
  }

  double get _roomArea {
    final length = _parse(_length.text) ?? 0;
    final width = _parse(_width.text) ?? 0;
    final area = length * width;
    return area.isFinite && area > 0 ? area : 0;
  }

  double? _parse(String value) =>
      double.tryParse(value.trim().replaceAll(',', '.'));

  String _clean(String value) => value.trim().replaceAll(',', '.');

  String _format(double value) => MoneyFormatter.decimal(value);
}

class _AdvancedSettingsDialog extends StatelessWidget {
  const _AdvancedSettingsDialog({
    required this.controller,
    required this.onChanged,
  });

  final MeasurementCalculatorController controller;
  final ValueChanged<MeasurementOptimizationOptions> onChanged;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final options = controller.options;
        return AlertDialog(
          title: const Text('ការកំណត់បន្ថែម'),
          content: SizedBox(
            width: 430,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'កម្មវិធីបានជ្រើសតម្លៃសមស្របសម្រាប់ការលក់ប្រចាំថ្ងៃរួចហើយ។',
                    style: TextStyle(color: _textSecondary),
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<MeasurementOptimizeFor>(
                    key: const ValueKey('measurement-optimize-for'),
                    initialValue: options.optimizeFor,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'អាទិភាព'),
                    items: const [
                      DropdownMenuItem(
                        value: MeasurementOptimizeFor.lowestWaste,
                        child: Text('សំណល់តិច បន្ទាប់មកតម្លៃទាប'),
                      ),
                      DropdownMenuItem(
                        value: MeasurementOptimizeFor.lowestCost,
                        child: Text('តម្លៃទាប បន្ទាប់មកសំណល់តិច'),
                      ),
                      DropdownMenuItem(
                        value: MeasurementOptimizeFor.fewestJoints,
                        child: Text('តំណតិចជាងគេ'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        onChanged(options.copyWith(optimizeFor: value));
                      }
                    },
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('អនុញ្ញាតតំណ'),
                    value: options.allowJoints,
                    onChanged: (value) =>
                        onChanged(options.copyWith(allowJoints: value)),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('ប្រើសំណល់កាត់ឡើងវិញ'),
                    value: options.reuseOffcuts,
                    onChanged: (value) =>
                        onChanged(options.copyWith(reuseOffcuts: value)),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'សម្ភារៈបម្រុង ${options.sparePercent.toStringAsFixed(0)}%',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  Slider(
                    value: options.sparePercent.clamp(0, 10),
                    min: 0,
                    max: 10,
                    divisions: 10,
                    label: '${options.sparePercent.toStringAsFixed(0)}%',
                    onChanged: (value) =>
                        onChanged(options.copyWith(sparePercent: value)),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('រួចរាល់'),
            ),
          ],
        );
      },
    );
  }
}

class _SimpleCard extends StatelessWidget {
  const _SimpleCard({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
      ),
      child: child,
    );
  }
}

class _InlineMessage extends StatelessWidget {
  const _InlineMessage({
    required this.color,
    required this.icon,
    required this.text,
  });

  final Color color;
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text, style: const TextStyle(color: _text)),
          ),
        ],
      ),
    );
  }
}

final _decimalFormatter = FilteringTextInputFormatter.allow(
  RegExp(r'[-0-9.,]'),
);

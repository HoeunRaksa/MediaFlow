import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:material_quote_pro/app_state.dart';
import 'package:material_quote_pro/features/materials/data/seed/default_material_seed.dart';
import 'package:material_quote_pro/features/measurement_calculator/domain/models/measurement_models.dart';
import 'package:material_quote_pro/features/measurement_calculator/native/measurement_native_api.dart';
import 'package:material_quote_pro/features/measurement_calculator/presentation/screens/measurement_calculator_screen.dart';
import 'package:provider/provider.dart';

void main() {
  testWidgets(
    'main workflow only shows room, product, and calculate controls',
    (tester) async {
      final state = _seededState();
      await _pump(tester, state: state, optimizer: _SimpleOptimizer());

      expect(find.text('គណនាសម្ភារៈ PVC'), findsOneWidget);
      expect(
        find.byKey(const ValueKey('measurement-length-0')),
        findsOneWidget,
      );
      expect(find.byKey(const ValueKey('measurement-width-0')), findsOneWidget);
      expect(find.byKey(const ValueKey('measurement-product')), findsOneWidget);
      expect(
        find.byKey(const ValueKey('measurement-calculate')),
        findsOneWidget,
      );
      expect(find.text('PVC K-01'), findsOneWidget);
      expect(find.textContaining(r'$6.70'), findsOneWidget);
      expect(find.textContaining(r'$8.60'), findsOneWidget);

      expect(find.text('របៀបបញ្ចូល'), findsNothing);
      expect(find.text('ទទឹង', skipOffstage: false), findsOneWidget);
      expect(find.text('កម្រាស់', skipOffstage: false), findsNothing);
      expect(find.text('បន្ថែមទំហំស្តុក'), findsNothing);
      expect(find.text('អនុញ្ញាតតំណ'), findsNothing);

      await tester.enterText(
        find.byKey(const ValueKey('measurement-length-0')),
        '7',
      );
      await tester.enterText(
        find.byKey(const ValueKey('measurement-width-0')),
        '4',
      );
      await tester.pump();
      expect(find.text('28 m²'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('calculate uses database variants and shows a simple result', (
    tester,
  ) async {
    final optimizer = _SimpleOptimizer();
    final state = _seededState();
    await _pump(tester, state: state, optimizer: optimizer);

    await tester.tap(find.byKey(const ValueKey('measurement-calculate')));
    await tester.pumpAndSettle();

    expect(optimizer.lastRequest, isNotNull);
    expect(optimizer.lastRequest!.rooms.single.areaM2, closeTo(25.2, 0.0001));
    expect(optimizer.lastRequest!.variants, hasLength(2));
    expect(
      optimizer.lastRequest!.variants.map((variant) => variant.unitPrice),
      [6.70, 8.60],
    );
    expect(
      optimizer.lastRequest!.variants.map((variant) => variant.materialId),
      ['pvc_k01_3000', 'pvc_k01_4000'],
    );

    expect(find.byKey(const ValueKey('measurement-result')), findsOneWidget);
    expect(find.text('ណែនាំ'), findsOneWidget);
    expect(find.text('22 សន្លឹក'), findsOneWidget);
    expect(find.text(r'$168.30'), findsOneWidget);
    expect(find.text('5.6 m²'), findsOneWidget);

    final invoice = find.byKey(const ValueKey('measurement-add-quotation'));
    await tester.scrollUntilVisible(
      invoice,
      400,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pump();
    await tester.tap(invoice);
    await tester.pump();
    expect(state.currentSaleItems, hasLength(2));
    expect(state.currentSaleItems.map((line) => line.materialId), [
      'pvc_k01_3000',
      'pvc_k01_4000',
    ]);
    expect(state.temporarySaleSummary.customerPayTotal, 168.30);
    expect(tester.takeException(), isNull);
  });

  testWidgets('advanced controls stay behind one small button', (tester) async {
    final state = _seededState();
    await _pump(tester, state: state, optimizer: _SimpleOptimizer());

    expect(find.text('អនុញ្ញាតតំណ'), findsNothing);
    expect(find.text('ប្រើសំណល់កាត់ឡើងវិញ'), findsNothing);

    await tester.tap(find.byKey(const ValueKey('measurement-advanced')));
    await tester.pumpAndSettle();

    expect(find.text('អនុញ្ញាតតំណ'), findsOneWidget);
    expect(find.text('ប្រើសំណល់កាត់ឡើងវិញ'), findsOneWidget);
    expect(
      find.byKey(const ValueKey('measurement-optimize-for')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('centered workflow remains overflow-free in a compact window', (
    tester,
  ) async {
    final state = _seededState();
    await _pump(
      tester,
      state: state,
      optimizer: _SimpleOptimizer(),
      size: const Size(700, 760),
    );

    await tester.drag(find.byType(ListView), const Offset(0, -500));
    await tester.pump();
    expect(find.byKey(const ValueKey('measurement-calculate')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}

AppState _seededState() {
  final now = DateTime.utc(2026, 8, 8);
  return AppState()
    ..isLoading = false
    ..materials = DefaultMaterialSeed.materials(now)
    ..prices = DefaultMaterialSeed.prices(now)
    ..packagingRules = DefaultMaterialSeed.packagingRules(now)
    ..productTemplates = DefaultMaterialSeed.productTypeTemplates();
}

Future<void> _pump(
  WidgetTester tester, {
  required AppState state,
  required MeasurementOptimizer optimizer,
  Size size = const Size(1440, 900),
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  addTearDown(state.dispose);
  await tester.pumpWidget(
    ChangeNotifierProvider.value(
      value: state,
      child: MaterialApp(
        theme: ThemeData.dark(useMaterial3: true),
        home: Scaffold(body: MeasurementCalculatorScreen(optimizer: optimizer)),
      ),
    ),
  );
  await tester.pump();
}

class _SimpleOptimizer implements MeasurementOptimizer {
  MeasurementOptimizationRequest? lastRequest;

  @override
  Future<MeasurementOptimizationResult> optimize(
    MeasurementOptimizationRequest request,
  ) async {
    lastRequest = request;
    return const MeasurementOptimizationResult(
      status: MeasurementStatus.ok,
      selectedCandidateIndex: 0,
      candidates: [
        MeasurementCandidate(
          candidateId: 3,
          valid: true,
          stockMode: MeasurementStockMode.mixed,
          singleVariantId: null,
          quantities: [
            MeasurementVariantQuantity(
              variantId: 3000,
              baseQuantity: 11,
              reserveQuantity: 0,
              purchaseQuantity: 11,
            ),
            MeasurementVariantQuantity(
              variantId: 4000,
              baseQuantity: 11,
              reserveQuantity: 0,
              purchaseQuantity: 11,
            ),
          ],
          cuts: [],
          roomLayouts: [],
          basePieceCount: 22,
          reservePieceCount: 0,
          purchasePieceCount: 22,
          jointCount: 0,
          requiredAreaM2: 25.2,
          purchasedAreaM2: 30.8,
          wasteAreaM2: 5.6,
          wastePercent: 18.182,
          totalCost: 168.30,
          score: 5.6,
        ),
      ],
      diagnostics: MeasurementDiagnostics(
        candidatesConsidered: 3,
        candidatesPruned: 0,
        executionTimeUs: 10,
        cuts: 22,
        offcutsCreated: 0,
        offcutsReused: 0,
      ),
    );
  }
}

import '../../../app_state.dart';
import '../../materials/domain/product_sale_models.dart';
import '../domain/models/measurement_models.dart';

class MeasurementQuotationAdapter {
  const MeasurementQuotationAdapter();

  List<ProductSaleResult> createLines({
    required AppState state,
    required MeasurementCandidate candidate,
    required List<MeasurementProductVariant> variants,
  }) {
    final variantsById = {
      for (final variant in variants) variant.variantId: variant,
    };
    return [
      for (final quantity in candidate.quantities)
        if (quantity.purchaseQuantity > 0 &&
            variantsById[quantity.variantId] != null)
          state.calculateProductSale(
            ProductSaleInput(
              productKindId: 'ceiling_material_only',
              materialId:
                  variantsById[quantity.variantId]!.materialId ?? 'ceiling_6mm',
              inputMethodId: InputMethodIds.manualQuantity,
              chargeMethodId: ChargeMethodIds.unitOnly,
              manualQuantity: quantity.purchaseQuantity,
              saleUnitPrice:
                  variantsById[quantity.variantId]!.materialId == null
                  ? variantsById[quantity.variantId]!.unitPrice
                  : null,
              costUnitPrice:
                  variantsById[quantity.variantId]!.materialId == null
                  ? variantsById[quantity.variantId]!.unitPrice
                  : null,
              displaySpec: variantsById[quantity.variantId]!.label,
              useSavedPriceAsDefault: true,
              allowSaleBelowCost: state.allowSaleBelowCost,
            ),
          ),
    ];
  }

  List<ProductSaleResult> createAreaLines({
    required AppState state,
    required AreaCoverageCandidate candidate,
    required List<MeasurementProductVariant> variants,
  }) {
    final variant = variants
        .where((item) => item.variantId == candidate.variantId)
        .firstOrNull;
    if (variant == null || candidate.purchaseQuantity <= 0) {
      return const [];
    }
    return [
      state.calculateProductSale(
        ProductSaleInput(
          productKindId: 'ceiling_material_only',
          materialId: 'ceiling_6mm',
          inputMethodId: InputMethodIds.manualQuantity,
          chargeMethodId: ChargeMethodIds.unitOnly,
          manualQuantity: candidate.purchaseQuantity,
          saleUnitPrice: variant.unitPrice,
          costUnitPrice: variant.unitPrice,
          displaySpec: '${variant.label} • ប៉ាន់ស្មានតាម m²',
          useSavedPriceAsDefault: false,
          allowSaleBelowCost: state.allowSaleBelowCost,
        ),
      ),
    ];
  }
}

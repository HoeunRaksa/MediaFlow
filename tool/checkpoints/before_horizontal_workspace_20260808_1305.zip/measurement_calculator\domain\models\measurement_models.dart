enum MeasurementInputMode { dimensions, areaOnly, smartText }

enum MeasurementOptimizeFor { lowestCost, lowestWaste, fewestJoints }

enum MeasurementOrientation { alongLength, alongWidth }

enum MeasurementStockMode { single, mixed }

enum MeasurementStatus {
  ok,
  invalidArgument,
  noSolution,
  limitExceeded,
  outOfMemory,
  internalError;

  factory MeasurementStatus.fromCode(int code) {
    return switch (code) {
      0 => MeasurementStatus.ok,
      1 => MeasurementStatus.invalidArgument,
      2 => MeasurementStatus.noSolution,
      3 => MeasurementStatus.limitExceeded,
      4 => MeasurementStatus.outOfMemory,
      _ => MeasurementStatus.internalError,
    };
  }
}

class MeasurementRoom {
  const MeasurementRoom({
    required this.id,
    required this.name,
    required this.lengthM,
    required this.widthM,
  });

  final int id;
  final String name;
  final double lengthM;
  final double widthM;

  double get areaM2 => lengthM * widthM;
}

class MeasurementProductVariant {
  const MeasurementProductVariant({
    required this.variantId,
    required this.label,
    required this.widthMm,
    required this.lengthMm,
    required this.thicknessMm,
    required this.unitPrice,
    this.materialId,
    this.productFamilyId,
    this.productCode,
  });

  final int variantId;
  final String label;
  final double widthMm;
  final double lengthMm;
  final double thicknessMm;
  final double unitPrice;
  final String? materialId;
  final String? productFamilyId;
  final String? productCode;

  double get areaM2 => widthMm * lengthMm / 1000000;
}

class MeasurementProductDefaults {
  const MeasurementProductDefaults._();

  static const variants = [
    MeasurementProductVariant(
      variantId: 3000,
      label: '400 × 10 × 3000 mm',
      widthMm: 400,
      lengthMm: 3000,
      thicknessMm: 10,
      unitPrice: 9,
    ),
    MeasurementProductVariant(
      variantId: 4000,
      label: '400 × 10 × 4000 mm',
      widthMm: 400,
      lengthMm: 4000,
      thicknessMm: 10,
      unitPrice: 12,
    ),
  ];
}

class MeasurementOptimizationOptions {
  const MeasurementOptimizationOptions({
    this.optimizeFor = MeasurementOptimizeFor.lowestWaste,
    this.allowJoints = true,
    this.reuseOffcuts = true,
    this.projectMode = true,
    this.sparePercent = 0,
    this.debugDiagnostics = false,
    this.maxSearchCandidates = 200000,
  });

  final MeasurementOptimizeFor optimizeFor;
  final bool allowJoints;
  final bool reuseOffcuts;
  final bool projectMode;
  final double sparePercent;
  final bool debugDiagnostics;
  final int maxSearchCandidates;

  MeasurementOptimizationOptions copyWith({
    MeasurementOptimizeFor? optimizeFor,
    bool? allowJoints,
    bool? reuseOffcuts,
    bool? projectMode,
    double? sparePercent,
    bool? debugDiagnostics,
    int? maxSearchCandidates,
  }) {
    return MeasurementOptimizationOptions(
      optimizeFor: optimizeFor ?? this.optimizeFor,
      allowJoints: allowJoints ?? this.allowJoints,
      reuseOffcuts: reuseOffcuts ?? this.reuseOffcuts,
      projectMode: projectMode ?? this.projectMode,
      sparePercent: sparePercent ?? this.sparePercent,
      debugDiagnostics: debugDiagnostics ?? this.debugDiagnostics,
      maxSearchCandidates: maxSearchCandidates ?? this.maxSearchCandidates,
    );
  }
}

class MeasurementOptimizationRequest {
  const MeasurementOptimizationRequest({
    required this.rooms,
    required this.variants,
    required this.options,
  });

  final List<MeasurementRoom> rooms;
  final List<MeasurementProductVariant> variants;
  final MeasurementOptimizationOptions options;
}

class MeasurementVariantQuantity {
  const MeasurementVariantQuantity({
    required this.variantId,
    required this.baseQuantity,
    required this.reserveQuantity,
    required this.purchaseQuantity,
  });

  final int variantId;
  final int baseQuantity;
  final int reserveQuantity;
  final int purchaseQuantity;
}

class MeasurementCutSegment {
  const MeasurementCutSegment({
    required this.roomId,
    required this.laneIndex,
    required this.sourceVariantId,
    required this.sourcePieceIndex,
    required this.segmentIndex,
    required this.sourceLengthMm,
    required this.usedLengthMm,
    required this.remainderLengthMm,
    required this.reusedOffcut,
  });

  final int roomId;
  final int laneIndex;
  final int sourceVariantId;
  final int sourcePieceIndex;
  final int segmentIndex;
  final double sourceLengthMm;
  final double usedLengthMm;
  final double remainderLengthMm;
  final bool reusedOffcut;
}

class MeasurementRoomLayout {
  const MeasurementRoomLayout({
    required this.roomId,
    required this.orientation,
    required this.laneCount,
    required this.longitudinalSpanMm,
    required this.crossSpanMm,
  });

  final int roomId;
  final MeasurementOrientation orientation;
  final int laneCount;
  final double longitudinalSpanMm;
  final double crossSpanMm;
}

class MeasurementCandidate {
  const MeasurementCandidate({
    required this.candidateId,
    required this.valid,
    required this.stockMode,
    required this.singleVariantId,
    required this.quantities,
    required this.cuts,
    required this.roomLayouts,
    required this.basePieceCount,
    required this.reservePieceCount,
    required this.purchasePieceCount,
    required this.jointCount,
    required this.requiredAreaM2,
    required this.purchasedAreaM2,
    required this.wasteAreaM2,
    required this.wastePercent,
    required this.totalCost,
    required this.score,
  });

  final int candidateId;
  final bool valid;
  final MeasurementStockMode stockMode;
  final int? singleVariantId;
  final List<MeasurementVariantQuantity> quantities;
  final List<MeasurementCutSegment> cuts;
  final List<MeasurementRoomLayout> roomLayouts;
  final int basePieceCount;
  final int reservePieceCount;
  final int purchasePieceCount;
  final int jointCount;
  final double requiredAreaM2;
  final double purchasedAreaM2;
  final double wasteAreaM2;
  final double wastePercent;
  final double totalCost;
  final double score;
}

class MeasurementDiagnostics {
  const MeasurementDiagnostics({
    required this.candidatesConsidered,
    required this.candidatesPruned,
    required this.executionTimeUs,
    required this.cuts,
    required this.offcutsCreated,
    required this.offcutsReused,
  });

  final int candidatesConsidered;
  final int candidatesPruned;
  final int executionTimeUs;
  final int cuts;
  final int offcutsCreated;
  final int offcutsReused;
}

class MeasurementOptimizationResult {
  const MeasurementOptimizationResult({
    required this.status,
    required this.selectedCandidateIndex,
    required this.candidates,
    required this.diagnostics,
  });

  final MeasurementStatus status;
  final int selectedCandidateIndex;
  final List<MeasurementCandidate> candidates;
  final MeasurementDiagnostics diagnostics;

  MeasurementCandidate? get selectedCandidate {
    if (selectedCandidateIndex < 0 ||
        selectedCandidateIndex >= candidates.length) {
      return null;
    }
    return candidates[selectedCandidateIndex];
  }
}

class AreaCoverageCandidate {
  const AreaCoverageCandidate({
    required this.variantId,
    required this.baseQuantity,
    required this.reserveQuantity,
    required this.purchaseQuantity,
    required this.requiredAreaM2,
    required this.purchasedAreaM2,
    required this.wasteAreaM2,
    required this.wastePercent,
    required this.totalCost,
  });

  final int variantId;
  final int baseQuantity;
  final int reserveQuantity;
  final int purchaseQuantity;
  final double requiredAreaM2;
  final double purchasedAreaM2;
  final double wasteAreaM2;
  final double wastePercent;
  final double totalCost;
}

class AreaCoverageResult {
  const AreaCoverageResult({
    required this.candidates,
    required this.selectedCandidateIndex,
  });

  final List<AreaCoverageCandidate> candidates;
  final int selectedCandidateIndex;

  AreaCoverageCandidate get selectedCandidate =>
      candidates[selectedCandidateIndex];
}

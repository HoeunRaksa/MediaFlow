import '../../../../core/constants/business_ids.dart';
import '../models/material_item.dart';
import '../models/material_price.dart';
import '../models/material_quantity_price_tier.dart';
import '../models/packaging_rule.dart';

class PvcMaterialIds {
  const PvcMaterialIds._();

  static const k01_3000 = 'pvc_k01_3000';
  static const k01_4000 = 'pvc_k01_4000';
  static const p01_3000 = 'pvc_p01_3000';
  static const p01_4000 = 'pvc_p01_4000';
  static const cLine023_4000 = 'pvc_c_line_023_4000';
  static const cLine027_4000 = 'pvc_c_line_027_4000';
}

class PvcCatalogSeed {
  const PvcCatalogSeed._();

  static final DateTime factorySourceDate = DateTime.utc(2026, 5, 16);
  static final DateTime sellingSourceDate = DateTime.utc(2026, 8, 8);

  static List<MaterialItem> materials(DateTime now) {
    final products = _products();
    return [
      for (var index = 0; index < products.length; index++)
        MaterialItem(
          id: products[index].id,
          khmerName: products[index].code,
          englishName: products[index].nameEnglish,
          spec: products[index].spec,
          unitId: 'piece',
          unitKhmer: 'ដើម',
          unitEnglish: 'Piece',
          categoryId: 'pvc',
          categoryKhmer: 'PVC',
          categoryEnglish: 'PVC',
          formulaTypeId: FormulaTypeIds.manualQuantity,
          coverageValue: null,
          multiplierValue: null,
          fixedQuantity: null,
          itemsPerBox: products[index].piecesPerBundle ?? 1,
          active: true,
          includedByDefault: false,
          showInCustomerQuote: products[index].sellingPriceCents != null,
          showInPickList: true,
          isOptionalAddon: true,
          isServiceOnly: false,
          sortOrder: 1000 + index,
          createdAt: now,
          updatedAt: now,
          code: products[index].code,
          productFamilyId: products[index].productFamilyId,
          widthMm: products[index].widthMm,
          thicknessMm: products[index].thicknessMm,
          lengthMm: products[index].lengthMm,
          piecesPerBundle: products[index].piecesPerBundle,
          notes: products[index].notes,
        ),
    ];
  }

  static List<MaterialPrice> prices(DateTime now) {
    final result = <MaterialPrice>[];
    for (final product in _products()) {
      final saleCents = product.sellingPriceCents;
      if (saleCents != null) {
        result.add(
          _price(
            materialId: product.id,
            priceTypeId: product.bundlePrice
                ? PriceTypeIds.saleBoxPrice
                : PriceTypeIds.saleUnitPrice,
            priceCents: saleCents,
            effectiveFrom: sellingSourceDate,
            now: now,
          ),
        );
      }
      final costCents = product.costPriceCents;
      if (costCents != null) {
        result.add(
          _price(
            materialId: product.id,
            priceTypeId: product.bundlePrice
                ? PriceTypeIds.costBoxPrice
                : PriceTypeIds.costUnitPrice,
            priceCents: costCents,
            effectiveFrom: factorySourceDate,
            now: now,
          ),
        );
      }
    }
    return result;
  }

  static List<MaterialQuantityPriceTier> quantityPriceTiers(DateTime now) {
    return [
      for (final product in _products())
        for (final entry in product.wholesalePriceCents.entries)
          MaterialQuantityPriceTier(
            id: '${product.id}_quantity_${entry.key}',
            materialId: product.id,
            minQuantity: entry.key,
            unitPriceCents: entry.value,
            currencyCode: 'USD',
            sourceDate: factorySourceDate,
            active: true,
            createdAt: now,
            updatedAt: now,
          ),
    ];
  }

  static List<PackagingRule> packagingRules(DateTime now) {
    return [
      for (final product in _products())
        if (product.piecesPerBundle != null)
          PackagingRule(
            id: 'packaging_${product.id}',
            materialId: product.id,
            itemsPerBox: product.piecesPerBundle!,
            boxUnitNameKhmer: 'បាច់',
            boxUnitNameEnglish: 'Bundle',
            size: product.spec,
            length: product.lengthMm == null
                ? ''
                : '${product.lengthMm!.toStringAsFixed(0)} mm',
            note: '${product.piecesPerBundle} pieces per bundle',
            active: true,
            updatedAt: now,
          ),
    ];
  }

  static MaterialPrice _price({
    required String materialId,
    required String priceTypeId,
    required int priceCents,
    required DateTime effectiveFrom,
    required DateTime now,
  }) {
    return MaterialPrice(
      id: '${materialId}_$priceTypeId',
      materialId: materialId,
      priceTypeId: priceTypeId,
      price: priceCents / 100,
      priceCents: priceCents,
      currencyCode: 'USD',
      effectiveFrom: effectiveFrom,
      effectiveTo: null,
      active: true,
      createdAt: now,
      updatedAt: now,
    );
  }

  static List<_PvcProduct> _products() {
    final products = <_PvcProduct>[];
    const kCodes = [
      'K-01',
      'K-02',
      'K-03',
      'K-04',
      'K-05',
      'K-06',
      'K-08',
      'K-10',
      'K-11',
      'K-12',
    ];
    const pCodes = ['P-01', 'P-02', 'P-03'];

    void addSeries({
      required List<String> codes,
      required int lengthMm,
      required int sellingPriceCents,
      required int costPriceCents,
      required Map<int, int> wholesalePriceCents,
    }) {
      for (final code in codes) {
        final compactCode = code.toLowerCase().replaceAll('-', '');
        products.add(
          _PvcProduct(
            id: 'pvc_${compactCode}_$lengthMm',
            code: code,
            productFamilyId: 'pvc_$compactCode',
            nameEnglish: '$code PVC Panel',
            spec: '400 × 10 × $lengthMm mm',
            widthMm: 400,
            thicknessMm: 10,
            lengthMm: lengthMm.toDouble(),
            sellingPriceCents: sellingPriceCents,
            costPriceCents: costPriceCents,
            wholesalePriceCents: wholesalePriceCents,
            notes:
                'PVC series variant. Khmer source label could not be verified because the image file was not supplied.',
          ),
        );
      }
    }

    addSeries(
      codes: kCodes,
      lengthMm: 3000,
      sellingPriceCents: 670,
      costPriceCents: 580,
      wholesalePriceCents: const {50: 560, 100: 530, 300: 510, 500: 500},
    );
    addSeries(
      codes: kCodes,
      lengthMm: 4000,
      sellingPriceCents: 860,
      costPriceCents: 770,
      wholesalePriceCents: const {50: 750, 100: 720, 300: 700, 500: 690},
    );
    addSeries(
      codes: pCodes,
      lengthMm: 3000,
      sellingPriceCents: 690,
      costPriceCents: 600,
      wholesalePriceCents: const {50: 580, 100: 550, 300: 530, 500: 520},
    );
    addSeries(
      codes: pCodes,
      lengthMm: 4000,
      sellingPriceCents: 885,
      costPriceCents: 795,
      wholesalePriceCents: const {50: 775, 100: 745, 300: 725, 500: 715},
    );

    products.addAll([
      const _PvcProduct(
        id: 'pvc_image1_row03_160x20x3000',
        code: 'ROW-03',
        productFamilyId: 'pvc_image1_row03',
        nameEnglish: 'PVC Image 1 Row 3',
        spec: '160 × 20 × 3000 mm',
        widthMm: 160,
        thicknessMm: 20,
        lengthMm: 3000,
        sellingPriceCents: 580,
        notes:
            'Selling-list-only specification; kept separate from factory 160 × 22 × 3000 mm. Khmer label unavailable.',
      ),
      const _PvcProduct(
        id: 'pvc_image1_row04_195x3000',
        code: 'ROW-04',
        productFamilyId: 'pvc_image1_row04',
        nameEnglish: 'PVC Image 1 Row 4',
        spec: '195 × 3000 mm (thickness not supplied)',
        widthMm: 195,
        lengthMm: 3000,
        sellingPriceCents: 650,
        notes:
            'Selling-list specification is incomplete and was not merged with factory 195 × 12 × 3000 mm. Khmer label unavailable.',
      ),
      const _PvcProduct(
        id: 'pvc_image1_row05_150x3000',
        code: 'ROW-05',
        productFamilyId: 'pvc_image1_row05',
        nameEnglish: 'PVC Image 1 Row 5',
        spec: '150 × 3000 mm (thickness not supplied)',
        widthMm: 150,
        lengthMm: 3000,
        sellingPriceCents: 550,
        notes:
            'Selling-list-only specification; kept separate from factory 160 × 9 × 3000 mm. Khmer label unavailable.',
      ),
      const _PvcProduct(
        id: 'pvc_factory_160x22x3000',
        code: 'FACTORY-160X22',
        productFamilyId: 'pvc_factory_160x22',
        nameEnglish: 'PVC Factory 160 × 22',
        spec: '160 × 22 × 3000 mm',
        widthMm: 160,
        thicknessMm: 22,
        lengthMm: 3000,
        costPriceCents: 490,
        wholesalePriceCents: {30: 480, 50: 450, 100: 430, 300: 410, 500: 400},
        notes:
            'Factory-list-only specification dated 16/05/2026; not merged with Image 1 row 3.',
      ),
      const _PvcProduct(
        id: 'pvc_factory_195x12x3000',
        code: 'FACTORY-195X12',
        productFamilyId: 'pvc_factory_195x12',
        nameEnglish: 'PVC Factory 195 × 12',
        spec: '195 × 12 × 3000 mm',
        widthMm: 195,
        thicknessMm: 12,
        lengthMm: 3000,
        costPriceCents: 510,
        wholesalePriceCents: {30: 500, 50: 470, 100: 450, 300: 430, 500: 420},
        notes:
            'Factory-list-only complete specification dated 16/05/2026; not merged with incomplete Image 1 row 4.',
      ),
      const _PvcProduct(
        id: 'pvc_factory_160x9x3000',
        code: 'FACTORY-160X9',
        productFamilyId: 'pvc_factory_160x9',
        nameEnglish: 'PVC Factory 160 × 9',
        spec: '160 × 9 × 3000 mm',
        widthMm: 160,
        thicknessMm: 9,
        lengthMm: 3000,
        costPriceCents: 440,
        wholesalePriceCents: {30: 430, 50: 400, 100: 380, 300: 360, 500: 350},
        notes:
            'Factory-list-only specification dated 16/05/2026; not merged with Image 1 row 5.',
      ),
      const _PvcProduct(
        id: 'pvc_v_25x25x3000',
        code: 'V',
        productFamilyId: 'pvc_v',
        nameEnglish: 'PVC V',
        spec: '25 × 25 × 3000 mm',
        widthMm: 25,
        thicknessMm: 25,
        lengthMm: 3000,
        sellingPriceCents: 350,
        costPriceCents: 250,
        notes: 'Khmer source label unavailable; exact code V retained.',
      ),
    ]);

    const rowSales = {
      7: 550,
      8: 550,
      9: 550,
      10: 400,
      11: 400,
      12: 420,
      13: 550,
      14: 600,
      16: 400,
      17: 400,
      18: 460,
    };
    const rowCosts = {
      7: 430,
      8: 430,
      9: 430,
      10: 280,
      11: 280,
      12: 280,
      13: 280,
      14: 320,
      17: 260,
    };
    for (final entry in rowSales.entries) {
      final row = entry.key;
      final isHundredPieceBundle = row == 13 || row == 14;
      products.add(
        _PvcProduct(
          id: 'pvc_image1_row${row.toString().padLeft(2, '0')}',
          code: 'ROW-${row.toString().padLeft(2, '0')}',
          productFamilyId: 'pvc_image1_row${row.toString().padLeft(2, '0')}',
          nameEnglish: 'PVC Image 1 Row $row',
          spec: isHundredPieceBundle ? '100 pieces' : '3 m',
          lengthMm: isHundredPieceBundle ? null : 3000,
          piecesPerBundle: isHundredPieceBundle ? 100 : null,
          bundlePrice: isHundredPieceBundle,
          sellingPriceCents: entry.value,
          costPriceCents: rowCosts[row],
          notes:
              'Source row retained because the attached image and exact Khmer label were unavailable.',
        ),
      );
    }

    products.addAll([
      const _PvcProduct(
        id: 'pvc_image2_100_piece_accessory',
        code: 'FACTORY-100PCS',
        productFamilyId: 'pvc_image2_100_piece_accessory',
        nameEnglish: 'PVC Factory 100-piece Accessory',
        spec: '100 pieces',
        piecesPerBundle: 100,
        bundlePrice: true,
        costPriceCents: 400,
        notes:
            'Factory-only 100-piece accessory; not merged with Image 1 rows 13 or 14 without the source image.',
      ),
      const _PvcProduct(
        id: 'pvc_glue',
        code: 'GLUE',
        productFamilyId: 'pvc_glue',
        nameEnglish: 'PVC Glue',
        spec: '',
        sellingPriceCents: 450,
        costPriceCents: 250,
        notes: 'Exact Khmer source label unavailable.',
      ),
      const _PvcProduct(
        id: PvcMaterialIds.cLine023_4000,
        code: 'C.LINE-0.23',
        productFamilyId: 'pvc_c_line_023',
        nameEnglish: 'C.Line 0.23',
        spec: '0.23 × 4 m; 20 pieces per bundle',
        lengthMm: 4000,
        piecesPerBundle: 20,
        bundlePrice: true,
        sellingPriceCents: 1624,
        costPriceCents: 850,
        notes: 'Selling and factory prices are per 20-piece bundle.',
      ),
      const _PvcProduct(
        id: PvcMaterialIds.cLine027_4000,
        code: 'C.LINE-0.27',
        productFamilyId: 'pvc_c_line_027',
        nameEnglish: 'C.Line 0.27',
        spec: '0.27 × 4 m; 20 pieces per bundle',
        lengthMm: 4000,
        piecesPerBundle: 20,
        bundlePrice: true,
        sellingPriceCents: 1719,
        costPriceCents: 950,
        notes: 'Selling and factory prices are per 20-piece bundle.',
      ),
      const _PvcProduct(
        id: 'pvc_db01_selling_4000',
        code: 'DB01',
        productFamilyId: 'pvc_db01_selling',
        nameEnglish: 'DB01 Selling-list Variant',
        spec: '23 × 333 × 4000 mm',
        widthMm: 333,
        thicknessMm: 23,
        lengthMm: 4000,
        sellingPriceCents: 2470,
        notes:
            'Selling-list dimension retained separately from factory 23 × 33.3 × 4000 mm.',
      ),
      const _PvcProduct(
        id: 'pvc_gd_selling_3000',
        code: 'GD',
        productFamilyId: 'pvc_gd_selling',
        nameEnglish: 'GD Selling-list Variant',
        spec: '23 × 400 × 3000 mm',
        widthMm: 400,
        thicknessMm: 23,
        lengthMm: 3000,
        sellingPriceCents: 2200,
        notes:
            'Generic selling-list GD retained separately from coded factory GD variants.',
      ),
      const _PvcProduct(
        id: 'pvc_last_accessory_3000',
        code: 'LAST-ACCESSORY',
        productFamilyId: 'pvc_last_accessory',
        nameEnglish: 'PVC Last Accessory',
        spec: '3 m',
        lengthMm: 3000,
        sellingPriceCents: 1000,
        costPriceCents: 800,
        notes:
            'Source-list position retained because the exact Khmer label was unavailable.',
      ),
      const _PvcProduct(
        id: 'pvc_image2_row21',
        code: 'ROW-21',
        productFamilyId: 'pvc_image2_row21',
        nameEnglish: 'PVC Image 2 Row 21',
        spec: '',
        costPriceCents: 380,
        notes:
            'Factory-list-only row 21; no confident selling-list mapping was supplied.',
      ),
    ]);

    for (final code in const ['DB01', 'DB02', 'DB03', 'DB04', 'DB05']) {
      products.add(
        _PvcProduct(
          id: 'pvc_${code.toLowerCase()}_factory_4000',
          code: code,
          productFamilyId: 'pvc_${code.toLowerCase()}_factory',
          nameEnglish: '$code Factory-list Variant',
          spec: '23 × 33.3 × 4000 mm',
          widthMm: 33.3,
          thicknessMm: 23,
          lengthMm: 4000,
          costPriceCents: 2070,
          notes:
              'Factory specification retained exactly as transcribed and kept separate from the DB01 selling-list dimension.',
        ),
      );
    }

    for (final code in const ['GD14', 'GD105', 'GD125', 'GD147', 'GD309']) {
      for (final entry in const {3000: 1800, 4000: 2350}.entries) {
        products.add(
          _PvcProduct(
            id: 'pvc_${code.toLowerCase()}_${entry.key}',
            code: code,
            productFamilyId: 'pvc_${code.toLowerCase()}',
            nameEnglish: '$code Factory-list Variant',
            spec: '23 × 400 × ${entry.key} mm',
            widthMm: 400,
            thicknessMm: 23,
            lengthMm: entry.key.toDouble(),
            costPriceCents: entry.value,
            notes:
                'Coded factory variant retained separately from the generic GD selling-list item.',
          ),
        );
      }
    }

    return products;
  }
}

class _PvcProduct {
  const _PvcProduct({
    required this.id,
    required this.code,
    required this.productFamilyId,
    required this.nameEnglish,
    required this.spec,
    this.widthMm,
    this.thicknessMm,
    this.lengthMm,
    this.piecesPerBundle,
    this.bundlePrice = false,
    this.sellingPriceCents,
    this.costPriceCents,
    this.wholesalePriceCents = const {},
    required this.notes,
  });

  final String id;
  final String code;
  final String productFamilyId;
  final String nameEnglish;
  final String spec;
  final double? widthMm;
  final double? thicknessMm;
  final double? lengthMm;
  final int? piecesPerBundle;
  final bool bundlePrice;
  final int? sellingPriceCents;
  final int? costPriceCents;
  final Map<int, int> wholesalePriceCents;
  final String notes;
}

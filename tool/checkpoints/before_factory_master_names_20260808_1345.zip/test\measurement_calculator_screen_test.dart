import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:material_quote_pro/app_state.dart';
import 'package:material_quote_pro/features/materials/data/seed/default_material_seed.dart';
import 'package:material_quote_pro/features/measurement_calculator/domain/models/measurement_models.dart';
import 'package:material_quote_pro/features/measurement_calculator/native/measurement_native_api.dart';
import 'package:material_quote_pro/features/measurement_calculator/presentation/screens/measurement_calculator_screen.dart';
import 'package:provider/provider.dart';

const _k3ProductId = 'pvc_k_400x10x3000_unit_670_1';
const _k4ProductId = 'pvc_k_400x10x4000_unit_860_1';
const _cLine023ProductId = 'pvc_c_line_0_23_naxnax4000_bundle_1624_20';

void main() {
  testWidgets('desktop workspace uses three fixed horizontal panels', (
    tester,
  ) async {
    final state = _seededState();
    await _pump(tester, state: state, optimizer: _WorkspaceOptimizer());

    expect(find.byKey(const ValueKey('workspace-root')), findsOneWidget);
    expect(find.byKey(const ValueKey('workspace-room-panel')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('workspace-products-panel')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('workspace-result-panel')),
      findsOneWidget,
    );
    expect(find.byType(ListView), findsNothing);
    expect(find.text('K 3m'), findsOneWidget);
    expect(find.text('K 4m'), findsOneWidget);
    expect(find.text('P 3m'), findsOneWidget);
    expect(find.text('P 4m'), findsOneWidget);
    expect(find.text('K-01'), findsNothing);
    expect(find.text('K-05'), findsNothing);
    for (final scrollView in tester.widgetList<SingleChildScrollView>(
      find.byType(SingleChildScrollView),
    )) {
      expect(scrollView.scrollDirection, Axis.horizontal);
    }
    expect(find.text('គណនា'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('selecting products updates the pinned result automatically', (
    tester,
  ) async {
    final optimizer = _WorkspaceOptimizer();
    final state = _seededState();
    await _pump(tester, state: state, optimizer: optimizer);

    await tester.tap(
      find.byKey(const ValueKey('workspace-product-$_k3ProductId')),
    );
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pumpAndSettle();

    expect(optimizer.lastRequest, isNotNull);
    expect(optimizer.lastRequest!.variants, hasLength(1));
    expect(
      optimizer.lastRequest!.variants.map((variant) => variant.unitPrice),
      [6.70],
    );
    expect(find.text(r'$107.20'), findsWidgets);
    expect(
      find.byKey(const ValueKey('workspace-selected-$_k3ProductId')),
      findsOneWidget,
    );

    await tester.tap(
      find.byKey(const ValueKey('workspace-product-$_k4ProductId')),
    );
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pumpAndSettle();

    expect(optimizer.lastRequest!.variants, hasLength(1));
    expect(optimizer.lastRequest!.variants.single.unitPrice, 8.60);
    expect(find.text(r'$244.80'), findsWidgets);
    expect(
      find.byKey(const ValueKey('workspace-selected-$_k4ProductId')),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('workspace-category-cLine')));
    await tester.pump();
    await tester.tap(
      find.byKey(const ValueKey('workspace-product-$_cLine023ProductId')),
    );
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('workspace-selected-$_cLine023ProductId')),
      findsOneWidget,
    );
    expect(find.text(r'$261.04'), findsWidgets);
    expect(find.textContaining('C-Line-0.23'), findsWidgets);

    await tester.tap(find.byKey(const ValueKey('workspace-add-quotation')));
    await tester.pumpAndSettle();
    expect(find.text('Optional color/design'), findsOneWidget);
    expect(state.currentSaleItems, isEmpty);

    await tester.tap(
      find.byKey(const ValueKey('workspace-order-design-$_k3ProductId')),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('K-05').last);
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(const ValueKey('workspace-order-design-continue')),
    );
    await tester.pumpAndSettle();
    expect(state.currentSaleItems, hasLength(3));
    expect(
      state.currentSaleItems.map((item) => item.materialId),
      contains('pvc_k05_3000'),
    );
    expect(
      state.temporarySaleSummary.customerPayTotal,
      closeTo(261.04, 0.0001),
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('rooms and measurements stay in horizontal in-place tabs', (
    tester,
  ) async {
    final state = _seededState();
    await _pump(tester, state: state, optimizer: _WorkspaceOptimizer());

    await tester.tap(find.byKey(const ValueKey('workspace-add-room')));
    await tester.pump();
    expect(find.byKey(const ValueKey('workspace-room-tab-2')), findsOneWidget);
    expect(find.byKey(const ValueKey('workspace-length-2-1')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('workspace-add-measurement')));
    await tester.pump();
    expect(
      find.byKey(const ValueKey('workspace-measurement-tab-2-2')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('workspace-length-2-2')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('workspace-room-tab-1')));
    await tester.pump();
    expect(find.byKey(const ValueKey('workspace-length-1-1')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('selected material opens compact contextual overrides', (
    tester,
  ) async {
    final state = _seededState();
    await _pump(tester, state: state, optimizer: _WorkspaceOptimizer());
    await tester.tap(
      find.byKey(const ValueKey('workspace-product-$_k3ProductId')),
    );
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pumpAndSettle();

    await tester.tap(
      find.byKey(const ValueKey('workspace-selected-$_k3ProductId')),
    );
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('workspace-override-length')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('workspace-override-quantity')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('workspace-override-price')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('workspace-override-waste')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('workspace-override-orientation')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('smaller desktop window keeps horizontal workspace navigation', (
    tester,
  ) async {
    final state = _seededState();
    final previousOnError = FlutterError.onError;
    final errors = <FlutterErrorDetails>[];
    FlutterError.onError = errors.add;
    addTearDown(() => FlutterError.onError = previousOnError);
    await _pump(
      tester,
      state: state,
      optimizer: _WorkspaceOptimizer(),
      size: const Size(1100, 720),
    );

    final workspaceScroll = tester.widget<SingleChildScrollView>(
      find.byKey(const ValueKey('workspace-horizontal-scroll')),
    );
    expect(workspaceScroll.scrollDirection, Axis.horizontal);
    FlutterError.onError = previousOnError;
    expect(
      errors,
      isEmpty,
      reason: errors.map((error) => error.toString()).join('\n\n'),
    );
  });
}

AppState _seededState() {
  final now = DateTime.utc(2026, 8, 8);
  return AppState()
    ..isLoading = false
    ..materials = DefaultMaterialSeed.materials(now)
    ..prices = DefaultMaterialSeed.prices(now)
    ..packagingRules = DefaultMaterialSeed.packagingRules(now)
    ..productTemplates = DefaultMaterialSeed.productTypeTemplates();
}

Future<void> _pump(
  WidgetTester tester, {
  required AppState state,
  required MeasurementOptimizer optimizer,
  Size size = const Size(1920, 1080),
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  addTearDown(state.dispose);
  await tester.pumpWidget(
    ChangeNotifierProvider.value(
      value: state,
      child: MaterialApp(
        theme: ThemeData.dark(useMaterial3: true),
        home: Scaffold(body: MeasurementCalculatorScreen(optimizer: optimizer)),
      ),
    ),
  );
  await tester.pump();
}

class _WorkspaceOptimizer implements MeasurementOptimizer {
  MeasurementOptimizationRequest? lastRequest;

  @override
  Future<MeasurementOptimizationResult> optimize(
    MeasurementOptimizationRequest request,
  ) async {
    lastRequest = request;
    final quantities = request.variants.length == 2
        ? const [
            MeasurementVariantQuantity(
              variantId: 3000,
              baseQuantity: 11,
              reserveQuantity: 0,
              purchaseQuantity: 11,
            ),
            MeasurementVariantQuantity(
              variantId: 4000,
              baseQuantity: 11,
              reserveQuantity: 0,
              purchaseQuantity: 11,
            ),
          ]
        : [
            MeasurementVariantQuantity(
              variantId: request.variants.first.variantId,
              baseQuantity: 16,
              reserveQuantity: 0,
              purchaseQuantity: 16,
            ),
          ];
    final totalCost = quantities.fold<double>(0, (total, quantity) {
      final variant = request.variants.singleWhere(
        (item) => item.variantId == quantity.variantId,
      );
      return total + variant.unitPrice * quantity.purchaseQuantity;
    });
    final area = request.rooms.fold<double>(
      0,
      (total, room) => total + room.areaM2,
    );
    return MeasurementOptimizationResult(
      status: MeasurementStatus.ok,
      selectedCandidateIndex: 0,
      candidates: [
        MeasurementCandidate(
          candidateId: 3,
          valid: true,
          stockMode: request.variants.length == 2
              ? MeasurementStockMode.mixed
              : MeasurementStockMode.single,
          singleVariantId: request.variants.length == 1
              ? request.variants.first.variantId
              : null,
          quantities: quantities,
          cuts: const [],
          roomLayouts: const [],
          basePieceCount: quantities.fold(
            0,
            (total, quantity) => total + quantity.baseQuantity,
          ),
          reservePieceCount: 0,
          purchasePieceCount: quantities.fold(
            0,
            (total, quantity) => total + quantity.purchaseQuantity,
          ),
          jointCount: 0,
          requiredAreaM2: area,
          purchasedAreaM2: area + 5.6,
          wasteAreaM2: 5.6,
          wastePercent: 18.182,
          totalCost: totalCost,
          score: 5.6,
        ),
      ],
      diagnostics: const MeasurementDiagnostics(
        candidatesConsidered: 3,
        candidatesPruned: 0,
        executionTimeUs: 10,
        cuts: 22,
        offcutsCreated: 0,
        offcutsReused: 0,
      ),
    );
  }
}

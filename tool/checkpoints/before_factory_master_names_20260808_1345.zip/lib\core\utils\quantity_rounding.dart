class QuantityRounding {
  const QuantityRounding._();

  static int customerCeil(double value) {
    if (value <= 0) {
      return 0;
    }
    return value.ceil();
  }
}

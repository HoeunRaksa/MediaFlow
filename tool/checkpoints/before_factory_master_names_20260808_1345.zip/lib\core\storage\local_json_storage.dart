import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;

import '../constants/app_constants.dart';
import 'app_data_bootstrapper.dart';

class LocalJsonStorage {
  LocalJsonStorage({
    this.fileName = AppConstants.storageFileName,
    Directory? baseDirectory,
  }) : _baseDirectory = baseDirectory;

  final String fileName;
  final Directory? _baseDirectory;

  static const _collectionFiles = {
    'materials': 'materials.json',
    'prices': 'prices.json',
    'materialQuantityPriceTiers': 'material_quantity_price_tiers.json',
    'packagingRules': 'packaging.json',
    'productTypeTemplates': 'product_kinds.json',
    'pricingTiers': 'settings.json',
    'formulaRules': 'settings.json',
    'units': 'settings.json',
    'categories': 'settings.json',
    'sellModes': 'settings.json',
  };

  Future<Directory> directory() async {
    final dir =
        _baseDirectory ?? await AppDataBootstrapper.defaultDataDirectory();
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  Future<File> _file() async {
    final dir = await directory();
    return File(p.join(dir.path, fileName));
  }

  Future<File> _collectionFile(String key) async {
    final dir = await directory();
    return File(p.join(dir.path, _collectionFiles[key] ?? fileName));
  }

  Future<void> ensureSeeded(Map<String, dynamic> seedData) async {
    for (final entry in seedData.entries) {
      if (_collectionFiles.containsKey(entry.key) && entry.value is List) {
        await _ensureCollectionSeeded(entry.key, entry.value as List<dynamic>);
      }
    }

    final settingsSeed = seedData['settings'];
    if (settingsSeed is Map<String, dynamic>) {
      final current = await readSettings();
      await writeSettings({...settingsSeed, ...current});
    }
  }

  Future<Map<String, dynamic>> readAll() async {
    final result = <String, dynamic>{};
    for (final key in _collectionFiles.keys) {
      result[key] = await readCollection(key);
    }
    result['settings'] = await readSettings();
    final legacyFile = await _file();
    if (await legacyFile.exists()) {
      final text = await legacyFile.readAsString(encoding: utf8);
      if (text.trim().isNotEmpty) {
        final legacy = jsonDecode(text);
        if (legacy is Map) {
          for (final entry in legacy.entries) {
            result.putIfAbsent('${entry.key}', () => entry.value);
          }
        }
      }
    }
    return result;
  }

  Future<void> writeAll(Map<String, dynamic> data) async {
    for (final entry in data.entries) {
      if (_collectionFiles.containsKey(entry.key) && entry.value is List) {
        final collection = (entry.value as List)
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        await writeCollection(entry.key, collection);
      }
    }
    final settings = data['settings'];
    if (settings is Map<String, dynamic>) {
      await writeSettings(settings);
    }
  }

  Future<List<Map<String, dynamic>>> readCollection(String key) async {
    final file = await _collectionFile(key);
    if (!await file.exists()) {
      return const [];
    }
    final decoded = await _readJson(file);
    final collection = decoded is List
        ? decoded
        : decoded is Map
        ? decoded[key] as List<dynamic>? ?? const []
        : const [];
    return collection
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList(growable: false);
  }

  Future<void> writeCollection(
    String key,
    List<Map<String, dynamic>> collection,
  ) async {
    final file = await _collectionFile(key);
    if (_isSettingsBacked(key)) {
      final data = await _readObject(file);
      data[key] = collection;
      await _writeJson(file, data);
      return;
    }
    await _writeJson(file, collection);
  }

  Future<Map<String, dynamic>> readSettings() async {
    final file = await _collectionFile('pricingTiers');
    final data = await _readObject(file);
    return Map<String, dynamic>.from(data['settings'] as Map? ?? const {});
  }

  Future<void> writeSettings(Map<String, dynamic> settings) async {
    final file = await _collectionFile('pricingTiers');
    final data = await _readObject(file);
    data['settings'] = settings;
    await _writeJson(file, data);
  }

  Future<void> _ensureCollectionSeeded(
    String key,
    List<dynamic> incoming,
  ) async {
    final file = await _collectionFile(key);
    if (!await file.exists()) {
      await writeCollection(
        key,
        incoming.map((item) => Map<String, dynamic>.from(item as Map)).toList(),
      );
      return;
    }

    final existing = [...await readCollection(key)];
    final existingIds = <Object?>{
      for (final item in existing)
        if (item['id'] != null) item['id'],
    };
    final missing = incoming
        .where((item) {
          if (item is! Map || item['id'] == null) {
            return false;
          }
          return !existingIds.contains(item['id']);
        })
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList(growable: false);
    if (missing.isNotEmpty) {
      existing.addAll(missing);
    }

    final repaired = key == 'prices'
        ? _repairSeededSalePrices(existing, incoming)
        : existing;
    final migrated = key == 'prices' ? _migratePriceCents(repaired) : repaired;
    if (missing.isNotEmpty || !identical(migrated, existing)) {
      await writeCollection(key, migrated);
    }
  }

  List<Map<String, dynamic>> _repairSeededSalePrices(
    List<Map<String, dynamic>> existing,
    List<dynamic> incoming,
  ) {
    final seedById = <Object?, Map<String, dynamic>>{
      for (final item in incoming)
        if (item is Map && item['id'] != null)
          item['id']: Map<String, dynamic>.from(item),
    };
    var changed = false;
    final nowText = DateTime.now().toIso8601String();
    final repaired = [
      for (final row in existing)
        () {
          final typeId = row['priceTypeId'];
          final isSalePrice =
              typeId == 'sale_unit_price' || typeId == 'sale_box_price';
          final price = (row['price'] as num?)?.toDouble();
          final seedPrice = (seedById[row['id']]?['price'] as num?)?.toDouble();
          if (isSalePrice && price == 0 && seedPrice != null && seedPrice > 0) {
            changed = true;
            final seedPriceCents =
                (seedById[row['id']]?['priceCents'] as num?)?.toInt() ??
                (seedPrice * 100).round();
            return {
              ...row,
              'price': seedPrice,
              'priceCents': seedPriceCents,
              'updatedAt': nowText,
            };
          }
          return row;
        }(),
    ];
    return changed ? repaired : existing;
  }

  List<Map<String, dynamic>> _migratePriceCents(
    List<Map<String, dynamic>> existing,
  ) {
    var changed = false;
    final migrated = [
      for (final row in existing)
        if (row['priceCents'] == null && row['price'] is num)
          () {
            changed = true;
            return {
              ...row,
              'priceCents': ((row['price'] as num).toDouble() * 100).round(),
            };
          }()
        else
          row,
    ];
    return changed ? migrated : existing;
  }

  bool _isSettingsBacked(String key) {
    return _collectionFiles[key] == 'settings.json';
  }

  Future<Map<String, dynamic>> _readObject(File file) async {
    if (!await file.exists()) {
      return {};
    }
    final decoded = await _readJson(file);
    return decoded is Map ? Map<String, dynamic>.from(decoded) : {};
  }

  Future<dynamic> _readJson(File file) async {
    final text = await file.readAsString(encoding: utf8);
    if (text.trim().isEmpty) {
      return null;
    }
    return jsonDecode(text);
  }

  Future<void> _writeJson(File file, Object? value) async {
    final parent = file.parent;
    if (!await parent.exists()) {
      await parent.create(recursive: true);
    }
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(value),
      encoding: utf8,
    );
  }
}

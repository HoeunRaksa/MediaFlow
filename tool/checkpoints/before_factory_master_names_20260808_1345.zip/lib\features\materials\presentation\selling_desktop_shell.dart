import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../app_state.dart';
import '../../../core/constants/business_ids.dart';
import '../../../core/utils/money_formatter.dart';
import '../../../core/utils/packaging_breakdown.dart';
import '../data/models/material_category.dart';
import '../data/models/material_item.dart';
import '../data/models/material_price.dart';
import '../data/models/packaging_rule.dart';
import '../data/models/product_type_template.dart';
import '../data/models/unit_of_measure.dart';
import '../domain/delivery_calculation_engine.dart';
import '../domain/product_sale_models.dart';
import '../../measurement_calculator/presentation/screens/measurement_calculator_screen.dart';

const _bg = Color(0xFF0D0F14);
const _sidebar = Color(0xFF101218);
const _surface = Color(0xFF151821);
const _card = Color(0xFF181B24);
const _border = Color(0xFF2A2F3D);
const _primary = Color(0xFF7C8CFF);
const _secondary = Color(0xFF38BDF8);
const _success = Color(0xFF22C55E);
const _warning = Color(0xFFF59E0B);
const _danger = Color(0xFFEF4444);
const _text = Color(0xFFF4F6FA);
const _textSecondary = Color(0xFFA8AFBF);
const _textMuted = Color(0xFF6B7280);

enum SaleDestination {
  ceiling,
  insulation,
  led,
  wire,
  decoration,
  custom,
  measurement,
  currentSale,
  products,
  prices,
  packaging,
  productKinds,
  formulas,
  unitsCategories,
  appSettings,
}

class SellingDesktopShell extends StatefulWidget {
  const SellingDesktopShell({
    super.key,
    this.initialDestination = SaleDestination.ceiling,
  });

  final SaleDestination initialDestination;

  @override
  State<SellingDesktopShell> createState() => _SellingDesktopShellState();
}

class _SellingDesktopShellState extends State<SellingDesktopShell> {
  late SaleDestination _destination;

  @override
  void initState() {
    super.initState();
    _destination = widget.initialDestination;
  }

  @override
  Widget build(BuildContext context) {
    final meta = _destinationMeta(_destination);
    return Scaffold(
      backgroundColor: _bg,
      body: Row(
        children: [
          _Sidebar(
            destination: _destination,
            onSelected: (value) => setState(() => _destination = value),
          ),
          Expanded(
            child: Column(
              children: [
                _TopHeader(meta: meta),
                Expanded(child: _body(_destination)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _body(SaleDestination destination) {
    return switch (destination) {
      SaleDestination.ceiling => _ProductSaleScreen(
        key: const ValueKey('ceiling'),
        config: _ProductScreenConfig.ceiling(),
      ),
      SaleDestination.insulation => _ProductSaleScreen(
        key: const ValueKey('insulation'),
        config: _ProductScreenConfig.insulation(),
      ),
      SaleDestination.led => _ProductSaleScreen(
        key: const ValueKey('led'),
        config: _ProductScreenConfig.led(),
      ),
      SaleDestination.wire => _ProductSaleScreen(
        key: const ValueKey('wire'),
        config: _ProductScreenConfig.wire(),
      ),
      SaleDestination.decoration => _ProductSaleScreen(
        key: const ValueKey('decoration'),
        config: _ProductScreenConfig.decoration(),
      ),
      SaleDestination.custom => _ProductSaleScreen(
        key: const ValueKey('custom'),
        config: _ProductScreenConfig.custom(),
      ),
      SaleDestination.measurement => const MeasurementCalculatorScreen(),
      SaleDestination.currentSale => const _TemporarySaleScreen(),
      SaleDestination.products => const _ProductsDataScreen(),
      SaleDestination.prices => const _PricesDataScreen(),
      SaleDestination.packaging => const _PackagingDataScreen(),
      SaleDestination.productKinds => const _ProductKindsDataScreen(),
      SaleDestination.formulas => const _FormulaRulesDataScreen(),
      SaleDestination.unitsCategories => const _UnitsCategoriesDataScreen(),
      SaleDestination.appSettings => const _AppSettingsDataScreen(),
    };
  }
}

class _DestinationMeta {
  const _DestinationMeta(this.title, this.subtitle, this.icon);

  final String title;
  final String subtitle;
  final IconData icon;
}

_DestinationMeta _destinationMeta(SaleDestination destination) {
  return switch (destination) {
    SaleDestination.ceiling => const _DestinationMeta(
      'ពិដាន',
      'គណនា / លក់',
      Icons.grid_view_rounded,
    ),
    SaleDestination.insulation => const _DestinationMeta(
      'អ៊ីសូឡង់',
      'គណនា / លក់',
      Icons.layers_rounded,
    ),
    SaleDestination.led => const _DestinationMeta(
      'អំពូល LED',
      'គណនា / លក់',
      Icons.lightbulb_outline_rounded,
    ),
    SaleDestination.wire => const _DestinationMeta(
      'លួស',
      'គណនា / លក់',
      Icons.cable_rounded,
    ),
    SaleDestination.decoration => const _DestinationMeta(
      'លម្អ',
      'គណនា / លក់',
      Icons.dashboard_customize_outlined,
    ),
    SaleDestination.custom => const _DestinationMeta(
      'ផលិតផលផ្សេងៗ',
      'គណនា / លក់',
      Icons.tune_rounded,
    ),
    SaleDestination.measurement => const _DestinationMeta(
      'គណនាទំហំ និងចំនួនសម្ភារៈ',
      'គិតតាមទំហំដើមពិត',
      Icons.architecture_rounded,
    ),
    SaleDestination.currentSale => const _DestinationMeta(
      'បញ្ជីលក់បច្ចុប្បន្ន',
      'សង្ខេបបណ្ដោះអាសន្ន',
      Icons.receipt_long_rounded,
    ),
    SaleDestination.products => const _DestinationMeta(
      'ផលិតផល',
      'ទិន្នន័យ',
      Icons.inventory_2_outlined,
    ),
    SaleDestination.prices => const _DestinationMeta(
      'តម្លៃ',
      'ទិន្នន័យ',
      Icons.sell_outlined,
    ),
    SaleDestination.packaging => const _DestinationMeta(
      'ការវេចខ្ចប់',
      'ទិន្នន័យ',
      Icons.all_inbox_outlined,
    ),
    SaleDestination.productKinds => const _DestinationMeta(
      'ប្រភេទផលិតផល',
      'ទិន្នន័យ',
      Icons.category_outlined,
    ),
    SaleDestination.formulas => const _DestinationMeta(
      'រូបមន្តគណនា',
      'ទិន្នន័យ',
      Icons.functions_rounded,
    ),
    SaleDestination.unitsCategories => const _DestinationMeta(
      'ឯកតា / ប្រភេទ',
      'ទិន្នន័យ',
      Icons.straighten_rounded,
    ),
    SaleDestination.appSettings => const _DestinationMeta(
      'ការកំណត់កម្មវិធី',
      'ការកំណត់',
      Icons.settings_outlined,
    ),
  };
}

class _Sidebar extends StatelessWidget {
  const _Sidebar({required this.destination, required this.onSelected});

  final SaleDestination destination;
  final ValueChanged<SaleDestination> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 248,
      color: _sidebar,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(18, 18, 18, 12),
              child: Row(
                children: [
                  Icon(Icons.point_of_sale_rounded, color: _primary, size: 22),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'គណនាលក់សម្ភារៈ',
                      style: TextStyle(
                        color: _text,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  _group('គណនា / លក់'),
                  _item(
                    Icons.grid_view_rounded,
                    'ពិដាន',
                    SaleDestination.ceiling,
                  ),
                  _item(
                    Icons.layers_rounded,
                    'អ៊ីសូឡង់',
                    SaleDestination.insulation,
                  ),
                  _item(
                    Icons.lightbulb_outline_rounded,
                    'អំពូល LED',
                    SaleDestination.led,
                  ),
                  _item(Icons.cable_rounded, 'លួស', SaleDestination.wire),
                  _item(
                    Icons.dashboard_customize_outlined,
                    'លម្អ',
                    SaleDestination.decoration,
                  ),
                  _item(
                    Icons.tune_rounded,
                    'ផលិតផលផ្សេងៗ',
                    SaleDestination.custom,
                  ),
                  _item(
                    Icons.architecture_rounded,
                    'គណនាទំហំ និងចំនួនសម្ភារៈ',
                    SaleDestination.measurement,
                  ),
                  const SizedBox(height: 14),
                  _group('សង្ខេបបណ្ដោះអាសន្ន'),
                  _item(
                    Icons.receipt_long_rounded,
                    'បញ្ជីលក់បច្ចុប្បន្ន',
                    SaleDestination.currentSale,
                  ),
                  const SizedBox(height: 14),
                  _group('ទិន្នន័យ'),
                  _item(
                    Icons.inventory_2_outlined,
                    'ផលិតផល',
                    SaleDestination.products,
                  ),
                  _item(Icons.sell_outlined, 'តម្លៃ', SaleDestination.prices),
                  _item(
                    Icons.all_inbox_outlined,
                    'ការវេចខ្ចប់',
                    SaleDestination.packaging,
                  ),
                  _item(
                    Icons.category_outlined,
                    'ប្រភេទផលិតផល',
                    SaleDestination.productKinds,
                  ),
                  _item(
                    Icons.functions_rounded,
                    'រូបមន្តគណនា',
                    SaleDestination.formulas,
                  ),
                  _item(
                    Icons.straighten_rounded,
                    'ឯកតា / ប្រភេទ',
                    SaleDestination.unitsCategories,
                  ),
                  const SizedBox(height: 14),
                  _group('ការកំណត់'),
                  _item(
                    Icons.settings_outlined,
                    'ការកំណត់កម្មវិធី',
                    SaleDestination.appSettings,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _group(String label) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 6),
      child: Text(
        label,
        style: const TextStyle(
          color: _textMuted,
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 0,
        ),
      ),
    );
  }

  Widget _item(IconData icon, String label, SaleDestination value) {
    final active = destination == value;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: InkWell(
        key: ValueKey('nav-${value.name}'),
        borderRadius: BorderRadius.circular(14),
        onTap: () => onSelected(value),
        child: Container(
          height: 42,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: active ? const Color(0xFF1D2440) : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: active ? const Color(0xFF2E3A67) : Colors.transparent,
            ),
          ),
          child: Row(
            children: [
              Icon(icon, size: 19, color: active ? _primary : _textSecondary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: active ? _text : _textSecondary,
                    fontSize: 13,
                    fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopHeader extends StatelessWidget {
  const _TopHeader({required this.meta});

  final _DestinationMeta meta;

  @override
  Widget build(BuildContext context) {
    final count = context.select<AppState, int>(
      (state) => state.currentSaleItems.length,
    );
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 22),
      decoration: const BoxDecoration(
        color: _bg,
        border: Border(bottom: BorderSide(color: _border)),
      ),
      child: Row(
        children: [
          Icon(meta.icon, color: _secondary, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  meta.title,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _text,
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                    height: 1.35,
                  ),
                ),
                Text(
                  meta.subtitle,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          const _HeaderPill(icon: Icons.attach_money_rounded, label: 'USD'),
          const SizedBox(width: 8),
          _HeaderPill(icon: Icons.shopping_cart_outlined, label: '$count មុខ'),
        ],
      ),
    );
  }
}

class _HeaderPill extends StatelessWidget {
  const _HeaderPill({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border),
      ),
      child: Row(
        children: [
          Icon(icon, color: _secondary, size: 18),
          const SizedBox(width: 7),
          Text(
            label,
            style: const TextStyle(color: _textSecondary, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _ProductScreenConfig {
  const _ProductScreenConfig({
    required this.templateId,
    required this.titleKhmer,
    required this.icon,
    required this.categoryIds,
    required this.oneProductInputMethodIds,
    this.supportsCeilingFullSet = false,
  });

  final String templateId;
  final String titleKhmer;
  final IconData icon;
  final Set<String> categoryIds;
  final List<String> oneProductInputMethodIds;
  final bool supportsCeilingFullSet;

  factory _ProductScreenConfig.ceiling() {
    return const _ProductScreenConfig(
      templateId: 'ceiling_material_only',
      titleKhmer: 'ពិដាន',
      icon: Icons.grid_view_rounded,
      categoryIds: {'ceiling', 't_bar', 'v_iron'},
      oneProductInputMethodIds: [
        InputMethodIds.looseQuantity,
        InputMethodIds.boxQuantity,
        InputMethodIds.boxPlusLoose,
        InputMethodIds.manualQuantity,
      ],
      supportsCeilingFullSet: true,
    );
  }

  factory _ProductScreenConfig.insulation() {
    return const _ProductScreenConfig(
      templateId: 'insulation_only',
      titleKhmer: 'អ៊ីសូឡង់',
      icon: Icons.layers_rounded,
      categoryIds: {'insulation'},
      oneProductInputMethodIds: [
        InputMethodIds.looseQuantity,
        InputMethodIds.boxQuantity,
        InputMethodIds.boxPlusLoose,
        InputMethodIds.manualQuantity,
      ],
    );
  }

  factory _ProductScreenConfig.led() {
    return const _ProductScreenConfig(
      templateId: 'led_only',
      titleKhmer: 'អំពូល LED',
      icon: Icons.lightbulb_outline_rounded,
      categoryIds: {'led'},
      oneProductInputMethodIds: [
        InputMethodIds.looseQuantity,
        InputMethodIds.boxQuantity,
        InputMethodIds.boxPlusLoose,
        InputMethodIds.manualQuantity,
      ],
    );
  }

  factory _ProductScreenConfig.wire() {
    return const _ProductScreenConfig(
      templateId: 'wire_only',
      titleKhmer: 'លួស',
      icon: Icons.cable_rounded,
      categoryIds: {'wire'},
      oneProductInputMethodIds: [
        InputMethodIds.looseQuantity,
        InputMethodIds.boxQuantity,
        InputMethodIds.boxPlusLoose,
        InputMethodIds.manualQuantity,
      ],
    );
  }

  factory _ProductScreenConfig.decoration() {
    return const _ProductScreenConfig(
      templateId: 'decoration_only',
      titleKhmer: 'លម្អ',
      icon: Icons.dashboard_customize_outlined,
      categoryIds: {'decoration'},
      oneProductInputMethodIds: [
        InputMethodIds.looseQuantity,
        InputMethodIds.manualQuantity,
      ],
    );
  }

  factory _ProductScreenConfig.custom() {
    return const _ProductScreenConfig(
      templateId: 'custom',
      titleKhmer: 'ផលិតផលផ្សេងៗ',
      icon: Icons.tune_rounded,
      categoryIds: {},
      oneProductInputMethodIds: [
        InputMethodIds.areaM2,
        InputMethodIds.widthLength,
        InputMethodIds.looseQuantity,
        InputMethodIds.boxQuantity,
        InputMethodIds.boxPlusLoose,
        InputMethodIds.manualQuantity,
        InputMethodIds.serviceOnly,
      ],
    );
  }
}

class _ProductSaleScreen extends StatefulWidget {
  const _ProductSaleScreen({super.key, required this.config});

  final _ProductScreenConfig config;

  @override
  State<_ProductSaleScreen> createState() => _ProductSaleScreenState();
}

class _ProductSaleScreenState extends State<_ProductSaleScreen> {
  final _area = TextEditingController(text: '100');
  final _width = TextEditingController(text: '5');
  final _length = TextEditingController(text: '6');
  final _loose = TextEditingController(text: '25');
  final _boxes = TextEditingController(text: '1');
  final _manual = TextEditingController(text: '1');
  final _manualTotal = TextEditingController(text: '0');
  final _areaSalePrice = TextEditingController(text: '4.20');
  final _deliveryFee = TextEditingController(text: '0');
  final Map<String, _LinePriceControllers> _linePrices = {};
  final Map<String, TextEditingController> _manualLineQuantities = {};

  String? _materialId;
  bool _ceilingFullSet = true;
  String _askModeId = CustomerAskModeIds.priceByArea;
  String _offerId = 'ceiling_full_set';
  String _inputMethodId = InputMethodIds.areaM2;
  String _chargeMethodId = ChargeMethodIds.boxPlusLoose;
  bool _includeDelivery = false;
  String _deliveryModeId = DeliveryModeIds.flatDelivery;
  String _deliveryPayerId = DeliveryPayerIds.ownerPays;
  bool _lastUseSavedPriceAsDefault = false;
  String? _loadedAreaSalePriceProductKindId;
  bool? _loadedAreaUseSavedPriceAsDefault;

  @override
  void initState() {
    super.initState();
    _ceilingFullSet = widget.config.supportsCeilingFullSet;
    _inputMethodId = _inputMethodIds.first;
    _chargeMethodId = _defaultChargeMethodId;
    for (final controller in [
      _area,
      _width,
      _length,
      _loose,
      _boxes,
      _manual,
      _manualTotal,
      _areaSalePrice,
      _deliveryFee,
    ]) {
      controller.addListener(_refresh);
    }
  }

  @override
  void didUpdateWidget(covariant _ProductSaleScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.config.templateId != widget.config.templateId) {
      _materialId = null;
      _ceilingFullSet = widget.config.supportsCeilingFullSet;
      _askModeId = CustomerAskModeIds.priceByArea;
      _offerId = 'ceiling_full_set';
      _inputMethodId = _inputMethodIds.first;
      _chargeMethodId = _defaultChargeMethodId;
      _linePrices.clear();
      _loadedAreaSalePriceProductKindId = null;
      _clearManualLineControllers();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final state = context.watch<AppState>();
    final products = _products(state);
    if ((_materialId == null ||
            !products.any((material) => material.id == _materialId)) &&
        products.isNotEmpty) {
      _materialId = products.first.id;
    }
    if (state.useSavedPriceAsDefault != _lastUseSavedPriceAsDefault) {
      _lastUseSavedPriceAsDefault = state.useSavedPriceAsDefault;
      _linePrices.clear();
      _loadedAreaSalePriceProductKindId = null;
    }
    if (!_inputMethodIds.contains(_inputMethodId)) {
      _inputMethodId = _inputMethodIds.first;
    }
    if (!_chargeMethodIds.contains(_chargeMethodId)) {
      _chargeMethodId = _defaultChargeMethodId;
    }
    final availableChargeMethods = _availableChargeMethodIds(state);
    if (!availableChargeMethods.contains(_chargeMethodId) &&
        availableChargeMethods.isNotEmpty) {
      _chargeMethodId = availableChargeMethods.first;
    }
    _ensurePriceControllers(state, _activeMaterialIds(state));
    _ensureAreaSalePriceController(state);
    _ensureManualLineControllers(state, _activeMaterialIds(state));
  }

  @override
  void dispose() {
    for (final controller in [
      _area,
      _width,
      _length,
      _loose,
      _boxes,
      _manual,
      _manualTotal,
      _areaSalePrice,
      _deliveryFee,
    ]) {
      controller.dispose();
    }
    for (final controllers in _linePrices.values) {
      controllers.dispose();
    }
    _clearManualLineControllers();
    super.dispose();
  }

  List<String> get _inputMethodIds {
    if (_usesCeilingAskModes) {
      return _askMode.allowedInputMethods;
    }
    if (widget.config.supportsCeilingFullSet && _ceilingFullSet) {
      return const [
        InputMethodIds.areaM2,
        InputMethodIds.widthLength,
        InputMethodIds.ceilingLooseSheets,
        InputMethodIds.ceilingBoxQuantity,
        InputMethodIds.ceilingBoxPlusLoose,
        InputMethodIds.manualPerProduct,
      ];
    }
    return widget.config.oneProductInputMethodIds;
  }

  List<String> get _chargeMethodIds {
    if (_usesCeilingAskModes) {
      return _askMode.allowedChargeMethods;
    }
    return const [
      ChargeMethodIds.areaM2Price,
      ChargeMethodIds.unitOnly,
      ChargeMethodIds.boxOnly,
      ChargeMethodIds.boxPlusLoose,
      ChargeMethodIds.manualTotal,
    ];
  }

  String get _defaultChargeMethodId {
    if (_usesCeilingAskModes) {
      return _chargeMethodIds.first;
    }
    return _chargeMethodIds.contains(ChargeMethodIds.boxPlusLoose)
        ? ChargeMethodIds.boxPlusLoose
        : _chargeMethodIds.first;
  }

  bool get _usesCeilingAskModes => widget.config.supportsCeilingFullSet;

  CustomerAskMode get _askMode => CustomerAskModeCatalog.ceilingById(
    _usesCeilingAskModes ? _askModeId : CustomerAskModeIds.priceByArea,
  );

  bool get _usesAreaCharge => _chargeMethodId == ChargeMethodIds.areaM2Price;

  bool get _inputMethodProvidesArea {
    return switch (_inputMethodId) {
      InputMethodIds.areaM2 ||
      InputMethodIds.widthLength ||
      InputMethodIds.ceilingLooseSheets ||
      InputMethodIds.ceilingBoxQuantity ||
      InputMethodIds.ceilingBoxPlusLoose => true,
      _ => false,
    };
  }

  bool get _needsManualAreaForAreaCharge =>
      _usesAreaCharge && !_inputMethodProvidesArea;

  bool get _isQuantityOnlyAskMode =>
      _usesCeilingAskModes && _askMode.isQuantityOnly;

  bool get _shouldShowProductPicker {
    if (!_usesCeilingAskModes) {
      return !_ceilingFullSet || !widget.config.supportsCeilingFullSet;
    }
    return _askMode.requiresProduct;
  }

  String get _resultTitle {
    if (!_usesCeilingAskModes) return 'លទ្ធផល';
    return switch (_askMode.id) {
      CustomerAskModeIds.priceByArea ||
      CustomerAskModeIds.priceByWidthLength => 'តម្លៃសរុបដែលអតិថិជនត្រូវបង់',
      CustomerAskModeIds.materialsByWidthLength ||
      CustomerAskModeIds.materialsOnly => 'ចំនួនកេស និងចំនួនរាយដែលត្រូវការ',
      CustomerAskModeIds.ceilingSheetsByWidthLength => 'ចំនួនពិដានដែលត្រូវការ',
      CustomerAskModeIds.looseProductSale => 'តម្លៃលក់ផលិតផលរាយ',
      CustomerAskModeIds.boxProductSale => 'តម្លៃលក់ជាកេស',
      CustomerAskModeIds.boxPlusLooseSale => 'តម្លៃលក់កេស + រាយ',
      _ => 'លទ្ធផល',
    };
  }

  void _changeAskMode(String value) {
    setState(() {
      _askModeId = value;
      _inputMethodId = _inputMethodIds.first;
      _chargeMethodId = _defaultChargeMethodId;
      _loadedAreaSalePriceProductKindId = null;
    });
  }

  List<String> _availableChargeMethodIds(AppState state) {
    final ids = [..._chargeMethodIds];
    if (!_usesCeilingAskModes || _materialId == null) {
      return ids;
    }
    if (_askMode.requiresProduct && !_productHasBoxPrice(state, _materialId!)) {
      ids.remove(ChargeMethodIds.boxOnly);
      ids.remove(ChargeMethodIds.boxPlusLoose);
    }
    return ids;
  }

  bool _productHasBoxPrice(AppState state, String materialId) {
    return (_price(
              state.prices,
              materialId,
              PriceTypeIds.saleBoxPrice,
              fallback: PriceTypeIds.boxPrice,
            ) ??
            0) >
        0;
  }

  List<DropdownMenuItem<String>> _ceilingOfferItems(AppState state) {
    const offerIds = ['ceiling_full_set', 'ceiling_material_only'];
    final byId = {
      for (final template in state.productTemplates) template.id: template,
    };
    return [
      for (final id in offerIds)
        if (byId[id] != null)
          DropdownMenuItem(
            value: id,
            child: Text(
              byId[id]!.nameKhmer,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
    ];
  }

  Widget _priceInputs(AppState state) {
    if (_chargeMethodId == ChargeMethodIds.areaM2Price) {
      return _numberField(_areaSalePrice, 'តម្លៃលក់ / ការ៉េ');
    }
    if (_chargeMethodId == ChargeMethodIds.manualTotal) {
      return _numberField(_manualTotal, 'បញ្ចូលតម្លៃសរុបផ្ទាល់');
    }
    final materialId = _materialId;
    if (materialId == null) {
      return const SizedBox.shrink();
    }
    final price = _linePrices[materialId];
    if (price == null) {
      return const SizedBox.shrink();
    }
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        if (_chargeMethodId == ChargeMethodIds.unitOnly ||
            _chargeMethodId == ChargeMethodIds.boxPlusLoose)
          _numberField(price.saleUnit, 'តម្លៃលក់ / រាយ'),
        if (_chargeMethodId == ChargeMethodIds.boxOnly ||
            _chargeMethodId == ChargeMethodIds.boxPlusLoose)
          _numberField(price.saleBox, 'តម្លៃលក់ / កេស'),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final products = _products(state);
    _ensurePriceControllers(state, _activeMaterialIds(state));
    _ensureAreaSalePriceController(state);
    _ensureManualLineControllers(state, _activeMaterialIds(state));
    final results = _calculateResults(state);
    final errors = results.expand((result) => result.validationErrors).toList();
    final aggregateBelowCost = _areaSaleBelowCost(results);
    final quantityOnly = _isQuantityOnlyAskMode;
    final hasBlockingWarning =
        results.any((result) => !result.canAddToTemporarySale) ||
        (aggregateBelowCost && !state.allowSaleBelowCost);
    final canAdd =
        !quantityOnly &&
        results.isNotEmpty &&
        errors.isEmpty &&
        !hasBlockingWarning;

    return _Page(
      floatingAction: FilledButton.icon(
        onPressed: canAdd ? () => _addToTemporaryList(results) : null,
        icon: const Icon(Icons.add_shopping_cart_rounded, size: 19),
        label: const Text('បន្ថែមទៅបញ្ជីបណ្ដោះអាសន្ន'),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final form = _formPanel(state, products, results);
          final resultPanel = _resultPanel(state, results, errors);
          if (constraints.maxWidth < 1060) {
            return ListView(
              padding: EdgeInsets.zero,
              children: [form, const SizedBox(height: 14), resultPanel],
            );
          }
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(width: 430, child: form),
              const SizedBox(width: 14),
              Expanded(child: resultPanel),
            ],
          );
        },
      ),
    );
  }

  Widget _formPanel(
    AppState state,
    List<MaterialItem> products,
    List<ProductSaleResult> results,
  ) {
    final inputHelperText = _inputHelperText(state);
    final availableChargeMethods = _availableChargeMethodIds(state);
    return _Panel(
      title: 'គណនា',
      icon: widget.config.icon,
      scrollBody: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_usesCeilingAskModes) ...[
            _sectionLabel('អតិថិជនសួរអំពីអ្វី?'),
            _ChoiceCards<String>(
              value: _askModeId,
              values: CustomerAskModeCatalog.ceilingDefaults
                  .map((mode) => mode.id)
                  .toList(growable: false),
              label: (id) => CustomerAskModeCatalog.ceilingById(id).nameKhmer,
              icon: _askModeIcon,
              onChanged: _changeAskMode,
            ),
            const SizedBox(height: 14),
          ],
          if (_usesCeilingAskModes && _askMode.requiresOffer) ...[
            DropdownButtonFormField<String>(
              initialValue: _offerId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'ជម្រើសលក់'),
              items: _ceilingOfferItems(state),
              onChanged: (value) {
                if (value == null) return;
                setState(() {
                  _offerId = value;
                  _loadedAreaSalePriceProductKindId = null;
                });
              },
            ),
            const SizedBox(height: 14),
          ],
          if (_shouldShowProductPicker) ...[
            DropdownButtonFormField<String>(
              initialValue: _materialId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'ផលិតផល'),
              items: products
                  .map(
                    (material) => DropdownMenuItem(
                      value: material.id,
                      child: Text(
                        _productLabel(material),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _materialId = value),
            ),
            const SizedBox(height: 14),
          ],
          if (_inputMethodIds.length > 1) ...[
            _sectionLabel('របៀបបញ្ចូល'),
            _ChoiceCards<String>(
              value: _inputMethodId,
              values: _inputMethodIds,
              label: (id) => InputMethodCatalog.byId(id).nameKhmer,
              icon: _inputIcon,
              onChanged: (value) => setState(() => _inputMethodId = value),
            ),
            const SizedBox(height: 14),
          ],
          _sectionLabel('ព័ត៌មានបញ្ចូល'),
          _dynamicInputs(state, InputMethodCatalog.byId(_inputMethodId)),
          if (_needsManualAreaForAreaCharge) ...[
            const SizedBox(height: 12),
            _numberField(_area, 'ការ៉េសរុប / m²'),
          ],
          if (inputHelperText != null) ...[
            const SizedBox(height: 8),
            Text(
              inputHelperText,
              style: const TextStyle(color: _textSecondary, fontSize: 12),
            ),
          ],
          if (availableChargeMethods.length > 1) ...[
            const SizedBox(height: 14),
            _sectionLabel('របៀបគិតលុយ'),
            _ChoiceCards<String>(
              value: _chargeMethodId,
              values: availableChargeMethods,
              label: (id) => ChargeMethodCatalog.byId(id).nameKhmer,
              icon: _chargeIcon,
              onChanged: (value) => setState(() => _chargeMethodId = value),
            ),
          ],
          if (!_isQuantityOnlyAskMode) ...[
            const SizedBox(height: 12),
            _sectionLabel('តម្លៃលក់'),
            _priceInputs(state),
          ],
          if (!_isQuantityOnlyAskMode) ...[
            const SizedBox(height: 14),
            _deliverySection(results),
          ],
          const SizedBox(height: 14),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              FilledButton.icon(
                onPressed: results.isEmpty ? null : () => _copySummary(results),
                icon: const Icon(Icons.copy_rounded, size: 18),
                label: const Text('ចម្លងសង្ខេប'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _dynamicInputs(AppState state, InputMethod method) {
    if (method.id == InputMethodIds.manualPerProduct) {
      final activeMaterials = _activeMaterials(state);
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          for (final material in activeMaterials)
            _numberField(
              _manualLineQuantities[material.id]!,
              _productLabel(material),
            ),
        ],
      );
    }
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        if (method.requiresArea) _numberField(_area, 'ការ៉េ / m²'),
        if (method.requiresWidthLength) ...[
          _numberField(_width, 'ទទឹង / m'),
          _numberField(_length, 'បណ្ដោយ / m'),
        ],
        if (method.requiresBoxQuantity)
          _numberField(
            _boxes,
            method.id == InputMethodIds.ceilingBoxQuantity ||
                    method.id == InputMethodIds.ceilingBoxPlusLoose
                ? 'ចំនួនកេសពិដាន'
                : 'ចំនួនកេស',
          ),
        if (method.requiresLooseQuantity)
          _numberField(
            _loose,
            method.id == InputMethodIds.ceilingLooseSheets ||
                    method.id == InputMethodIds.ceilingBoxPlusLoose
                ? 'ចំនួនពិដានរាយ'
                : 'ចំនួនរាយ',
          ),
        if (method.requiresManualQuantity) _numberField(_manual, 'ចំនួន'),
      ],
    );
  }

  Widget _deliverySection(List<ProductSaleResult> results) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _includeDelivery,
            title: const Text('ថ្លៃដឹក / សេវាដឹកជញ្ជូន'),
            subtitle: const Text('មានថ្លៃដឹក', style: TextStyle(fontSize: 12)),
            onChanged: (value) => setState(() => _includeDelivery = value),
          ),
          if (_includeDelivery) ...[
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: _deliveryPayerId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'អ្នកចេញថ្លៃដឹក'),
              items: DeliveryPayerCatalog.defaults
                  .where((option) => option.id != DeliveryPayerIds.noDelivery)
                  .map(
                    (option) => DropdownMenuItem(
                      value: option.id,
                      child: Text(
                        option.nameKhmer,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                if (value == null) return;
                setState(() => _deliveryPayerId = value);
              },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _deliveryModeId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'របៀបគិតថ្លៃដឹក'),
              items: const [
                DropdownMenuItem(
                  value: DeliveryModeIds.flatDelivery,
                  child: Text('ថ្លៃដឹកថេរ'),
                ),
                DropdownMenuItem(
                  value: DeliveryModeIds.perBoxDelivery,
                  child: Text('គិតថ្លៃដឹកតាមកេស'),
                ),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() => _deliveryModeId = value);
              },
            ),
            const SizedBox(height: 12),
            _numberField(
              _deliveryFee,
              _deliveryModeId == DeliveryModeIds.flatDelivery
                  ? 'ថ្លៃដឹកសរុប'
                  : 'ថ្លៃដឹក / កេស',
            ),
            if (_deliveryModeId != DeliveryModeIds.flatDelivery)
              Builder(
                builder: (context) {
                  int totalFullBoxes = 0;
                  int totalLooseItems = 0;
                  for (final r in results) {
                    totalFullBoxes += r.packagingFullBoxes;
                    totalLooseItems += r.packagingLooseItems;
                  }
                  final fee = _parseDouble(_deliveryFee.text) ?? 0;
                  final totalFee = totalFullBoxes * fee;
                  return Padding(
                    padding: const EdgeInsets.only(top: 8.0, bottom: 4.0),
                    child: Text(
                      'ចំនួនកេសសម្រាប់ដឹក: $totalFullBoxes\nចំនួនរាយ: $totalLooseItems\nថ្លៃដឹកសរុប: ${MoneyFormatter.money(totalFee)}',
                      style: const TextStyle(
                        color: _textSecondary,
                        fontSize: 13,
                        height: 1.5,
                      ),
                    ),
                  );
                },
              ),
          ],
        ],
      ),
    );
  }

  Widget _resultPanel(
    AppState state,
    List<ProductSaleResult> results,
    List<String> errors,
  ) {
    final totalPay = results.fold<double>(
      0,
      (sum, result) => sum + result.customerPayTotal,
    );
    final totalCost = results.fold<double>(
      0,
      (sum, result) => sum + result.ownerCostTotal,
    );
    final totalProfit = results.fold<double>(
      0,
      (sum, result) => sum + result.ownerProfit,
    );
    final totalQuantity = results.fold<int>(
      0,
      (sum, result) => sum + result.sellQuantity,
    );
    final areaSale = results.any(
      (result) => result.chargeMethodId == ChargeMethodIds.areaM2Price,
    );
    final quantityOnly = _isQuantityOnlyAskMode;
    final areaM2 = _areaSaleAreaM2(results);
    final areaPrice = _areaSalePricePerM2(results);
    return _Panel(
      title: _resultTitle,
      icon: Icons.analytics_outlined,
      scrollBody: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (errors.isNotEmpty)
            _ErrorList(errors: errors)
          else ...[
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: quantityOnly
                  ? [
                      if (areaM2 > 0)
                        _MetricTile(
                          'ការ៉េសរុប',
                          '${MoneyFormatter.decimal(areaM2)} m²',
                        ),
                      _MetricTile('ចំនួនសម្ភារៈសរុប', '$totalQuantity'),
                    ]
                  : areaSale
                  ? [
                      _MetricTile(
                        'ការ៉េសរុប',
                        '${MoneyFormatter.decimal(areaM2)} m²',
                      ),
                      _MetricTile(
                        'តម្លៃលក់ / ការ៉េ',
                        MoneyFormatter.money(areaPrice),
                      ),
                      _MetricTile('អតិថិជនបង់', MoneyFormatter.money(totalPay)),
                      _MetricTile('ថ្លៃដើម', MoneyFormatter.money(totalCost)),
                      _MetricTile(
                        'ចំណេញ',
                        MoneyFormatter.money(totalProfit),
                        accent: totalProfit < 0 ? _danger : _success,
                      ),
                    ]
                  : [
                      _MetricTile('ចំនួនសរុប', '$totalQuantity'),
                      _MetricTile('អតិថិជនបង់', MoneyFormatter.money(totalPay)),
                      _MetricTile('ថ្លៃដើម', MoneyFormatter.money(totalCost)),
                      _MetricTile(
                        'ចំណេញ',
                        MoneyFormatter.money(totalProfit),
                        accent: totalProfit < 0 ? _danger : _success,
                      ),
                    ],
            ),
            if (!quantityOnly) ...[
              const SizedBox(height: 12),
              _SellStatusCard(
                results: results,
                allowSaleBelowCost: state.allowSaleBelowCost,
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: areaSale
                    ? OutlinedButton.icon(
                        onPressed: results.isEmpty
                            ? null
                            : () => _saveCurrentAreaPriceAsDefault(state),
                        icon: const Icon(Icons.save_outlined, size: 18),
                        label: const Text('រក្សាទុកតម្លៃការ៉េនេះ'),
                      )
                    : OutlinedButton.icon(
                        onPressed: results.isEmpty
                            ? null
                            : () =>
                                  _saveCurrentPricesAsDefaults(state, results),
                        icon: const Icon(Icons.save_outlined, size: 18),
                        label: const Text('រក្សាទុកតម្លៃនេះ'),
                      ),
              ),
            ],
            const SizedBox(height: 12),
            _ResultsTable(
              results: results,
              areaSale: areaSale,
              quantityOnly: quantityOnly,
              linePrices: _linePrices,
              onChanged: _refresh,
            ),
          ],
        ],
      ),
    );
  }

  List<ProductSaleResult> _calculateResults(AppState state) {
    List<ProductSaleResult> results;
    if (_usesCeilingAskModes) {
      results = _calculateCeilingAskResults(state);
    } else if (widget.config.supportsCeilingFullSet && _ceilingFullSet) {
      final template = state.productTemplates
          .where((item) => item.id == 'ceiling_full_set')
          .firstOrNull;
      if (template == null) return const [];
      final rules = template.defaultMaterialRules
          .where((rule) => rule.includedByDefault)
          .toList();
      results = [
        for (var i = 0; i < rules.length; i++)
          state.calculateProductSale(
            _input(
              state: state,
              productKindId: template.id,
              materialId: rules[i].materialId,
              includeDelivery: i == 0 && _includeDelivery,
              includeAreaRevenue: i == 0,
            ),
          ),
      ];
    } else {
      if (_materialId == null) return const [];
      results = [
        state.calculateProductSale(
          _input(
            state: state,
            productKindId: widget.config.templateId,
            materialId: _materialId!,
            includeDelivery: _includeDelivery,
            includeAreaRevenue: true,
          ),
        ),
      ];
    }

    if (_includeDelivery && results.isNotEmpty && results[0].includeDelivery) {
      final delivery = calculateDelivery(
        deliveryModeId: _deliveryModeId,
        deliveryPayerId: _deliveryPayerId,
        deliveryRate: _parseDouble(_deliveryFee.text) ?? 0,
        lines: results
            .map(
              (r) => DeliveryLineData(
                packagingFullBoxes: r.packagingFullBoxes,
                packagingLooseItems: r.packagingLooseItems,
              ),
            )
            .toList(),
      );
      final customerPays =
          delivery.deliveryPayerId == DeliveryPayerIds.customerPays;
      final ownerPays = delivery.deliveryPayerId == DeliveryPayerIds.ownerPays;
      final customerPayTotal = MoneyFormatter.roundMoney(
        results[0].productRevenue +
            (customerPays ? delivery.deliveryFeeTotal : 0.0),
      );
      final ownerCostTotal = MoneyFormatter.roundMoney(
        results[0].productCost + (ownerPays ? delivery.deliveryFeeTotal : 0.0),
      );
      results[0] = results[0].copyWithDelivery(
        deliveryModeId: delivery.deliveryModeId,
        deliveryPayerId: delivery.deliveryPayerId,
        deliveryRate: delivery.deliveryRate,
        totalFullBoxes: delivery.totalFullBoxes,
        totalLooseItems: delivery.totalLooseItems,
        deliveryFeeTotal: delivery.deliveryFeeTotal,
        deliveryRevenue: customerPays ? delivery.deliveryFeeTotal : 0.0,
        deliveryCostToOwner: ownerPays ? delivery.deliveryFeeTotal : 0.0,
        customerPayTotal: customerPayTotal,
        ownerCostTotal: ownerCostTotal,
        ownerProfit: MoneyFormatter.roundMoney(
          customerPayTotal - ownerCostTotal,
        ),
      );
    }

    return results;
  }

  List<ProductSaleResult> _calculateCeilingAskResults(AppState state) {
    final mode = _askMode;
    if (mode.requiresOffer) {
      return _calculateTemplateResults(
        state: state,
        productKindId: _offerId,
        includeDeliveryOnFirstLine: _includeDelivery,
        includeAreaRevenueOnFirstLine: true,
      );
    }
    return switch (mode.id) {
      CustomerAskModeIds.materialsByWidthLength ||
      CustomerAskModeIds.materialsOnly => _calculateTemplateResults(
        state: state,
        productKindId: 'ceiling_full_set',
        includeDeliveryOnFirstLine: false,
        includeAreaRevenueOnFirstLine: false,
      ),
      CustomerAskModeIds.ceilingSheetsByWidthLength => [
        state.calculateProductSale(
          _input(
            state: state,
            productKindId: 'ceiling_full_set',
            materialId: 'ceiling_6mm',
            includeDelivery: false,
            includeAreaRevenue: false,
          ),
        ),
      ],
      _ =>
        _materialId == null
            ? const <ProductSaleResult>[]
            : [
                state.calculateProductSale(
                  _input(
                    state: state,
                    productKindId: widget.config.templateId,
                    materialId: _materialId!,
                    includeDelivery: _includeDelivery,
                    includeAreaRevenue: true,
                  ),
                ),
              ],
    };
  }

  List<ProductSaleResult> _calculateTemplateResults({
    required AppState state,
    required String productKindId,
    required bool includeDeliveryOnFirstLine,
    required bool includeAreaRevenueOnFirstLine,
  }) {
    final template = state.productTemplates
        .where((item) => item.id == productKindId)
        .firstOrNull;
    if (template == null) return const [];
    final rules = template.defaultMaterialRules
        .where((rule) => rule.includedByDefault)
        .toList();
    return [
      for (var i = 0; i < rules.length; i++)
        state.calculateProductSale(
          _input(
            state: state,
            productKindId: template.id,
            materialId: rules[i].materialId,
            includeDelivery: i == 0 && includeDeliveryOnFirstLine,
            includeAreaRevenue: i == 0 && includeAreaRevenueOnFirstLine,
          ),
        ),
    ];
  }

  ProductSaleInput _input({
    required AppState state,
    required String productKindId,
    required String materialId,
    required bool includeDelivery,
    required bool includeAreaRevenue,
  }) {
    final price = _linePrices[materialId];
    final manualQuantity = _inputMethodId == InputMethodIds.manualPerProduct
        ? _parseInt(_manualLineQuantities[materialId]?.text ?? '')
        : _parseInt(_manual.text);
    return ProductSaleInput(
      productKindId: productKindId,
      materialId: materialId,
      askModeId: _usesCeilingAskModes ? _askModeId : null,
      offerId: _usesCeilingAskModes && _askMode.requiresOffer ? _offerId : null,
      inputMethodId: _inputMethodId,
      chargeMethodId: _chargeMethodId,
      areaM2: _parseDouble(_area.text),
      widthM: _parseDouble(_width.text),
      lengthM: _parseDouble(_length.text),
      looseQuantity: _parseInt(_loose.text),
      boxQuantity: _parseInt(_boxes.text),
      manualQuantity: manualQuantity,
      saleUnitPrice: _parseDouble(price?.saleUnit.text ?? ''),
      saleBoxPrice: _parseDouble(price?.saleBox.text ?? ''),
      salePricePerM2: _parseDouble(_areaSalePrice.text),
      includeAreaRevenue: includeAreaRevenue,
      manualTotalPrice: _parseDouble(_manualTotal.text),
      useSavedPriceAsDefault: true,
      includeDelivery: includeDelivery,
      deliveryModeId: _deliveryModeId,
      deliveryPayerId: includeDelivery
          ? _deliveryPayerId
          : DeliveryPayerIds.noDelivery,
      deliveryRate: _parseDouble(_deliveryFee.text) ?? 0,
      allowSaleBelowCost: state.allowSaleBelowCost,
    );
  }

  List<MaterialItem> _products(AppState state) {
    final materials = state.materials.where((material) {
      if (!material.active) return false;
      if (widget.config.categoryIds.isEmpty) return true;
      if (!widget.config.categoryIds.contains(material.categoryId)) {
        return false;
      }
      if (_usesCeilingAskModes &&
          (_askMode.id == CustomerAskModeIds.boxProductSale ||
              _askMode.id == CustomerAskModeIds.boxPlusLooseSale) &&
          !_productHasBoxPrice(state, material.id)) {
        return false;
      }
      return true;
    }).toList()..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return materials;
  }

  List<String> _activeMaterialIds(AppState state) {
    if (_usesCeilingAskModes) {
      final mode = _askMode;
      if (mode.requiresOffer) {
        return _templateMaterialIds(state, _offerId);
      }
      return switch (mode.id) {
        CustomerAskModeIds.materialsByWidthLength ||
        CustomerAskModeIds.materialsOnly => _templateMaterialIds(
          state,
          'ceiling_full_set',
        ),
        CustomerAskModeIds.ceilingSheetsByWidthLength => const ['ceiling_6mm'],
        _ => _materialId == null ? const [] : [_materialId!],
      };
    }
    if (widget.config.supportsCeilingFullSet && _ceilingFullSet) {
      final template = state.productTemplates
          .where((item) => item.id == 'ceiling_full_set')
          .firstOrNull;
      return template?.defaultMaterialRules
              .where((rule) => rule.includedByDefault)
              .map((rule) => rule.materialId)
              .toList() ??
          const [];
    }
    return _materialId == null ? const [] : [_materialId!];
  }

  List<String> _templateMaterialIds(AppState state, String productKindId) {
    final template = state.productTemplates
        .where((item) => item.id == productKindId)
        .firstOrNull;
    return template?.defaultMaterialRules
            .where((rule) => rule.includedByDefault)
            .map((rule) => rule.materialId)
            .toList() ??
        const [];
  }

  List<MaterialItem> _activeMaterials(AppState state) {
    final byId = {
      for (final material in state.materials) material.id: material,
    };
    return [
      for (final materialId in _activeMaterialIds(state))
        if (byId[materialId] != null) byId[materialId]!,
    ];
  }

  String? _inputHelperText(AppState state) {
    if (_inputMethodId == InputMethodIds.widthLength) {
      final width = _parseDouble(_width.text) ?? 0;
      final length = _parseDouble(_length.text) ?? 0;
      if (width <= 0 || length <= 0) return null;
      return 'ការ៉េ = ទទឹង × បណ្ដោយ = ${MoneyFormatter.decimal(width * length)} m²';
    }
    if (_inputMethodId == InputMethodIds.ceilingLooseSheets ||
        _inputMethodId == InputMethodIds.ceilingBoxQuantity ||
        _inputMethodId == InputMethodIds.ceilingBoxPlusLoose) {
      final coverage = _ceilingCoverageM2(state);
      final itemsPerBox = _ceilingItemsPerBox(state);
      final boxes = _parseInt(_boxes.text) ?? 0;
      final loose = _parseInt(_loose.text) ?? 0;
      final ceilingSheets = switch (_inputMethodId) {
        InputMethodIds.ceilingLooseSheets => loose,
        InputMethodIds.ceilingBoxQuantity => breakdownFromBoxQuantity(
          boxQuantity: boxes,
          itemsPerBox: itemsPerBox,
        ).totalQuantity,
        _ => breakdownFromBoxPlusLoose(
          boxQuantity: boxes,
          looseQuantity: loose,
          itemsPerBox: itemsPerBox,
        ).totalQuantity,
      };
      if (ceilingSheets <= 0) return null;
      return 'ការ៉េប៉ាន់ស្មាន: ${MoneyFormatter.decimal(ceilingSheets * coverage)} m²';
    }
    return null;
  }

  double _ceilingCoverageM2(AppState state) {
    final template = state.productTemplates
        .where((item) => item.id == 'ceiling_full_set')
        .firstOrNull;
    final rule = template?.defaultMaterialRules
        .where((item) => item.materialId == 'ceiling_6mm')
        .firstOrNull;
    final material = state.materials
        .where((item) => item.id == 'ceiling_6mm')
        .firstOrNull;
    final value = rule?.coverageValueOverride ?? material?.coverageValue;
    return value == null || value <= 0 ? 0.36 : value;
  }

  int _ceilingItemsPerBox(AppState state) {
    final rule = state.packagingRules
        .where((item) => item.materialId == 'ceiling_6mm' && item.active)
        .firstOrNull;
    final material = state.materials
        .where((item) => item.id == 'ceiling_6mm')
        .firstOrNull;
    final value = rule?.itemsPerBox ?? material?.itemsPerBox ?? 12;
    return value <= 0 ? 12 : value;
  }

  void _ensurePriceControllers(AppState state, List<String> materialIds) {
    for (final materialId in materialIds) {
      _linePrices.putIfAbsent(materialId, () {
        final controllers = _LinePriceControllers(
          saleUnit: _initialPriceText(
            state,
            materialId,
            PriceTypeIds.saleUnitPrice,
            fallback: PriceTypeIds.unitPrice,
          ),
          saleBox: _initialPriceText(
            state,
            materialId,
            PriceTypeIds.saleBoxPrice,
            fallback: PriceTypeIds.boxPrice,
          ),
        );
        controllers.addListener(_refresh);
        return controllers;
      });
    }
  }

  void _ensureManualLineControllers(AppState state, List<String> materialIds) {
    for (final materialId in materialIds) {
      _manualLineQuantities.putIfAbsent(materialId, () {
        final controller = TextEditingController(text: '1');
        controller.addListener(_refresh);
        return controller;
      });
    }
  }

  void _clearManualLineControllers() {
    for (final controller in _manualLineQuantities.values) {
      controller.dispose();
    }
    _manualLineQuantities.clear();
  }

  String _initialPriceText(
    AppState state,
    String materialId,
    String priceTypeId, {
    String? fallback,
  }) {
    return '${_price(state.prices, materialId, priceTypeId, fallback: fallback) ?? 0}';
  }

  String get _areaSalePriceProductKindId {
    if (_usesCeilingAskModes && _askMode.requiresOffer) {
      return _offerId;
    }
    if (widget.config.supportsCeilingFullSet && _ceilingFullSet) {
      return 'ceiling_full_set';
    }
    return widget.config.templateId;
  }

  void _ensureAreaSalePriceController(AppState state) {
    final productKindId = _areaSalePriceProductKindId;
    if (_loadedAreaSalePriceProductKindId == productKindId &&
        _loadedAreaUseSavedPriceAsDefault == state.useSavedPriceAsDefault) {
      return;
    }
    _loadedAreaSalePriceProductKindId = productKindId;
    _loadedAreaUseSavedPriceAsDefault = state.useSavedPriceAsDefault;
    _areaSalePrice.text = state.useSavedPriceAsDefault
        ? _initialAreaSalePriceText(state, productKindId)
        : '0';
  }

  String _initialAreaSalePriceText(AppState state, String productKindId) {
    return '${_price(state.prices, productKindId, PriceTypeIds.areaM2SalePrice, fallback: PriceTypeIds.servicePrice) ?? 0}';
  }

  Future<void> _saveCurrentAreaPriceAsDefault(AppState state) async {
    final now = DateTime.now();
    final productKindId = _areaSalePriceProductKindId;
    await state.savePrice(
      MaterialPrice(
        id: '${productKindId}_${PriceTypeIds.areaM2SalePrice}',
        materialId: productKindId,
        priceTypeId: PriceTypeIds.areaM2SalePrice,
        price: _parseDouble(_areaSalePrice.text) ?? 0,
        currencyCode: 'USD',
        effectiveFrom: DateTime(2020),
        effectiveTo: null,
        active: true,
        createdAt: now,
        updatedAt: now,
      ),
    );
    _loadedAreaSalePriceProductKindId = null;
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('បានរក្សាទុកតម្លៃការ៉េ។')));
    }
  }

  Future<void> _saveCurrentPricesAsDefaults(
    AppState state,
    List<ProductSaleResult> results,
  ) async {
    final now = DateTime.now();
    for (final result in results) {
      final price = _linePrices[result.materialId];
      if (price == null) continue;
      for (final item in [
        MapEntry(PriceTypeIds.saleUnitPrice, price.saleUnit),
        MapEntry(PriceTypeIds.saleBoxPrice, price.saleBox),
      ]) {
        await state.savePrice(
          MaterialPrice(
            id: '${result.materialId}_${item.key}',
            materialId: result.materialId,
            priceTypeId: item.key,
            price: _parseDouble(item.value.text) ?? 0,
            currencyCode: 'USD',
            effectiveFrom: DateTime(2020),
            effectiveTo: null,
            active: true,
            createdAt: now,
            updatedAt: now,
          ),
        );
      }
    }
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('បានរក្សាទុកតម្លៃលក់។')));
    }
  }

  void _addToTemporaryList(List<ProductSaleResult> results) {
    context.read<AppState>().addTemporarySaleResults(results);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('បានបន្ថែមទៅបញ្ជីបណ្ដោះអាសន្ន។')),
    );
  }

  void _copySummary(List<ProductSaleResult> results) {
    Clipboard.setData(ClipboardData(text: _summaryText(results)));
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('បានចម្លងសង្ខេប។')));
  }

  void _refresh() {
    if (mounted) setState(() {});
  }
}

class _LinePriceControllers {
  _LinePriceControllers({required String saleUnit, required String saleBox})
    : saleUnit = TextEditingController(text: saleUnit),
      saleBox = TextEditingController(text: saleBox);

  final TextEditingController saleUnit;
  final TextEditingController saleBox;

  void addListener(VoidCallback listener) {
    saleUnit.addListener(listener);
    saleBox.addListener(listener);
  }

  void dispose() {
    saleUnit.dispose();
    saleBox.dispose();
  }
}

class _ResultsTable extends StatelessWidget {
  const _ResultsTable({
    required this.results,
    required this.areaSale,
    required this.quantityOnly,
    required this.linePrices,
    required this.onChanged,
  });

  final List<ProductSaleResult> results;
  final bool areaSale;
  final bool quantityOnly;
  final Map<String, _LinePriceControllers> linePrices;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    if (results.isEmpty) {
      return const Text(
        'មិនមានលទ្ធផល',
        style: TextStyle(color: _textSecondary),
      );
    }
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        headingRowHeight: 42,
        dataRowMinHeight: 58,
        dataRowMaxHeight: 66,
        columns: quantityOnly
            ? const [
                DataColumn(label: Text('ផលិតផល')),
                DataColumn(label: Text('ចំនួន')),
                DataColumn(label: Text('កេស')),
                DataColumn(label: Text('រាយ')),
              ]
            : areaSale
            ? const [
                DataColumn(label: Text('ផលិតផល')),
                DataColumn(label: Text('ចំនួន')),
                DataColumn(label: Text('កេស')),
                DataColumn(label: Text('រាយ')),
                DataColumn(label: Text('ថ្លៃដើម')),
              ]
            : const [
                DataColumn(label: Text('ផលិតផល')),
                DataColumn(label: Text('ចំនួន')),
                DataColumn(label: Text('កេស')),
                DataColumn(label: Text('រាយ')),
                DataColumn(label: Text('របៀបគិតលុយ')),
                DataColumn(label: Text('តម្លៃលក់')),
                DataColumn(label: Text('អតិថិជនបង់')),
                DataColumn(label: Text('ថ្លៃដើម')),
                DataColumn(label: Text('ចំណេញ')),
              ],
        rows: [
          for (final result in results)
            DataRow(
              color: result.belowCost
                  ? WidgetStatePropertyAll(_danger.withValues(alpha: 0.08))
                  : null,
              cells: quantityOnly
                  ? _quantityOnlyCells(result)
                  : areaSale
                  ? _areaSaleCells(result)
                  : _standardCells(result),
            ),
        ],
      ),
    );
  }

  List<DataCell> _areaSaleCells(ProductSaleResult result) {
    return [
      DataCell(Text(_productResultLabel(result))),
      DataCell(Text('${result.sellQuantity} ${result.unitKhmer}')),
      DataCell(Text('${result.packagingFullBoxes}')),
      DataCell(Text('${result.packagingLooseItems}')),
      DataCell(Text(MoneyFormatter.money(result.productCost))),
    ];
  }

  List<DataCell> _quantityOnlyCells(ProductSaleResult result) {
    return [
      DataCell(Text(_productResultLabel(result))),
      DataCell(Text('${result.sellQuantity} ${result.unitKhmer}')),
      DataCell(Text('${result.packagingFullBoxes}')),
      DataCell(Text('${result.packagingLooseItems}')),
    ];
  }

  List<DataCell> _standardCells(ProductSaleResult result) {
    return [
      DataCell(Text(_productResultLabel(result))),
      DataCell(Text('${result.sellQuantity} ${result.unitKhmer}')),
      DataCell(Text('${result.packagingFullBoxes}')),
      DataCell(Text('${result.packagingLooseItems}')),
      DataCell(Text(result.chargeMethodNameKhmer)),
      _salePriceCell(result),
      DataCell(Text(MoneyFormatter.money(result.customerPayTotal))),
      DataCell(Text(MoneyFormatter.money(result.ownerCostTotal))),
      DataCell(
        Text(
          MoneyFormatter.money(result.ownerProfit),
          style: TextStyle(
            color: result.ownerProfit < 0 ? _danger : _success,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    ];
  }

  DataCell _salePriceCell(ProductSaleResult result) {
    final price = linePrices[result.materialId];
    if (price == null) {
      return const DataCell(Text('-'));
    }
    return switch (result.chargeMethodId) {
      ChargeMethodIds.unitOnly => DataCell(
        _priceInput(price.saleUnit, suffix: '/ រាយ'),
      ),
      ChargeMethodIds.boxOnly => DataCell(
        _priceInput(price.saleBox, suffix: '/ កេស'),
      ),
      ChargeMethodIds.boxPlusLoose => DataCell(
        SizedBox(
          width: 260,
          child: Row(
            children: [
              Expanded(child: _priceInput(price.saleBox, suffix: '/ កេស')),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Text('+', style: TextStyle(color: _textSecondary)),
              ),
              Expanded(child: _priceInput(price.saleUnit, suffix: '/ រាយ')),
            ],
          ),
        ),
      ),
      ChargeMethodIds.areaM2Price => DataCell(
        Text('${MoneyFormatter.money(result.salePricePerM2)} / ការ៉េ'),
      ),
      ChargeMethodIds.manualTotal => DataCell(
        Text(
          MoneyFormatter.money(
            result.manualTotalPrice ?? result.productRevenue,
          ),
        ),
      ),
      _ => const DataCell(Text('-')),
    };
  }

  Widget _priceInput(
    TextEditingController controller, {
    required String suffix,
  }) {
    return SizedBox(
      width: 122,
      child: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          isDense: true,
          prefixText: r'$',
          suffixText: suffix,
        ),
        onChanged: (_) => onChanged(),
      ),
    );
  }
}

class _TemporarySaleScreen extends StatelessWidget {
  const _TemporarySaleScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final summary = state.temporarySaleSummary;
    return _Page(
      child: _Panel(
        title: 'បញ្ជីលក់បច្ចុប្បន្ន',
        icon: Icons.receipt_long_rounded,
        scrollBody: true,
        trailing: Wrap(
          spacing: 8,
          children: [
            FilledButton.icon(
              onPressed: summary.items.isEmpty
                  ? null
                  : () => _copyCartSummary(context, summary.items),
              icon: const Icon(Icons.copy_rounded, size: 18),
              label: const Text('ចម្លងសង្ខេប'),
            ),
            OutlinedButton.icon(
              onPressed: summary.items.isEmpty
                  ? null
                  : () => context.read<AppState>().clearTemporarySale(),
              icon: const Icon(Icons.delete_sweep_rounded, size: 18),
              label: const Text('សម្អាតទាំងអស់'),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _MetricTile('ចំនួនផលិតផលសរុប', '${summary.totalQuantity}'),
                _MetricTile(
                  'អតិថិជនបង់សរុប',
                  MoneyFormatter.money(summary.customerPayTotal),
                ),
                _MetricTile(
                  'ថ្លៃដើមសរុប',
                  MoneyFormatter.money(summary.ownerCostTotal),
                ),
                _MetricTile(
                  'ចំណេញសរុប',
                  MoneyFormatter.money(summary.ownerProfit),
                  accent: summary.ownerProfit < 0 ? _danger : _success,
                ),
              ],
            ),
            const SizedBox(height: 14),
            _TemporarySaleTable(items: summary.items),
          ],
        ),
      ),
    );
  }

  void _copyCartSummary(BuildContext context, List<ProductSaleResult> items) {
    Clipboard.setData(ClipboardData(text: _summaryText(items)));
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('បានចម្លងសង្ខេប។')));
  }
}

class _TemporarySaleTable extends StatelessWidget {
  const _TemporarySaleTable({required this.items});

  final List<ProductSaleResult> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const Text(
        'មិនទាន់មានផលិតផលក្នុងបញ្ជី',
        style: TextStyle(color: _textSecondary),
      );
    }
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        columns: const [
          DataColumn(label: Text('ល.រ')),
          DataColumn(label: Text('ប្រភេទ')),
          DataColumn(label: Text('ផលិតផល')),
          DataColumn(label: Text('របៀបបញ្ចូល')),
          DataColumn(label: Text('របៀបគិតលុយ')),
          DataColumn(label: Text('ចំនួន')),
          DataColumn(label: Text('កេស')),
          DataColumn(label: Text('រាយ')),
          DataColumn(label: Text('អតិថិជនបង់')),
          DataColumn(label: Text('ថ្លៃដើម')),
          DataColumn(label: Text('ចំណេញ')),
          DataColumn(label: Text('ស្ថានភាព')),
          DataColumn(label: Text('')),
        ],
        rows: [
          for (var i = 0; i < items.length; i++)
            DataRow(
              cells: [
                DataCell(Text('${i + 1}')),
                DataCell(Text(items[i].productKindNameKhmer)),
                DataCell(Text(_productResultLabel(items[i]))),
                DataCell(Text(items[i].inputMethodNameKhmer)),
                DataCell(Text(items[i].chargeMethodNameKhmer)),
                DataCell(Text('${items[i].sellQuantity}')),
                DataCell(Text('${items[i].packagingFullBoxes}')),
                DataCell(Text('${items[i].packagingLooseItems}')),
                DataCell(Text(MoneyFormatter.money(items[i].customerPayTotal))),
                DataCell(Text(MoneyFormatter.money(items[i].ownerCostTotal))),
                DataCell(Text(MoneyFormatter.money(items[i].ownerProfit))),
                DataCell(Text(items[i].canSellStatusNameKhmer)),
                DataCell(
                  IconButton(
                    tooltip: 'លុបមួយមុខ',
                    onPressed: () =>
                        context.read<AppState>().removeTemporarySaleItem(i),
                    icon: const Icon(Icons.delete_outline_rounded, size: 19),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

class _ProductsDataScreen extends StatelessWidget {
  const _ProductsDataScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final products = [...state.materials]
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return _Page(
      child: _Panel(
        title: 'ផលិតផល',
        icon: Icons.inventory_2_outlined,
        fillHeight: true,
        child: _PanelList(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return _ListRow(
              title: _productLabel(product),
              subtitle:
                  '${product.categoryKhmer} • ${product.unitKhmer} • ${product.formulaTypeId}',
              trailing: Switch(
                value: product.active,
                onChanged: (value) =>
                    state.saveMaterial(product.copyWith(active: value)),
              ),
              onEdit: () async {
                final saved = await showDialog<MaterialItem>(
                  context: context,
                  builder: (_) => _ProductDialog(
                    product: product,
                    categories: state.categories,
                    units: state.units,
                  ),
                );
                if (saved != null) await state.saveMaterial(saved);
              },
            );
          },
        ),
      ),
    );
  }
}

class _PricesDataScreen extends StatelessWidget {
  const _PricesDataScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final products = [...state.materials]
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return _Page(
      child: _Panel(
        title: 'តម្លៃ',
        icon: Icons.sell_outlined,
        fillHeight: true,
        child: _PanelList(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return _ListRow(
              title: _productLabel(product),
              subtitle:
                  'លក់រាយ ${_moneyOrDash(_price(state.prices, product.id, PriceTypeIds.saleUnitPrice, fallback: PriceTypeIds.unitPrice))} • លក់កេស ${_moneyOrDash(_price(state.prices, product.id, PriceTypeIds.saleBoxPrice, fallback: PriceTypeIds.boxPrice))} • ដើមរាយ ${_moneyOrDash(_price(state.prices, product.id, PriceTypeIds.costUnitPrice))}',
              onEdit: () async {
                final saved = await showDialog<List<MaterialPrice>>(
                  context: context,
                  builder: (_) =>
                      _PriceDialog(product: product, prices: state.prices),
                );
                if (saved != null) {
                  for (final price in saved) {
                    await state.savePrice(price);
                  }
                }
              },
            );
          },
        ),
      ),
    );
  }
}

class _PackagingDataScreen extends StatelessWidget {
  const _PackagingDataScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final rulesByMaterial = {
      for (final rule in state.packagingRules) rule.materialId: rule,
    };
    final products = [...state.materials]
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return _Page(
      child: _Panel(
        title: 'ការវេចខ្ចប់',
        icon: Icons.all_inbox_outlined,
        fillHeight: true,
        child: _PanelList(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return _ListRow(
              title: _productLabel(product),
              subtitle:
                  '${rulesByMaterial[product.id]?.itemsPerBox ?? product.itemsPerBox ?? 1} ក្នុងកេស',
              onEdit: () async {
                final saved = await showDialog<PackagingRule>(
                  context: context,
                  builder: (_) => _PackagingDialog(
                    product: product,
                    rule: rulesByMaterial[product.id],
                  ),
                );
                if (saved != null) await state.savePackagingRule(saved);
              },
            );
          },
        ),
      ),
    );
  }
}

class _ProductKindsDataScreen extends StatelessWidget {
  const _ProductKindsDataScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final templates = [...state.productTemplates]
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return _Page(
      child: _Panel(
        title: 'ប្រភេទផលិតផល',
        icon: Icons.category_outlined,
        fillHeight: true,
        child: _PanelList(
          itemCount: templates.length,
          itemBuilder: (context, index) {
            final template = templates[index];
            return _ListRow(
              title: template.nameKhmer,
              subtitle: '${template.defaultMaterialRules.length} ផលិតផល',
              trailing: Switch(
                value: template.active,
                onChanged: (value) =>
                    state.saveProductTemplate(template.copyWith(active: value)),
              ),
              onEdit: () async {
                final saved = await showDialog<ProductTypeTemplate>(
                  context: context,
                  builder: (_) => _ProductKindDialog(template: template),
                );
                if (saved != null) await state.saveProductTemplate(saved);
              },
            );
          },
        ),
      ),
    );
  }
}

class _FormulaRulesDataScreen extends StatelessWidget {
  const _FormulaRulesDataScreen();

  @override
  Widget build(BuildContext context) {
    final rules = context.watch<AppState>().formulaRules;
    return _Page(
      child: _Panel(
        title: 'រូបមន្តគណនា',
        icon: Icons.functions_rounded,
        fillHeight: true,
        child: _PanelList(
          itemCount: rules.length,
          itemBuilder: (context, index) {
            final rule = rules[index];
            return _ListRow(
              title: rule.nameKhmer,
              subtitle: rule.formulaTypeId,
            );
          },
        ),
      ),
    );
  }
}

class _UnitsCategoriesDataScreen extends StatelessWidget {
  const _UnitsCategoriesDataScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return _Page(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: _Panel(
              title: 'ឯកតា',
              icon: Icons.straighten_rounded,
              fillHeight: true,
              child: _PanelList(
                itemCount: state.units.length,
                itemBuilder: (context, index) {
                  final unit = state.units[index];
                  return _ListRow(
                    title: unit.nameKhmer,
                    subtitle: unit.abbreviationKhmer,
                    onEdit: () async {
                      final saved = await showDialog<UnitOfMeasure>(
                        context: context,
                        builder: (_) => _UnitDialog(unit: unit),
                      );
                      if (saved != null) await state.saveUnit(saved);
                    },
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: _Panel(
              title: 'ប្រភេទ',
              icon: Icons.category_outlined,
              fillHeight: true,
              child: _PanelList(
                itemCount: state.categories.length,
                itemBuilder: (context, index) {
                  final category = state.categories[index];
                  return _ListRow(
                    title: category.nameKhmer,
                    subtitle: category.id,
                    onEdit: () async {
                      final saved = await showDialog<MaterialCategory>(
                        context: context,
                        builder: (_) => _CategoryDialog(category: category),
                      );
                      if (saved != null) await state.saveCategory(saved);
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AppSettingsDataScreen extends StatelessWidget {
  const _AppSettingsDataScreen();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return _Page(
      child: _Panel(
        title: 'ការកំណត់កម្មវិធី',
        icon: Icons.settings_outlined,
        scrollBody: true,
        child: Column(
          children: [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: state.useSavedPriceAsDefault,
              title: const Text('ប្រើតម្លៃរក្សាទុកជាតម្លៃដើម'),
              subtitle: const Text(
                'បិទ = ការគណនាចាប់ផ្តើមតម្លៃ 0 ហើយវាយតម្លៃថ្មីពេលលក់',
              ),
              onChanged: state.setUseSavedPriceAsDefault,
            ),
            const Divider(),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: state.allowSaleBelowCost,
              title: const Text('អនុញ្ញាតលក់ទាបជាងថ្លៃដើម'),
              subtitle: const Text(
                'បិទ = មិនអាចបន្ថែមទៅបញ្ជីបណ្ដោះអាសន្នបើខាត',
              ),
              onChanged: state.setAllowSaleBelowCost,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _MetricTile('ផលិតផល', '${state.materials.length}'),
                _MetricTile('តម្លៃ', '${state.prices.length}'),
                _MetricTile(
                  'បញ្ជីបណ្ដោះអាសន្ន',
                  '${state.currentSaleItems.length}',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductDialog extends StatefulWidget {
  const _ProductDialog({
    required this.product,
    required this.categories,
    required this.units,
  });

  final MaterialItem product;
  final List<MaterialCategory> categories;
  final List<UnitOfMeasure> units;

  @override
  State<_ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<_ProductDialog> {
  late final TextEditingController _khmer;
  late final TextEditingController _english;
  late final TextEditingController _spec;
  late final TextEditingController _coverage;
  late final TextEditingController _multiplier;
  late final TextEditingController _itemsPerBox;
  late String _categoryId;
  late String _unitId;
  late String _formulaTypeId;
  late bool _active;

  @override
  void initState() {
    super.initState();
    _khmer = TextEditingController(text: widget.product.khmerName);
    _english = TextEditingController(text: widget.product.englishName);
    _spec = TextEditingController(text: widget.product.spec);
    _coverage = TextEditingController(
      text: widget.product.coverageValue?.toString() ?? '',
    );
    _multiplier = TextEditingController(
      text: widget.product.multiplierValue?.toString() ?? '',
    );
    _itemsPerBox = TextEditingController(
      text: (widget.product.itemsPerBox ?? 1).toString(),
    );
    _categoryId = widget.product.categoryId;
    _unitId = widget.product.unitId;
    _formulaTypeId = widget.product.formulaTypeId;
    _active = widget.product.active;
  }

  @override
  void dispose() {
    _khmer.dispose();
    _english.dispose();
    _spec.dispose();
    _coverage.dispose();
    _multiplier.dispose();
    _itemsPerBox.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('កែផលិតផល'),
      content: SizedBox(
        width: 720,
        child: SingleChildScrollView(
          child: Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _dialogField(_khmer, 'ឈ្មោះផលិតផល'),
              _dialogField(_english, 'កូដ / ឈ្មោះបច្ចេកទេស'),
              _dialogField(_spec, 'លក្ខណៈ'),
              _dropdown(
                label: 'ប្រភេទផលិតផល',
                value: _categoryId,
                items: widget.categories
                    .map((item) => MapEntry(item.id, item.nameKhmer))
                    .toList(),
                onChanged: (value) => setState(() => _categoryId = value),
              ),
              _dropdown(
                label: 'ឯកតា',
                value: _unitId,
                items: widget.units
                    .map((item) => MapEntry(item.id, item.nameKhmer))
                    .toList(),
                onChanged: (value) => setState(() => _unitId = value),
              ),
              _dropdown(
                label: 'រូបមន្តគណនា',
                value: _formulaTypeId,
                items: FormulaTypeIds.supportedNow
                    .map((id) => MapEntry(id, id))
                    .toList(),
                onChanged: (value) => setState(() => _formulaTypeId = value),
              ),
              _dialogField(_coverage, 'តម្លៃគ្របដណ្ដប់', number: true),
              _dialogField(_multiplier, 'មេគុណ', number: true),
              _dialogField(_itemsPerBox, 'ចំនួនក្នុងកេស', number: true),
              SizedBox(
                width: 210,
                child: SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _active,
                  title: const Text('សកម្ម'),
                  onChanged: (value) => setState(() => _active = value),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('បោះបង់'),
        ),
        FilledButton(onPressed: _save, child: const Text('រក្សាទុក')),
      ],
    );
  }

  void _save() {
    final category = widget.categories.firstWhere(
      (item) => item.id == _categoryId,
      orElse: () => widget.categories.first,
    );
    final unit = widget.units.firstWhere(
      (item) => item.id == _unitId,
      orElse: () => widget.units.first,
    );
    Navigator.pop(
      context,
      widget.product.copyWith(
        khmerName: _khmer.text.trim(),
        englishName: _english.text.trim(),
        spec: _spec.text.trim(),
        categoryId: category.id,
        categoryKhmer: category.nameKhmer,
        categoryEnglish: category.nameEnglish,
        unitId: unit.id,
        unitKhmer: unit.abbreviationKhmer,
        unitEnglish: unit.abbreviationEnglish,
        formulaTypeId: _formulaTypeId,
        coverageValue: _parseDouble(_coverage.text),
        clearCoverageValue: _coverage.text.trim().isEmpty,
        multiplierValue: _parseDouble(_multiplier.text),
        clearMultiplierValue: _multiplier.text.trim().isEmpty,
        itemsPerBox: _parseInt(_itemsPerBox.text) ?? 1,
        active: _active,
      ),
    );
  }
}

class _PriceDialog extends StatefulWidget {
  const _PriceDialog({required this.product, required this.prices});

  final MaterialItem product;
  final List<MaterialPrice> prices;

  @override
  State<_PriceDialog> createState() => _PriceDialogState();
}

class _PriceDialogState extends State<_PriceDialog> {
  late final TextEditingController _saleUnit;
  late final TextEditingController _saleBox;
  late final TextEditingController _costUnit;
  late final TextEditingController _costBox;

  @override
  void initState() {
    super.initState();
    _saleUnit = TextEditingController(
      text:
          '${_price(widget.prices, widget.product.id, PriceTypeIds.saleUnitPrice, fallback: PriceTypeIds.unitPrice) ?? 0}',
    );
    _saleBox = TextEditingController(
      text:
          '${_price(widget.prices, widget.product.id, PriceTypeIds.saleBoxPrice, fallback: PriceTypeIds.boxPrice) ?? 0}',
    );
    _costUnit = TextEditingController(
      text:
          '${_price(widget.prices, widget.product.id, PriceTypeIds.costUnitPrice) ?? 0}',
    );
    _costBox = TextEditingController(
      text:
          '${_price(widget.prices, widget.product.id, PriceTypeIds.costBoxPrice) ?? 0}',
    );
  }

  @override
  void dispose() {
    _saleUnit.dispose();
    _saleBox.dispose();
    _costUnit.dispose();
    _costBox.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('តម្លៃ ${widget.product.khmerName}'),
      content: SizedBox(
        width: 470,
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _dialogField(_saleUnit, 'តម្លៃលក់រាយ', number: true),
            _dialogField(_saleBox, 'តម្លៃលក់កេស', number: true),
            _dialogField(_costUnit, 'ថ្លៃដើមរាយ', number: true),
            _dialogField(_costBox, 'ថ្លៃដើមកេស', number: true),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('បោះបង់'),
        ),
        FilledButton(onPressed: _save, child: const Text('រក្សាទុក')),
      ],
    );
  }

  void _save() {
    final now = DateTime.now();
    MaterialPrice build(String typeId, TextEditingController controller) {
      return MaterialPrice(
        id: '${widget.product.id}_$typeId',
        materialId: widget.product.id,
        priceTypeId: typeId,
        price: _parseDouble(controller.text) ?? 0,
        currencyCode: 'USD',
        effectiveFrom: DateTime(2020),
        effectiveTo: null,
        active: true,
        createdAt: now,
        updatedAt: now,
      );
    }

    Navigator.pop(context, [
      build(PriceTypeIds.saleUnitPrice, _saleUnit),
      build(PriceTypeIds.saleBoxPrice, _saleBox),
      build(PriceTypeIds.costUnitPrice, _costUnit),
      build(PriceTypeIds.costBoxPrice, _costBox),
    ]);
  }
}

class _PackagingDialog extends StatefulWidget {
  const _PackagingDialog({required this.product, this.rule});

  final MaterialItem product;
  final PackagingRule? rule;

  @override
  State<_PackagingDialog> createState() => _PackagingDialogState();
}

class _PackagingDialogState extends State<_PackagingDialog> {
  late final TextEditingController _items;
  late bool _active;

  @override
  void initState() {
    super.initState();
    _items = TextEditingController(
      text: '${widget.rule?.itemsPerBox ?? widget.product.itemsPerBox ?? 1}',
    );
    _active = widget.rule?.active ?? true;
  }

  @override
  void dispose() {
    _items.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('ការវេចខ្ចប់ ${widget.product.khmerName}'),
      content: SizedBox(
        width: 300,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _dialogField(_items, 'ចំនួនក្នុងកេស', number: true),
            SwitchListTile(
              value: _active,
              title: const Text('សកម្ម'),
              onChanged: (value) => setState(() => _active = value),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('បោះបង់'),
        ),
        FilledButton(onPressed: _save, child: const Text('រក្សាទុក')),
      ],
    );
  }

  void _save() {
    Navigator.pop(
      context,
      PackagingRule(
        id: widget.rule?.id ?? 'packaging_${widget.product.id}',
        materialId: widget.product.id,
        itemsPerBox: _parseInt(_items.text) ?? 1,
        boxUnitNameKhmer: 'កេស',
        boxUnitNameEnglish: 'Box',
        size: widget.rule?.size ?? '',
        length: widget.rule?.length ?? '',
        note: widget.rule?.note ?? '',
        active: _active,
        updatedAt: DateTime.now(),
      ),
    );
  }
}

class _ProductKindDialog extends StatefulWidget {
  const _ProductKindDialog({required this.template});

  final ProductTypeTemplate template;

  @override
  State<_ProductKindDialog> createState() => _ProductKindDialogState();
}

class _ProductKindDialogState extends State<_ProductKindDialog> {
  late final TextEditingController _khmer;
  late bool _active;

  @override
  void initState() {
    super.initState();
    _khmer = TextEditingController(text: widget.template.nameKhmer);
    _active = widget.template.active;
  }

  @override
  void dispose() {
    _khmer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('កែប្រភេទផលិតផល'),
      content: SizedBox(
        width: 320,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _dialogField(_khmer, 'ឈ្មោះ'),
            SwitchListTile(
              value: _active,
              title: const Text('សកម្ម'),
              onChanged: (value) => setState(() => _active = value),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('បោះបង់'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            widget.template.copyWith(nameKhmer: _khmer.text, active: _active),
          ),
          child: const Text('រក្សាទុក'),
        ),
      ],
    );
  }
}

class _UnitDialog extends StatefulWidget {
  const _UnitDialog({required this.unit});

  final UnitOfMeasure unit;

  @override
  State<_UnitDialog> createState() => _UnitDialogState();
}

class _UnitDialogState extends State<_UnitDialog> {
  late final TextEditingController _name;
  late final TextEditingController _abbr;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.unit.nameKhmer);
    _abbr = TextEditingController(text: widget.unit.abbreviationKhmer);
  }

  @override
  void dispose() {
    _name.dispose();
    _abbr.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('កែឯកតា'),
      content: SizedBox(
        width: 320,
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _dialogField(_name, 'ឈ្មោះ'),
            _dialogField(_abbr, 'អក្សរកាត់'),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('បោះបង់'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            widget.unit.copyWith(
              nameKhmer: _name.text.trim(),
              abbreviationKhmer: _abbr.text.trim(),
            ),
          ),
          child: const Text('រក្សាទុក'),
        ),
      ],
    );
  }
}

class _CategoryDialog extends StatefulWidget {
  const _CategoryDialog({required this.category});

  final MaterialCategory category;

  @override
  State<_CategoryDialog> createState() => _CategoryDialogState();
}

class _CategoryDialogState extends State<_CategoryDialog> {
  late final TextEditingController _name;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.category.nameKhmer);
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('កែប្រភេទ'),
      content: SizedBox(width: 280, child: _dialogField(_name, 'ឈ្មោះ')),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('បោះបង់'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            widget.category.copyWith(nameKhmer: _name.text.trim()),
          ),
          child: const Text('រក្សាទុក'),
        ),
      ],
    );
  }
}

class _Page extends StatelessWidget {
  const _Page({required this.child, this.floatingAction});

  final Widget child;
  final Widget? floatingAction;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Padding(padding: const EdgeInsets.all(18), child: child),
        ),
        if (floatingAction != null)
          Positioned(right: 22, bottom: 22, child: floatingAction!),
      ],
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({
    required this.title,
    required this.icon,
    required this.child,
    this.fillHeight = false,
    this.scrollBody = false,
    this.trailing,
  });

  final String title;
  final IconData icon;
  final Widget child;
  final bool fillHeight;
  final bool scrollBody;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final hasBoundedHeight = constraints.hasBoundedHeight;
        final shouldScrollBody = scrollBody && hasBoundedHeight;
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: fillHeight || shouldScrollBody
                ? MainAxisSize.max
                : MainAxisSize.min,
            children: [
              Row(
                children: [
                  Icon(icon, size: 20, color: _secondary),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  ?trailing,
                ],
              ),
              const SizedBox(height: 14),
              if (shouldScrollBody)
                _ScrollablePanelBody(child: child)
              else
                child,
            ],
          ),
        );
      },
    );
  }
}

class _ScrollablePanelBody extends StatefulWidget {
  const _ScrollablePanelBody({required this.child});

  final Widget child;

  @override
  State<_ScrollablePanelBody> createState() => _ScrollablePanelBodyState();
}

class _ScrollablePanelBodyState extends State<_ScrollablePanelBody> {
  final ScrollController _controller = ScrollController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scrollbar(
        controller: _controller,
        thumbVisibility: true,
        child: SingleChildScrollView(
          controller: _controller,
          child: widget.child,
        ),
      ),
    );
  }
}

class _PanelList extends StatefulWidget {
  const _PanelList({required this.itemCount, required this.itemBuilder});

  final int itemCount;
  final IndexedWidgetBuilder itemBuilder;

  @override
  State<_PanelList> createState() => _PanelListState();
}

class _PanelListState extends State<_PanelList> {
  final ScrollController _controller = ScrollController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scrollbar(
        controller: _controller,
        thumbVisibility: true,
        child: ListView.builder(
          controller: _controller,
          padding: EdgeInsets.zero,
          itemCount: widget.itemCount,
          itemBuilder: widget.itemBuilder,
        ),
      ),
    );
  }
}

class _ChoiceCards<T> extends StatelessWidget {
  const _ChoiceCards({
    required this.value,
    required this.values,
    required this.label,
    required this.icon,
    required this.onChanged,
  });

  final T value;
  final List<T> values;
  final String Function(T value) label;
  final IconData Function(T value) icon;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final item in values)
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => onChanged(item),
            child: Container(
              height: 42,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: item == value ? const Color(0xFF1D2440) : _surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: item == value ? _primary : _border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    icon(item),
                    size: 18,
                    color: item == value ? _primary : _textSecondary,
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      label(item),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: item == value ? _text : _textSecondary,
                        fontSize: 12.5,
                        fontWeight: item == value ? FontWeight.w800 : null,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile(this.label, this.value, {this.accent = _primary});

  final String label;
  final String value;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 176,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _textSecondary, fontSize: 12),
          ),
          const SizedBox(height: 5),
          Text(
            value,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: accent,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _SellStatusCard extends StatelessWidget {
  const _SellStatusCard({
    required this.results,
    required this.allowSaleBelowCost,
  });

  final List<ProductSaleResult> results;
  final bool allowSaleBelowCost;

  @override
  Widget build(BuildContext context) {
    final hasBelowCost =
        _areaSaleBelowCost(results) ||
        results.any((result) => result.belowCost);
    final hasZeroCost = results.any((result) => result.costZeroWarning);
    final color = hasBelowCost ? _danger : (hasZeroCost ? _warning : _success);
    final status = hasBelowCost
        ? 'មិនគួរលក់'
        : (hasZeroCost ? 'មិនទាន់ដឹងថ្លៃដើម' : 'អាចលក់បាន');
    final message = hasBelowCost
        ? allowSaleBelowCost
              ? 'តម្លៃលក់ទាបជាងថ្លៃដើម'
              : 'តម្លៃលក់ទាបជាងថ្លៃដើម — មិនអាចបន្ថែមទៅបញ្ជីបាន'
        : (hasZeroCost
              ? 'ថ្លៃដើមនៅជា 0 — មិនទាន់អាចវាយតម្លៃចំណេញពិតបានទេ'
              : 'តម្លៃលក់ខ្ពស់ជាង ឬស្មើថ្លៃដើម');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          Icon(
            hasBelowCost
                ? Icons.report_problem_outlined
                : (hasZeroCost
                      ? Icons.info_outline_rounded
                      : Icons.check_circle_outline_rounded),
            color: color,
            size: 22,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ស្ថានភាពលក់',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: _textSecondary,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  status,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  message,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: color, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorList extends StatelessWidget {
  const _ErrorList({required this.errors});

  final List<String> errors;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final error in errors.toSet())
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(error, style: const TextStyle(color: _danger)),
          ),
      ],
    );
  }
}

class _ListRow extends StatelessWidget {
  const _ListRow({
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onEdit,
  });

  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onEdit;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _text,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          ?trailing,
          IconButton(
            tooltip: 'កែ',
            onPressed: onEdit,
            icon: const Icon(Icons.edit_outlined, size: 19),
          ),
        ],
      ),
    );
  }
}

Widget _numberField(TextEditingController controller, String label) {
  return SizedBox(
    width: 196,
    child: TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label),
    ),
  );
}

Widget _dialogField(
  TextEditingController controller,
  String label, {
  bool number = false,
}) {
  return SizedBox(
    width: 210,
    child: TextField(
      controller: controller,
      keyboardType: number
          ? const TextInputType.numberWithOptions(decimal: true)
          : null,
      decoration: InputDecoration(labelText: label),
    ),
  );
}

Widget _dropdown({
  required String label,
  required String value,
  required List<MapEntry<String, String>> items,
  required ValueChanged<String> onChanged,
}) {
  return SizedBox(
    width: 210,
    child: DropdownButtonFormField<String>(
      initialValue: value,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: items
          .map(
            (item) => DropdownMenuItem(
              value: item.key,
              child: Text(
                item.value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          )
          .toList(),
      onChanged: (value) {
        if (value != null) onChanged(value);
      },
    ),
  );
}

Widget _sectionLabel(String label) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      label,
      style: const TextStyle(
        color: _textSecondary,
        fontSize: 12,
        fontWeight: FontWeight.w800,
      ),
    ),
  );
}

IconData _askModeIcon(String id) {
  return switch (id) {
    CustomerAskModeIds.priceByArea => Icons.square_foot_rounded,
    CustomerAskModeIds.priceByWidthLength => Icons.straighten_rounded,
    CustomerAskModeIds.materialsByWidthLength => Icons.view_module_rounded,
    CustomerAskModeIds.ceilingSheetsByWidthLength => Icons.grid_on_rounded,
    CustomerAskModeIds.looseProductSale => Icons.scatter_plot_rounded,
    CustomerAskModeIds.boxProductSale => Icons.inventory_2_outlined,
    CustomerAskModeIds.boxPlusLooseSale => Icons.all_inbox_outlined,
    CustomerAskModeIds.singleProductManual => Icons.edit_note_rounded,
    CustomerAskModeIds.materialsOnly => Icons.functions_rounded,
    _ => Icons.help_outline_rounded,
  };
}

IconData _inputIcon(String id) {
  return switch (id) {
    InputMethodIds.areaM2 => Icons.square_foot_rounded,
    InputMethodIds.widthLength => Icons.straighten_rounded,
    InputMethodIds.looseQuantity => Icons.scatter_plot_rounded,
    InputMethodIds.boxQuantity => Icons.inventory_2_outlined,
    InputMethodIds.boxPlusLoose => Icons.all_inbox_outlined,
    InputMethodIds.ceilingLooseSheets => Icons.grid_on_rounded,
    InputMethodIds.ceilingBoxQuantity => Icons.inventory_2_rounded,
    InputMethodIds.ceilingBoxPlusLoose => Icons.all_inbox_rounded,
    InputMethodIds.manualPerProduct => Icons.edit_note_rounded,
    InputMethodIds.manualQuantity => Icons.edit_note_rounded,
    _ => Icons.tune_rounded,
  };
}

IconData _chargeIcon(String id) {
  return switch (id) {
    ChargeMethodIds.areaM2Price => Icons.square_foot_rounded,
    ChargeMethodIds.unitOnly => Icons.scatter_plot_rounded,
    ChargeMethodIds.boxOnly => Icons.inventory_2_outlined,
    ChargeMethodIds.boxPlusLoose => Icons.all_inbox_outlined,
    ChargeMethodIds.manualTotal => Icons.price_change_outlined,
    _ => Icons.sell_outlined,
  };
}

String _productLabel(MaterialItem material) {
  final spec = material.spec.trim().isEmpty ? '' : ' ${material.spec}';
  return '${material.khmerName}$spec';
}

String _productResultLabel(ProductSaleResult result) {
  final spec = result.spec.trim().isEmpty ? '' : ' ${result.spec}';
  return '${result.materialNameKhmer}$spec';
}

bool _isAreaSale(List<ProductSaleResult> results) {
  return results.any(
    (result) => result.chargeMethodId == ChargeMethodIds.areaM2Price,
  );
}

bool _isQuantityOnlyResult(List<ProductSaleResult> results) {
  return results.any(
    (result) => result.chargeMethodId == ChargeMethodIds.quantityOnly,
  );
}

double _areaSaleAreaM2(List<ProductSaleResult> results) {
  for (final result in results) {
    if (result.chargeMethodId == ChargeMethodIds.areaM2Price &&
        result.areaM2 != null &&
        result.areaM2! > 0) {
      return result.areaM2!;
    }
  }
  return 0;
}

double _areaSalePricePerM2(List<ProductSaleResult> results) {
  for (final result in results) {
    if (result.chargeMethodId == ChargeMethodIds.areaM2Price) {
      return result.salePricePerM2;
    }
  }
  return 0;
}

bool _areaSaleBelowCost(List<ProductSaleResult> results) {
  if (!_isAreaSale(results)) return false;
  final totalPay = results.fold<double>(
    0,
    (sum, item) => sum + item.customerPayTotal,
  );
  final totalCost = results.fold<double>(
    0,
    (sum, item) => sum + item.ownerCostTotal,
  );
  return totalCost > 0 && totalPay < totalCost;
}

String _summaryText(List<ProductSaleResult> results) {
  final totalPay = results.fold<double>(
    0,
    (sum, item) => sum + item.customerPayTotal,
  );
  final totalCost = results.fold<double>(
    0,
    (sum, item) => sum + item.ownerCostTotal,
  );
  final totalProfit = results.fold<double>(
    0,
    (sum, item) => sum + item.ownerProfit,
  );
  final buffer = StringBuffer()..writeln('សង្ខេបលក់');
  if (_isQuantityOnlyResult(results)) {
    buffer.writeln(
      'ការ៉េសរុប: ${MoneyFormatter.decimal(_areaSaleAreaM2(results))} m²',
    );
    for (final item in results) {
      buffer.writeln(
        '${_productResultLabel(item)}: ${item.sellQuantity} ${item.unitKhmer} = ${item.packagingFullBoxes} កេស + ${item.packagingLooseItems} រាយ',
      );
    }
    return buffer.toString();
  }
  if (_isAreaSale(results)) {
    buffer
      ..writeln(
        'ការ៉េសរុប: ${MoneyFormatter.decimal(_areaSaleAreaM2(results))} m²',
      )
      ..writeln(
        'តម្លៃលក់ / ការ៉េ: ${MoneyFormatter.money(_areaSalePricePerM2(results))}',
      )
      ..writeln('អតិថិជនបង់: ${MoneyFormatter.money(totalPay)}')
      ..writeln('ថ្លៃដើម: ${MoneyFormatter.money(totalCost)}')
      ..writeln('ចំណេញ: ${MoneyFormatter.money(totalProfit)}')
      ..writeln('សម្ភារៈត្រូវរៀបចំ');
    for (final item in results) {
      buffer.writeln(
        '${_productResultLabel(item)}: ${item.sellQuantity} ${item.unitKhmer} = ${item.packagingFullBoxes} កេស + ${item.packagingLooseItems} រាយ | ដើម ${MoneyFormatter.money(item.productCost)}',
      );
    }
    return buffer.toString();
  }
  for (final item in results) {
    buffer.writeln(
      '${_productResultLabel(item)}: ${item.sellQuantity} ${item.unitKhmer} = ${item.packagingFullBoxes} កេស + ${item.packagingLooseItems} រាយ | ${MoneyFormatter.money(item.customerPayTotal)}',
    );
  }
  buffer
    ..writeln('អតិថិជនបង់សរុប: ${MoneyFormatter.money(totalPay)}')
    ..writeln('ថ្លៃដើមសរុប: ${MoneyFormatter.money(totalCost)}')
    ..writeln('ចំណេញសរុប: ${MoneyFormatter.money(totalProfit)}');
  return buffer.toString();
}

double? _parseDouble(String value) {
  final cleaned = value.replaceAll(',', '').trim();
  if (cleaned.isEmpty) return null;
  return double.tryParse(cleaned);
}

int? _parseInt(String value) {
  final parsed = _parseDouble(value);
  return parsed?.round();
}

double? _price(
  List<MaterialPrice> prices,
  String materialId,
  String priceTypeId, {
  String? fallback,
}) {
  final now = DateTime.now();
  final salePriceCanFallbackFromZero =
      priceTypeId == PriceTypeIds.saleUnitPrice ||
      priceTypeId == PriceTypeIds.saleBoxPrice;
  for (final id in [priceTypeId, ?fallback]) {
    final matches =
        prices
            .where(
              (price) =>
                  price.materialId == materialId &&
                  price.priceTypeId == id &&
                  price.isEffectiveAt(now),
            )
            .toList()
          ..sort((a, b) => b.effectiveFrom.compareTo(a.effectiveFrom));
    if (matches.isNotEmpty) {
      final price = matches.first.price;
      if (id == priceTypeId &&
          price == 0 &&
          salePriceCanFallbackFromZero &&
          fallback != null) {
        continue;
      }
      return price;
    }
  }
  return null;
}

String _moneyOrDash(double? value) {
  return value == null ? '-' : MoneyFormatter.money(value);
}

// Copyright (c) 2026 Material Quote Pro.
// Generated binding surface for native/measurement/include/measurement_engine.h.
// Regenerate with package:ffigen using: dart run tool/ffigen.dart

// ignore_for_file: type=lint, camel_case_types, non_constant_identifier_names

import 'dart:ffi' as ffi;

final class MeasurementHandle extends ffi.Opaque {}

final class MeasurementRoomC extends ffi.Struct {
  @ffi.Int32()
  external int room_id;

  @ffi.Double()
  external double length_mm;

  @ffi.Double()
  external double width_mm;
}

final class MeasurementProductVariantC extends ffi.Struct {
  @ffi.Int32()
  external int variant_id;

  @ffi.Double()
  external double width_mm;

  @ffi.Double()
  external double length_mm;

  @ffi.Double()
  external double thickness_mm;

  @ffi.Double()
  external double unit_price;
}

final class MeasurementOptionsC extends ffi.Struct {
  @ffi.Uint8()
  external int optimize_for;

  @ffi.Uint8()
  external int allow_joints;

  @ffi.Uint8()
  external int reuse_offcuts;

  @ffi.Uint8()
  external int project_mode;

  @ffi.Uint8()
  external int debug_diagnostics;

  @ffi.Uint8()
  external int reserved_0;

  @ffi.Uint8()
  external int reserved_1;

  @ffi.Uint8()
  external int reserved_2;

  @ffi.Double()
  external double spare_percent;

  @ffi.Uint32()
  external int max_search_candidates;
}

final class MeasurementRequestC extends ffi.Struct {
  external ffi.Pointer<MeasurementRoomC> rooms;

  @ffi.Uint32()
  external int room_count;

  external ffi.Pointer<MeasurementProductVariantC> variants;

  @ffi.Uint32()
  external int variant_count;

  external MeasurementOptionsC options;
}

final class MeasurementCandidateC extends ffi.Struct {
  @ffi.Int32()
  external int candidate_id;

  @ffi.Int32()
  external int single_variant_id;

  @ffi.Uint32()
  external int quantity_offset;

  @ffi.Uint32()
  external int quantity_count;

  @ffi.Uint32()
  external int cut_offset;

  @ffi.Uint32()
  external int cut_count;

  @ffi.Uint32()
  external int room_layout_offset;

  @ffi.Uint32()
  external int room_layout_count;

  @ffi.Uint32()
  external int base_piece_count;

  @ffi.Uint32()
  external int reserve_piece_count;

  @ffi.Uint32()
  external int purchase_piece_count;

  @ffi.Uint32()
  external int joint_count;

  @ffi.Uint8()
  external int valid;

  @ffi.Uint8()
  external int stock_mode;

  @ffi.Uint8()
  external int reserved_0;

  @ffi.Uint8()
  external int reserved_1;

  @ffi.Double()
  external double required_area_m2;

  @ffi.Double()
  external double purchased_area_m2;

  @ffi.Double()
  external double waste_area_m2;

  @ffi.Double()
  external double waste_percent;

  @ffi.Double()
  external double total_cost;

  @ffi.Double()
  external double score;
}

final class MeasurementVariantQuantityC extends ffi.Struct {
  @ffi.Uint32()
  external int candidate_index;

  @ffi.Int32()
  external int variant_id;

  @ffi.Uint32()
  external int base_quantity;

  @ffi.Uint32()
  external int reserve_quantity;

  @ffi.Uint32()
  external int purchase_quantity;
}

final class MeasurementCutSegmentC extends ffi.Struct {
  @ffi.Uint32()
  external int candidate_index;

  @ffi.Int32()
  external int room_id;

  @ffi.Uint32()
  external int lane_index;

  @ffi.Int32()
  external int source_variant_id;

  @ffi.Uint32()
  external int source_piece_index;

  @ffi.Uint32()
  external int segment_index;

  @ffi.Uint8()
  external int reused_offcut;

  @ffi.Uint8()
  external int reserved_0;

  @ffi.Uint8()
  external int reserved_1;

  @ffi.Uint8()
  external int reserved_2;

  @ffi.Double()
  external double source_length_mm;

  @ffi.Double()
  external double used_length_mm;

  @ffi.Double()
  external double remainder_length_mm;
}

final class MeasurementRoomLayoutC extends ffi.Struct {
  @ffi.Uint32()
  external int candidate_index;

  @ffi.Int32()
  external int room_id;

  @ffi.Uint8()
  external int orientation;

  @ffi.Uint8()
  external int reserved_0;

  @ffi.Uint8()
  external int reserved_1;

  @ffi.Uint8()
  external int reserved_2;

  @ffi.Uint32()
  external int lane_count;

  @ffi.Double()
  external double longitudinal_span_mm;

  @ffi.Double()
  external double cross_span_mm;
}

final class MeasurementDiagnosticsC extends ffi.Struct {
  @ffi.Uint64()
  external int candidates_considered;

  @ffi.Uint64()
  external int candidates_pruned;

  @ffi.Uint64()
  external int execution_time_us;

  @ffi.Uint32()
  external int cuts;

  @ffi.Uint32()
  external int offcuts_created;

  @ffi.Uint32()
  external int offcuts_reused;
}

final class MeasurementResultC extends ffi.Struct {
  @ffi.Int32()
  external int status;

  @ffi.Int32()
  external int selected_candidate_index;

  external ffi.Pointer<MeasurementCandidateC> candidates;

  @ffi.Uint32()
  external int candidate_count;

  external ffi.Pointer<MeasurementVariantQuantityC> quantities;

  @ffi.Uint32()
  external int quantity_count;

  external ffi.Pointer<MeasurementCutSegmentC> cuts;

  @ffi.Uint32()
  external int cut_count;

  external ffi.Pointer<MeasurementRoomLayoutC> room_layouts;

  @ffi.Uint32()
  external int room_layout_count;

  external MeasurementDiagnosticsC diagnostics;
}

typedef _CreateNative = ffi.Pointer<MeasurementHandle> Function();
typedef _CreateDart = ffi.Pointer<MeasurementHandle> Function();
typedef _DestroyNative = ffi.Void Function(ffi.Pointer<MeasurementHandle>);
typedef _DestroyDart = void Function(ffi.Pointer<MeasurementHandle>);
typedef _OptimizeNative =
    ffi.Int32 Function(
      ffi.Pointer<MeasurementHandle>,
      ffi.Pointer<MeasurementRequestC>,
      ffi.Pointer<MeasurementResultC>,
    );
typedef _OptimizeDart =
    int Function(
      ffi.Pointer<MeasurementHandle>,
      ffi.Pointer<MeasurementRequestC>,
      ffi.Pointer<MeasurementResultC>,
    );
typedef _ReleaseNative = ffi.Void Function(ffi.Pointer<MeasurementResultC>);
typedef _ReleaseDart = void Function(ffi.Pointer<MeasurementResultC>);

class MeasurementBindings {
  MeasurementBindings(ffi.DynamicLibrary library)
    : measurement_engine_create = library
          .lookupFunction<_CreateNative, _CreateDart>(
            'measurement_engine_create',
            isLeaf: true,
          ),
      measurement_engine_destroy = library
          .lookupFunction<_DestroyNative, _DestroyDart>(
            'measurement_engine_destroy',
            isLeaf: true,
          ),
      measurement_optimize = library
          .lookupFunction<_OptimizeNative, _OptimizeDart>(
            'measurement_optimize',
          ),
      measurement_result_release = library
          .lookupFunction<_ReleaseNative, _ReleaseDart>(
            'measurement_result_release',
            isLeaf: true,
          );

  final _CreateDart measurement_engine_create;
  final _DestroyDart measurement_engine_destroy;
  final _OptimizeDart measurement_optimize;
  final _ReleaseDart measurement_result_release;
}

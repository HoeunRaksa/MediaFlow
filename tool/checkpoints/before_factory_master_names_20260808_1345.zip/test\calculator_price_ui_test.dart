import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('calculator table keeps price UX simple and hides cost editors', () {
    final source = File(
      'lib/features/materials/presentation/selling_desktop_shell.dart',
    ).readAsStringSync();
    final tableSource = source.substring(
      source.indexOf('class _ResultsTable'),
      source.indexOf('class _TemporarySaleScreen'),
    );
    final inputSource = source.substring(
      source.indexOf('ProductSaleInput _input'),
      source.indexOf('List<MaterialItem> _products'),
    );

    expect(tableSource, contains("DataColumn(label: Text('តម្លៃលក់'))"));
    expect(tableSource, contains("suffix: '/ កេស'"));
    expect(tableSource, contains("suffix: '/ រាយ'"));
    expect(source, contains("label: const Text('រក្សាទុកតម្លៃនេះ')"));
    expect(source, contains('ថ្លៃដើមនៅជា 0 — មិនទាន់អាចវាយតម្លៃចំណេញពិតបានទេ'));
    expect(tableSource, isNot(contains('ថ្លៃដើមរាយ')));
    expect(tableSource, isNot(contains('ថ្លៃដើមកេស')));
    expect(tableSource, isNot(contains('costUnit')));
    expect(tableSource, isNot(contains('costBox')));
    expect(inputSource, isNot(contains('costUnitPrice:')));
    expect(inputSource, isNot(contains('costBoxPrice:')));
  });
}

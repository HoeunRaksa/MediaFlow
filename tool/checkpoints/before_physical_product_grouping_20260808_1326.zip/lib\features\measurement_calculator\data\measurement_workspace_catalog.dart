import '../../../core/constants/business_ids.dart';
import '../../materials/data/models/material_item.dart';
import '../../materials/data/models/material_price.dart';
import '../domain/workspace_models.dart';

class MeasurementWorkspaceCatalog {
  const MeasurementWorkspaceCatalog();

  List<WorkspaceProduct> build({
    required List<MaterialItem> materials,
    required List<MaterialPrice> prices,
    DateTime? at,
  }) {
    final effectiveAt = at ?? DateTime.now();
    final pricesByMaterial = <String, MaterialPrice>{};
    for (final price in prices) {
      final isSelling =
          price.priceTypeId == PriceTypeIds.saleUnitPrice ||
          price.priceTypeId == PriceTypeIds.saleBoxPrice;
      if (!isSelling || !price.isEffectiveAt(effectiveAt)) continue;
      final current = pricesByMaterial[price.materialId];
      if (current == null ||
          price.effectiveFrom.isAfter(current.effectiveFrom)) {
        pricesByMaterial[price.materialId] = price;
      }
    }

    final grouped = <String, List<MaterialItem>>{};
    for (final material in materials) {
      final familyId = material.productFamilyId;
      if (!material.active ||
          material.categoryId != 'pvc' ||
          familyId == null ||
          pricesByMaterial[material.id] == null) {
        continue;
      }
      grouped.putIfAbsent(familyId, () => []).add(material);
    }

    final products = <WorkspaceProduct>[];
    for (final entry in grouped.entries) {
      entry.value.sort((a, b) {
        final leftLength = a.lengthMm ?? double.maxFinite;
        final rightLength = b.lengthMm ?? double.maxFinite;
        final byLength = leftLength.compareTo(rightLength);
        return byLength != 0 ? byLength : a.id.compareTo(b.id);
      });
      final first = entry.value.first;
      final code = first.code ?? first.englishName;
      final category = _category(code, first);
      final variants = <WorkspaceProductVariant>[];
      for (var index = 0; index < entry.value.length; index++) {
        final material = entry.value[index];
        final price = pricesByMaterial[material.id]!;
        variants.add(
          WorkspaceProductVariant(
            variantId:
                material.lengthMm?.round() ??
                100000 + material.sortOrder + index,
            materialId: material.id,
            label: material.spec.isEmpty ? code : material.spec,
            lengthMm: material.lengthMm,
            widthMm: material.widthMm,
            thicknessMm: material.thicknessMm,
            unitPrice: price.price,
            priceTypeId: price.priceTypeId,
            itemsPerBundle:
                material.piecesPerBundle ?? material.itemsPerBox ?? 1,
          ),
        );
      }
      final hasCoverageData = variants.every(
        (variant) =>
            variant.priceTypeId == PriceTypeIds.saleUnitPrice &&
            variant.lengthMm != null &&
            variant.widthMm != null &&
            variant.thicknessMm != null,
      );
      final calculationKind =
          hasCoverageData &&
              (category == WorkspaceProductCategory.pvc ||
                  category == WorkspaceProductCategory.db ||
                  category == WorkspaceProductCategory.gd)
          ? WorkspaceCalculationKind.coverage
          : variants.any((variant) => variant.lengthMm != null)
          ? WorkspaceCalculationKind.linear
          : WorkspaceCalculationKind.fixed;
      products.add(
        WorkspaceProduct(
          id: entry.key,
          code: code,
          name: first.englishName,
          category: category,
          calculationKind: calculationKind,
          variants: List.unmodifiable(variants),
          sortOrder: first.sortOrder,
        ),
      );
    }
    products.sort((a, b) {
      final byOrder = a.sortOrder.compareTo(b.sortOrder);
      return byOrder != 0 ? byOrder : a.code.compareTo(b.code);
    });
    return List.unmodifiable(products);
  }

  WorkspaceProductCategory _category(String code, MaterialItem material) {
    final normalized = code.toUpperCase();
    if (normalized.startsWith('C.LINE')) return WorkspaceProductCategory.cLine;
    if (normalized.startsWith('DB')) return WorkspaceProductCategory.db;
    if (normalized.startsWith('GD')) return WorkspaceProductCategory.gd;
    if (normalized.startsWith('K-') ||
        normalized.startsWith('P-') ||
        (material.widthMm != null &&
            material.widthMm! >= 100 &&
            material.thicknessMm != null)) {
      return WorkspaceProductCategory.pvc;
    }
    return WorkspaceProductCategory.accessories;
  }
}

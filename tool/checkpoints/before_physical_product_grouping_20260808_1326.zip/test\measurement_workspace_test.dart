import 'package:flutter_test/flutter_test.dart';
import 'package:material_quote_pro/features/materials/data/seed/default_material_seed.dart';
import 'package:material_quote_pro/features/measurement_calculator/data/measurement_workspace_catalog.dart';
import 'package:material_quote_pro/features/measurement_calculator/domain/models/measurement_models.dart';
import 'package:material_quote_pro/features/measurement_calculator/domain/workspace_calculation_service.dart';
import 'package:material_quote_pro/features/measurement_calculator/domain/workspace_models.dart';
import 'package:material_quote_pro/features/measurement_calculator/native/measurement_native_api.dart';

void main() {
  final now = DateTime.utc(2026, 8, 8);
  final seedProducts = const MeasurementWorkspaceCatalog().build(
    materials: DefaultMaterialSeed.materials(now),
    prices: DefaultMaterialSeed.prices(now),
    at: now,
  );
  const room = MeasurementRoom(id: 1, name: 'Room 1', lengthM: 6, widthM: 4.2);

  test('workspace catalog groups all selling product types', () {
    expect(seedProducts.any((product) => product.id == 'pvc_k01'), isTrue);
    expect(
      seedProducts.any((product) => product.id == 'pvc_c_line_023'),
      isTrue,
    );
    expect(seedProducts.any((product) => product.id == 'pvc_glue'), isTrue);
    expect(
      seedProducts.any((product) => product.id == 'pvc_db01_factory'),
      isFalse,
    );
    expect(
      seedProducts
          .singleWhere((product) => product.id == 'pvc_k01')
          .calculationKind,
      WorkspaceCalculationKind.coverage,
    );
    expect(
      seedProducts
          .singleWhere((product) => product.id == 'pvc_c_line_023')
          .category,
      WorkspaceProductCategory.cLine,
    );
  });

  test(
    'linear and fixed materials calculate immediately with bundle semantics',
    () async {
      final service = WorkspaceCalculationService(
        optimizer: _CapturingOptimizer(),
      );
      final result = await service.calculate(
        rooms: const [room],
        selections: [
          WorkspaceProductSelection(
            product: seedProducts.singleWhere(
              (product) => product.id == 'pvc_c_line_023',
            ),
          ),
          WorkspaceProductSelection(
            product: seedProducts.singleWhere(
              (product) => product.id == 'pvc_glue',
            ),
          ),
        ],
        options: const MeasurementOptimizationOptions(),
      );

      final cLine = result.materials.first;
      expect(cLine.totalQuantity, 1);
      expect(cLine.totalPrice, 16.24);
      expect(cLine.lines.single.unitLabel, 'បាច់');
      expect(cLine.lines.single.detail, contains('6'));
      expect(cLine.lines.single.detail, contains('20'));
      expect(result.materials.last.totalPrice, 4.50);
      expect(result.totalPrice, 20.74);
    },
  );

  test('coverage overrides reach the retained native optimizer', () async {
    final optimizer = _CapturingOptimizer();
    final service = WorkspaceCalculationService(optimizer: optimizer);
    final k01 = seedProducts.singleWhere((product) => product.id == 'pvc_k01');
    await service.calculate(
      rooms: const [room],
      selections: [
        WorkspaceProductSelection(
          product: k01,
          overrides: const WorkspaceMaterialOverride(
            variantId: 4000,
            unitPrice: 9,
            sparePercent: 3,
            orientation: MeasurementOrientation.alongWidth,
          ),
        ),
      ],
      options: const MeasurementOptimizationOptions(),
    );

    expect(optimizer.lastRequest!.variants, hasLength(1));
    expect(optimizer.lastRequest!.variants.single.lengthMm, 4000);
    expect(optimizer.lastRequest!.variants.single.unitPrice, 9);
    expect(optimizer.lastRequest!.options.sparePercent, 3);
    expect(
      optimizer.lastRequest!.options.orientationOverride,
      MeasurementOrientation.alongWidth,
    );
  });
}

class _CapturingOptimizer implements MeasurementOptimizer {
  MeasurementOptimizationRequest? lastRequest;

  @override
  Future<MeasurementOptimizationResult> optimize(
    MeasurementOptimizationRequest request,
  ) async {
    lastRequest = request;
    final variant = request.variants.first;
    return MeasurementOptimizationResult(
      status: MeasurementStatus.ok,
      selectedCandidateIndex: 0,
      candidates: [
        MeasurementCandidate(
          candidateId: 1,
          valid: true,
          stockMode: MeasurementStockMode.single,
          singleVariantId: variant.variantId,
          quantities: [
            MeasurementVariantQuantity(
              variantId: variant.variantId,
              baseQuantity: 2,
              reserveQuantity: 0,
              purchaseQuantity: 2,
            ),
          ],
          cuts: const [],
          roomLayouts: const [],
          basePieceCount: 2,
          reservePieceCount: 0,
          purchasePieceCount: 2,
          jointCount: 0,
          requiredAreaM2: 25.2,
          purchasedAreaM2: 25.6,
          wasteAreaM2: 0.4,
          wastePercent: 1.56,
          totalCost: variant.unitPrice * 2,
          score: 0.4,
        ),
      ],
      diagnostics: const MeasurementDiagnostics(
        candidatesConsidered: 1,
        candidatesPruned: 0,
        executionTimeUs: 1,
        cuts: 2,
        offcutsCreated: 0,
        offcutsReused: 0,
      ),
    );
  }
}

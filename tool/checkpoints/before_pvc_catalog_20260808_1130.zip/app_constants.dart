class AppConstants {
  const AppConstants._();

  static const appName = 'គណនាលក់សម្ភារៈ';
  static const khmerFontFamily = 'NotoSansKhmer';
  static const storageFileName = 'material_quote_foundation.json';
  static const dataFolderName = 'MaterialQuotePro';

  static const seedAssetPaths = {
    'materials.json': 'assets/seed/materials.json',
    'prices.json': 'assets/seed/prices.json',
    'packaging.json': 'assets/seed/packaging.json',
    'product_kinds.json': 'assets/seed/product_kinds.json',
    'settings.json': 'assets/seed/settings.json',
  };
}
